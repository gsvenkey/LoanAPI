﻿using AutoMapper;
using PACS.AgriLoan.ViewModel;
using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Services.AutoMapper
{
    public class LoanIssueMapping : Profile
    {
        public LoanIssueMapping()
        {
            #region View Modals to Domain Modals
            CreateMap<LoanIssueHeaderVM, LoanIssueHeader>()
                    .ForMember(dest => dest.LoanReceiptHeaders, src => src.Ignore())
                    .ForMember(dest => dest.LoanClosures, src => src.Ignore())
                    .ForMember(dest => dest.RateOfInterestId, src => src.Ignore())
                    .ForMember(dest => dest.RateOfInterest, src => src.Ignore())
                    .ForMember(dest => dest.FYear, src => src.Ignore())
                    .ForMember(dest => dest.Sanction, src => src.Ignore())
                    .ForMember(dest => dest.Member, src => src.Ignore())
                    .ForMember(dest => dest.LoanType, src => src.Ignore())
                    .ForMember(dest => dest.Pacs, src => src.Ignore())
                    ;

            CreateMap<LoanIssueDetailVM, LoanIssueDetail>()
                .ForMember(dest => dest.Crop, src => src.Ignore())
                .ForMember(dest => dest.VaoDetail, src => src.Ignore())
                .ForMember(dest => dest.Issue, src => src.Ignore())
                .ForMember(dest => dest.SanctionDetail, src => src.Ignore());
            #endregion


            #region Domain Modals to View Modals 
            CreateMap<LoanIssueHeader, LoanIssueHeaderVM>()

                    .ForMember(dest => dest.Message, src => src.Ignore());

            CreateMap<LoanIssueDetail, LoanIssueDetailVM>()
                .ForMember(dest => dest.Message, src => src.Ignore())
                .ForMember(dest => dest.CropName, src => src.Ignore())
                .ForMember(dest => dest.CropNameInTamil, src => src.Ignore());
            //.ForMember(dest => dest.FertilizerPerAcre, src => src.Ignore())
            //.ForMember(dest => dest.SeedPerAcre, src => src.Ignore())
            //.ForMember(dest => dest.PesticidePerAcre, src => src.Ignore())
            //.ForMember(dest => dest.KindFertilizerPerAcre, src => src.Ignore())
            //.ForMember(dest => dest.KindSeedPerAcre, src => src.Ignore())
            //.ForMember(dest => dest.KindPesticidePerAcre, src => src.Ignore());

            CreateMap<VW_ListLoanIssue, ListLoanIssueVM>();

            CreateMap<VW_GetLoanSanctionHeader, LoanIssueHeaderVM>()
               .ForMember(dest => dest.Message, src => src.Ignore())
               .ForMember(dest => dest.SanctionId, src => src.Ignore())
               .ForMember(dest => dest.IssueDate, src => src.Ignore())
               .ForMember(dest => dest.IssueAmount, src => src.Ignore())
               .ForMember(dest => dest.CreatedDate, src => src.Ignore())
               .ForMember(dest => dest.ModifiedDate, src => src.Ignore())
               .ForMember(dest => dest.IsDeleted, src => src.Ignore())
               .ForMember(dest => dest.CreatedBy, src => src.Ignore())
               .ForMember(dest => dest.ModifiedBy, src => src.Ignore())
               .ForMember(dest => dest.RateOfInterestId, src => src.Ignore())
               .ForMember(dest => dest.IssueNo, src => src.Ignore())
               .ForMember(dest => dest.LoanNo, src => src.Ignore())
               .ForMember(dest => dest.DueDate, src => src.Ignore())
               .ForMember(dest => dest.LoanIssueDetails, src => src.Ignore());












            CreateMap<VW_GetLoanSanctionDetail, LoanIssueDetailVM>()
           .ForMember(dest => dest.Message, src => src.Ignore())
           .ForMember(dest => dest.CreatedDate, src => src.Ignore())
           .ForMember(dest => dest.ModifiedDate, src => src.Ignore())
           .ForMember(dest => dest.IsDeleted, src => src.Ignore())
           .ForMember(dest => dest.CreatedBy, src => src.Ignore())
           .ForMember(dest => dest.ModifiedBy, src => src.Ignore())
           .ForMember(dest => dest.SanctionDetailId, src => src.Ignore())
           .ForMember(dest => dest.VaoDetailId, src => src.Ignore())
           .ForMember(dest => dest.IssueAcre, src => src.Ignore())
           .ForMember(dest => dest.Manure, src => src.Ignore())
           .ForMember(dest => dest.IssueId, src => src.Ignore())
           .ForMember(dest => dest.SanctionDetail, src => src.Ignore())

           


           ;

            #endregion
        }

    }
}
