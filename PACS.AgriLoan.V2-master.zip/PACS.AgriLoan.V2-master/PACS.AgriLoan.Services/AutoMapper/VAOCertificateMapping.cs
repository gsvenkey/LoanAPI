﻿using AutoMapper;
using PACS.AgriLoan.ViewModel;
using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;

namespace PACS.AgriLoan.Services.AutoMapper
{
    public class VAOCertificateMapping : Profile
    {
        public VAOCertificateMapping()
        {
            CreateMap<VW_GetSurveyDetail, ServeyDetailsVM>();
            CreateMap<VaoCertificateHeaderVM, VaoCertificateHeader>()
                .ForMember(dest => dest.Id, src => src.MapFrom(src => src.Id))
                .ForMember(dest => dest.Acre, src => src.MapFrom(src => src.Acre))
                .ForMember(dest => dest.CertificateDate, src => src.MapFrom(src => src.CertificateDate))
                .ForMember(dest => dest.CreatedBy, src => src.MapFrom(src => src.CreatedBy))
                .ForMember(dest => dest.CreatedDate, src => src.MapFrom(src => src.CreatedDate))
                .ForMember(dest => dest.DateOfEntry, src => src.MapFrom(src => src.DateOfEntry))
                .ForMember(dest => dest.FirkaId, src => src.MapFrom(src => src.FirkaId))
                .ForMember(dest => dest.IrrigationTypeId, src => src.MapFrom(src => src.IrrigationTypeId))
                .ForMember(dest => dest.IsDeleted, src => src.MapFrom(src => src.IsDeleted))
                .ForMember(dest => dest.MemberId, src => src.MapFrom(src => src.MemberId))
                .ForMember(dest => dest.ModifiedBy, src => src.MapFrom(src => src.ModifiedBy))
                .ForMember(dest => dest.ModifiedDate, src => src.MapFrom(src => src.ModifiedDate))
                .ForMember(dest => dest.OwnerShipTypeId, src => src.MapFrom(src => src.OwnerShipTypeId))
                .ForMember(dest => dest.RevenueVillageId, src => src.MapFrom(src => src.RevenueVillageId))
                .ForMember(dest => dest.VaoCertificateDetails, src => src.MapFrom(src => src.VaoCertificateDetails))
                .ForAllOtherMembers(opt => opt.Ignore());


            CreateMap<VaoCertificateHeader, VaoCertificateHeaderVM>()
                .ForMember(dest => dest.Id, src => src.MapFrom(src => src.Id))
                .ForMember(dest => dest.Acre, src => src.MapFrom(src => src.Acre))
                .ForMember(dest => dest.CertificateDate, src => src.MapFrom(src => src.CertificateDate))
                .ForMember(dest => dest.CreatedBy, src => src.MapFrom(src => src.CreatedBy))
                .ForMember(dest => dest.CreatedDate, src => src.MapFrom(src => src.CreatedDate))
                .ForMember(dest => dest.DateOfEntry, src => src.MapFrom(src => src.DateOfEntry))
                .ForMember(dest => dest.FirkaId, src => src.MapFrom(src => src.FirkaId))
                .ForMember(dest => dest.IrrigationTypeId, src => src.MapFrom(src => src.IrrigationTypeId))
                .ForMember(dest => dest.IsDeleted, src => src.MapFrom(src => src.IsDeleted))
                .ForMember(dest => dest.MemberId, src => src.MapFrom(src => src.MemberId))
                .ForMember(dest => dest.ModifiedBy, src => src.MapFrom(src => src.ModifiedBy))
                .ForMember(dest => dest.ModifiedDate, src => src.MapFrom(src => src.ModifiedDate))
                .ForMember(dest => dest.OwnerShipTypeId, src => src.MapFrom(src => src.OwnerShipTypeId))
                .ForMember(dest => dest.RevenueVillageId, src => src.MapFrom(src => src.RevenueVillageId))
                .ForMember(dest => dest.VaoCertificateDetails, src => src.MapFrom(src => src.VaoCertificateDetails))
                .ForAllOtherMembers(opt => opt.Ignore());



            CreateMap<VaoCertificateDetailVM, VaoCertificateDetail>()
                .ForMember(dest => dest.Id, src => src.MapFrom(src => src.Id))
                .ForMember(dest => dest.Bounded, src => src.MapFrom(src => src.Bounded))
                .ForMember(dest => dest.CreatedBy, src => src.MapFrom(src => src.CreatedBy))
                .ForMember(dest => dest.CreatedDate, src => src.MapFrom(src => src.CreatedDate))
                .ForMember(dest => dest.IsDeleted, src => src.MapFrom(src => src.IsDeleted))
                .ForMember(dest => dest.ModifiedBy, src => src.MapFrom(src => src.ModifiedBy))
                .ForMember(dest => dest.ModifiedDate, src => src.MapFrom(src => src.ModifiedDate))
                .ForMember(dest => dest.ServeyNo, src => src.MapFrom(src => src.ServeyNo))
                .ForMember(dest => dest.SubDivisionNo, src => src.MapFrom(src => src.SubDivisionNo))
                .ForMember(dest => dest.TotalArea, src => src.MapFrom(src => src.TotalArea))
                .ForAllOtherMembers(opt => opt.Ignore());


            CreateMap<VaoCertificateDetail, VaoCertificateDetailVM>()
                .ForMember(dest => dest.Id, src => src.MapFrom(src => src.Id))
                .ForMember(dest => dest.Bounded, src => src.MapFrom(src => src.Bounded))
                .ForMember(dest => dest.CreatedBy, src => src.MapFrom(src => src.CreatedBy))
                .ForMember(dest => dest.CreatedDate, src => src.MapFrom(src => src.CreatedDate))
                .ForMember(dest => dest.IsDeleted, src => src.MapFrom(src => src.IsDeleted))
                .ForMember(dest => dest.ModifiedBy, src => src.MapFrom(src => src.ModifiedBy))
                .ForMember(dest => dest.ModifiedDate, src => src.MapFrom(src => src.ModifiedDate))
                .ForMember(dest => dest.ServeyNo, src => src.MapFrom(src => src.ServeyNo))
                .ForMember(dest => dest.SubDivisionNo, src => src.MapFrom(src => src.SubDivisionNo))
                .ForMember(dest => dest.TotalArea, src => src.MapFrom(src => src.TotalArea))
                .ForAllOtherMembers(opt => opt.Ignore());
        }

    }

    //public class VaoCertificateDetailResolver : IValueResolver<VaoCertificateHeaderVM, VaoCertificateHeader, ICollection<VaoCertificateDetail>>
    //{
    //    public ICollection<VaoCertificateDetail> Resolve(VaoCertificateHeaderVM source, VaoCertificateHeader destination, 
    //        ICollection<VaoCertificateDetail> destMember, ResolutionContext context)
    //    {
    //       if (source != null)
    //        {
    //            return new List<VaoCertificateDetail>
    //            {
    //                new VaoCertificateDetail
    //                {
    //                    Id = source.VaoCertificateDetails.,
    //                    VaoCertificateId = source.VaoCertificateDetails.
    //                }
    //            }
    //        }

    //    }
    //}






}
