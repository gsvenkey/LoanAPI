﻿using AutoMapper;
using PACS.AgriLoan.ViewModel;
using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Services.AutoMapper
{
    public class MemberMasterMapping : Profile

    {
        public MemberMasterMapping()
        {
            CreateMap<MemberMasterVM, MemberMaster>()
               .ForAllOtherMembers(opts => opts.Ignore());

            CreateMap<MemberMaster, MemberMasterVM>()
                .ForMember(dest => dest.Message, src => src.Ignore())
                .ForMember(dest => dest.SelectShareType, src => src.Ignore())
                .ForMember(dest => dest.SelectMembershipType, src => src.Ignore())
                .ForMember(dest => dest.SelectGender, src => src.Ignore())
                .ForMember(dest => dest.SelectReligion, src => src.Ignore())
                .ForMember(dest => dest.SelectCommunity, src => src.Ignore())
               .ForAllOtherMembers(opts => opts.Ignore());

            CreateMap<VW_GetMemberInfo, MemberInfoVM>();
            
        }
    }
}
