﻿using AutoMapper;
using PACS.AgriLoan.ViewModel;
using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Services.AutoMapper
{
    public class LoanReceiptMapping : Profile
    {
        public LoanReceiptMapping()
        {
            #region ViewModals to Domain Modals
            CreateMap<LoanReceiptHeaderVM, LoanReceiptHeader>()
                 .ForMember(dest => dest.Id, src => src.MapFrom(src => src.Id))
                 .ForMember(dest => dest.CreatedBy, src => src.MapFrom(src => src.CreatedBy))
                 .ForMember(dest => dest.CreatedDate, src => src.MapFrom(src => src.CreatedDate))
                 .ForMember(dest => dest.IsDeleted, src => src.MapFrom(src => src.IsDeleted))
                 .ForMember(dest => dest.PacsId, src => src.MapFrom(src => src.PacsId))
                 .ForMember(dest => dest.FYearId, src => src.MapFrom(src => src.FYearId))
                 .ForMember(dest => dest.IssueId, src => src.MapFrom(src => src.IssueId))
                 .ForMember(dest => dest.LoanTypeID, src => src.MapFrom(src => src.LoanTypeId))
                 .ForMember(dest => dest.IssueAmount, src => src.MapFrom(src => src.IssueAmount))
                 .ForMember(dest => dest.MemberID, src => src.MapFrom(src => src.MemberId))
                 .ForMember(dest => dest.MemberID, src => src.MapFrom(src => src.MemberId))
                 .ForMember(dest => dest.MemberID, src => src.MapFrom(src => src.MemberId))
                 .ForAllOtherMembers(opt => opt.Ignore());


            CreateMap<LoanReceiptDetailVM, LoanReceiptDetail>()
                .ForMember(dest => dest.Id, src => src.MapFrom(src => src.Id))
                .ForMember(dest => dest.ReceiptId, src => src.MapFrom(src => src.ReceiptId))
                .ForMember(dest => dest.ReceiptDate, src => src.MapFrom(src => src.ReceiptDate))
                .ForMember(dest => dest.ReceiptNo, src => src.MapFrom(src => src.ReceiptNo))
                .ForMember(dest => dest.Principal, src => src.MapFrom(src => src.Principal))
                .ForMember(dest => dest.Interest, src => src.MapFrom(src => src.Interest))
                .ForMember(dest => dest.PenalInterest, src => src.MapFrom(src => src.PenalInterest))
                .ForMember(dest => dest.Noticecharge, src => src.MapFrom(src => src.Noticecharge))
                .ForMember(dest => dest.ARCFees, src => src.MapFrom(src => src.ARCFees))
                .ForMember(dest => dest.EPFees, src => src.MapFrom(src => src.EPFees))
                .ForMember(dest => dest.OtherFees, src => src.MapFrom(src => src.OtherFees))
                .ForMember(dest => dest.IsDeleted, src => src.MapFrom(src => src.IsDeleted))
                .ForMember(dest => dest.CreatedBy, src => src.MapFrom(src => src.CreatedBy))
                .ForMember(dest => dest.CreatedDate, src => src.MapFrom(src => src.CreatedDate))
                .ForMember(dest => dest.ModifiedBy, src => src.MapFrom(src => src.ModifiedBy))
                .ForMember(dest => dest.ModifiedDate, src => src.MapFrom(src => src.ModifiedDate))
                .ForAllOtherMembers(opt => opt.Ignore());




















            #endregion



            #region Domain Modals to ViewModals

            CreateMap<LoanReceiptHeader, LoanReceiptHeaderVM>()
                 .ForMember(dest => dest.Id, src => src.MapFrom(src => src.Id))
                 .ForMember(dest => dest.PacsId, src => src.MapFrom(src => src.PacsId))
                 .ForMember(dest => dest.FYearId, src => src.MapFrom(src => src.FYearId))
                 .ForMember(dest => dest.MemberId, src => src.MapFrom(src => src.MemberID))
                 .ForMember(dest => dest.LoanTypeId, src => src.MapFrom(src => src.LoanTypeID))
                 .ForMember(dest => dest.IssueId, src => src.MapFrom(src => src.IssueId))
                 .ForMember(dest => dest.IsDeleted, src => src.MapFrom(src => src.IsDeleted))
                 .ForMember(dest => dest.CreatedBy, src => src.MapFrom(src => src.CreatedBy))
                 .ForMember(dest => dest.CreatedDate, src => src.MapFrom(src => src.CreatedDate))
                 .ForMember(dest => dest.ModifiedBy, src => src.MapFrom(src => src.ModifiedBy))
                 .ForMember(dest => dest.ModifiedDate, src => src.MapFrom(src => src.ModifiedDate))
                 .ForMember(dest => dest.IssueNo, src => src.Ignore())
                 .ForMember(dest => dest.LoanNo, src => src.Ignore())
                 .ForMember(dest => dest.IssueDate, src => src.Ignore())
                 .ForMember(dest => dest.DueDate, src => src.Ignore())
                 .ForMember(dest => dest.IssueAmount, src => src.MapFrom(src => src.IssueAmount))
                 .ForMember(dest => dest.RateId, src => src.Ignore())
                 .ForMember(dest => dest.NormalROI, src => src.Ignore())
                 .ForMember(dest => dest.PenalROI, src => src.Ignore())
                 .ForMember(dest => dest.NormalNoOfDays, src => src.Ignore())
                 .ForMember(dest => dest.PenalNoOfDays, src => src.Ignore())
                 .ForMember(dest => dest.PrinicipalPaid, src => src.Ignore())
                 .ForMember(dest => dest.Intrest, src => src.Ignore())
                 .ForMember(dest => dest.PenalIntrest, src => src.Ignore())
                 .ForMember(dest => dest.PrinicipalTaken, src => src.Ignore())
                 .ForMember(dest => dest.BalancePrinicipal, src => src.Ignore())
                 .ForMember(dest => dest.ReceiptAmount, src => src.Ignore());


            CreateMap<LoanReceiptDetail, LoanReceiptDetailVM>()
                .ForMember(dest => dest.Id, src => src.MapFrom(src => src.Id))
                .ForMember(dest => dest.ReceiptId, src => src.MapFrom(src => src.ReceiptId))
                .ForMember(dest => dest.ReceiptDate, src => src.MapFrom(src => src.ReceiptDate))
                .ForMember(dest => dest.ReceiptNo, src => src.MapFrom(src => src.ReceiptNo))
                .ForMember(dest => dest.Principal, src => src.MapFrom(src => src.Principal))
                .ForMember(dest => dest.Interest, src => src.MapFrom(src => src.Interest))
                .ForMember(dest => dest.PenalInterest, src => src.MapFrom(src => src.PenalInterest))
                .ForMember(dest => dest.Noticecharge, src => src.MapFrom(src => src.Noticecharge))
                .ForMember(dest => dest.ARCFees, src => src.MapFrom(src => src.ARCFees))
                .ForMember(dest => dest.EPFees, src => src.MapFrom(src => src.EPFees))
                .ForMember(dest => dest.OtherFees, src => src.MapFrom(src => src.OtherFees))
                .ForMember(dest => dest.IsDeleted, src => src.MapFrom(src => src.IsDeleted))
                .ForMember(dest => dest.CreatedBy, src => src.MapFrom(src => src.CreatedBy))
                .ForMember(dest => dest.CreatedDate, src => src.MapFrom(src => src.CreatedDate))
                .ForMember(dest => dest.ModifiedBy, src => src.MapFrom(src => src.ModifiedBy))
                .ForMember(dest => dest.ModifiedDate, src => src.MapFrom(src => src.ModifiedDate))
                .ForAllOtherMembers(opt => opt.Ignore());




            CreateMap<VW_GetLoanReceiptPendingDetail, LoanReceiptHeaderVM>()
                .ForMember(dest => dest.Id, src => src.MapFrom(src => src.ReceiptId))
                .ForMember(dest => dest.PacsId, src => src.MapFrom(src => src.PacsId))
                .ForMember(dest => dest.FYearId, src => src.MapFrom(src => src.FYearId))
                .ForMember(dest => dest.MemberId, src => src.MapFrom(src => src.MemberId))
                .ForMember(dest => dest.LoanTypeId, src => src.MapFrom(src => src.LoanTypeId))
                .ForMember(dest => dest.IssueId, src => src.MapFrom(src => src.IssueId))
                .ForMember(dest => dest.IssueNo, src => src.MapFrom(src => src.IssueNo))
                .ForMember(dest => dest.LoanNo, src => src.MapFrom(src => src.LoanNo))
                .ForMember(dest => dest.IssueDate, src => src.MapFrom(src => src.IssueDate))
                .ForMember(dest => dest.DueDate, src => src.MapFrom(src => src.IssueDate))
                .ForMember(dest => dest.IssueAmount, src => src.MapFrom(src => src.DueDate))
                .ForMember(dest => dest.RateId, src => src.MapFrom(src => src.RateId))
                .ForMember(dest => dest.NormalROI, src => src.MapFrom(src => src.NormalROI))
                .ForMember(dest => dest.PenalROI, src => src.MapFrom(src => src.PenalROI))
                .ForMember(dest => dest.NormalNoOfDays, src => src.MapFrom(src => src.NormalNoOfDays))
                .ForMember(dest => dest.PenalNoOfDays, src => src.MapFrom(src => src.PenalNoOfDays))
                .ForMember(dest => dest.PrinicipalPaid, src => src.MapFrom(src => src.PrinicipalPaid))
                .ForMember(dest => dest.Intrest, src => src.MapFrom(src => src.Intrest))
                .ForMember(dest => dest.PenalIntrest, src => src.MapFrom(src => src.PenalIntrest))
                .ForMember(dest => dest.IsDeleted, src => src.Ignore())
                .ForMember(dest => dest.CreatedBy, src => src.Ignore())
                .ForMember(dest => dest.CreatedDate, src => src.Ignore())
                .ForMember(dest => dest.ModifiedBy, src => src.Ignore())
                .ForMember(dest => dest.ModifiedDate, src => src.Ignore());

            #endregion
        }
    }
}
