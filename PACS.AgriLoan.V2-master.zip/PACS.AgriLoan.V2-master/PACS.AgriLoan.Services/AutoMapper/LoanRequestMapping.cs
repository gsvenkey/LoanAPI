﻿using AutoMapper;
using PACS.AgriLoan.ViewModel;
using PASC.AgriLoan.DomainModels.Models;

namespace PACS.AgriLoan.Services.AutoMapper
{
    public class LoanRequestMapping : Profile
    {
        public LoanRequestMapping()
        {
            #region View Modals to Domain Modals

            CreateMap<LoanRequestHeaderVM, LoanRequestHeader>()
                 .ForMember(dest => dest.Id, src => src.MapFrom(src => src.Id))
                 .ForMember(dest => dest.CreatedBy, src => src.MapFrom(src => src.CreatedBy))
                 .ForMember(dest => dest.CreatedDate, src => src.MapFrom(src => src.CreatedDate))
                 .ForMember(dest => dest.IsDeleted, src => src.MapFrom(src => src.IsDeleted))
                 .ForMember(dest => dest.MemberID, src => src.MapFrom(src => src.MemberID))
                 .ForMember(dest => dest.ModifiedBy, src => src.MapFrom(src => src.ModifiedBy))
                 .ForMember(dest => dest.ModifiedDate, src => src.MapFrom(src => src.ModifiedDate))
                 .ForMember(dest => dest.RequestNo, src => src.MapFrom(src => src.RequestNo))
                 .ForMember(dest => dest.RequestAmount, src => src.MapFrom(src => src.RequestAmount))
                 .ForMember(dest => dest.PacsId, src => src.MapFrom(src => src.PacsId))
                 .ForMember(dest => dest.FYearId, src => src.MapFrom(src => src.FYearId))
                 .ForMember(dest => dest.RequestDate, src => src.MapFrom(src => src.RequestDate))
                 .ForMember(dest => dest.LoanTypeID, src => src.MapFrom(src => src.LoanTypeID))
                 .ForMember(dest => dest.LoanRequestDetails, src => src.MapFrom(src => src.LoanRequestDetails))
                 .ForMember(dest => dest.JewelPledgedDetails, src => src.MapFrom(src => src.JewelPledgedDetails))
                 .ForMember(dest => dest.JlgLoanTypeDetails, src => src.MapFrom(src => src.JlgLoanTypeDetails))
                 .ForMember(dest => dest.LandPledgedDetails, src => src.MapFrom(src => src.LandPledgedDetails))
                 .ForMember(dest => dest.SuretyDetails, src => src.MapFrom(src => src.SuretyDetails))
                 .ForMember(dest => dest.JlgLoanMemberDetails, src => src.MapFrom(src => src.JlgLoanMemberDetails))

                 .ForAllOtherMembers(opt => opt.Ignore());

            CreateMap<LoanRequestDetailVM, LoanRequestDetail>()
                 .ForMember(dest => dest.LoanRequestId, src => src.MapFrom(src => src.LoanRequestId))
                 .ForMember(dest => dest.CropId, src => src.MapFrom(src => src.CropId))
                 .ForMember(dest => dest.Acre, src => src.MapFrom(src => src.Acre))
                 .ForMember(dest => dest.CultivationAcre, src => src.MapFrom(src => src.CultivationAcre))
                 .ForMember(dest => dest.Id, src => src.MapFrom(src => src.Id))
                 .ForMember(dest => dest.VaoDetailId, src => src.MapFrom(src => src.VaoDetailId))
                 .ForMember(dest => dest.LoanDuePeriod, src => src.MapFrom(src => src.LoanDuePeriod))
                 .ForMember(dest => dest.RequestAmount, src => src.MapFrom(src => src.RequestAmount))
                 .ForMember(dest => dest.IsDeleted, src => src.MapFrom(src => src.IsDeleted))
                 .ForMember(dest => dest.CreatedBy, src => src.MapFrom(src => src.CreatedBy))
                 .ForMember(dest => dest.CreatedDate, src => src.MapFrom(src => src.CreatedDate))
                 .ForMember(dest => dest.ModifiedBy, src => src.MapFrom(src => src.ModifiedBy))
                 .ForMember(dest => dest.ModifiedDate, src => src.MapFrom(src => src.ModifiedDate))
                 .ForAllOtherMembers(opt => opt.Ignore());

            CreateMap<JewelPledgedDetailVM, JewelPledgedDetail>()
                .ForMember(dest => dest.Id, src => src.MapFrom(src => src.Id))
                 .ForMember(dest => dest.IsDeleted, src => src.MapFrom(src => src.IsDeleted))
                 .ForMember(dest => dest.CreatedBy, src => src.MapFrom(src => src.CreatedBy))
                 .ForMember(dest => dest.CreatedDate, src => src.MapFrom(src => src.CreatedDate))
                 .ForMember(dest => dest.ModifiedBy, src => src.MapFrom(src => src.ModifiedBy))
                 .ForMember(dest => dest.LoanRequestId, src => src.MapFrom(src => src.LoanRequestId))
                 .ForMember(dest => dest.JewelMasterId, src => src.MapFrom(src => src.JewelMasterId))
                 .ForMember(dest => dest.NoOfItem, src => src.MapFrom(src => src.NoOfItem))
                 .ForMember(dest => dest.TotalWeight, src => src.MapFrom(src => src.TotalWeight))
                 .ForMember(dest => dest.DisallowedWt, src => src.MapFrom(src => src.DisallowedWt))
                 .ForMember(dest => dest.EstimateWeight, src => src.MapFrom(src => src.EstimateWeight))
                 .ForMember(dest => dest.EstimationValue, src => src.MapFrom(src => src.EstimationValue))
                 .ForMember(dest => dest.PacsValue, src => src.MapFrom(src => src.PacsValue))
                .ForAllOtherMembers(opt => opt.Ignore());


            CreateMap<JlgLoanTypeDetailVM, JlgLoanTypeDetail>()
                  .ForMember(dest => dest.Id, src => src.MapFrom(src => src.Id))
                 .ForMember(dest => dest.IsDeleted, src => src.MapFrom(src => src.IsDeleted))
                 .ForMember(dest => dest.CreatedBy, src => src.MapFrom(src => src.CreatedBy))
                 .ForMember(dest => dest.CreatedDate, src => src.MapFrom(src => src.CreatedDate))
                 .ForMember(dest => dest.ModifiedBy, src => src.MapFrom(src => src.ModifiedBy))
                 .ForMember(dest => dest.LoanRequestId, src => src.MapFrom(src => src.LoanRequestId))
                 .ForMember(dest => dest.JlgHeaderId, src => src.MapFrom(src => src.JlgHeaderId))
                 .ForMember(dest => dest.ResolutionNumber, src => src.MapFrom(src => src.ResolutionNumber))
                 .ForMember(dest => dest.ResolutionDate, src => src.MapFrom(src => src.ResolutionDate))
                 .ForMember(dest => dest.MemberSavingsAmount, src => src.MapFrom(src => src.MemberSavingsAmount))
                 .ForMember(dest => dest.GovtRFSubsidyAmount, src => src.MapFrom(src => src.GovtRFSubsidyAmount))
                 .ForMember(dest => dest.LoanOutstanding, src => src.MapFrom(src => src.LoanOutstanding))
                 .ForMember(dest => dest.MembersODLoanAmount, src => src.MapFrom(src => src.MembersODLoanAmount))
                 .ForMember(dest => dest.InterestIncome, src => src.MapFrom(src => src.InterestIncome))
                 .ForMember(dest => dest.JLGCashBalance, src => src.MapFrom(src => src.JLGCashBalance))
                 .ForMember(dest => dest.BalanceAmount, src => src.MapFrom(src => src.BalanceAmount))
                .ForAllOtherMembers(opt => opt.Ignore());


            CreateMap<LandPledgedDetailVM, LandPledgedDetail>()
                 .ForMember(dest => dest.Id, src => src.MapFrom(src => src.Id))
                 .ForMember(dest => dest.IsDeleted, src => src.MapFrom(src => src.IsDeleted))
                 .ForMember(dest => dest.CreatedBy, src => src.MapFrom(src => src.CreatedBy))
                 .ForMember(dest => dest.CreatedDate, src => src.MapFrom(src => src.CreatedDate))
                 .ForMember(dest => dest.ModifiedBy, src => src.MapFrom(src => src.ModifiedBy))
                 .ForMember(dest => dest.LoanRequestId, src => src.MapFrom(src => src.LoanRequestId))
                 .ForMember(dest => dest.SubRegisterId, src => src.MapFrom(src => src.SubRegisterId))
                 .ForMember(dest => dest.MortgageRegNo, src => src.MapFrom(src => src.MortgageRegNo))
                 .ForMember(dest => dest.DateOfMortgage, src => src.MapFrom(src => src.DateOfMortgage))
                 .ForMember(dest => dest.MortgageAmount, src => src.MapFrom(src => src.MortgageAmount))
                .ForAllOtherMembers(opt => opt.Ignore());


            CreateMap<SuretyDetailVM, SuretyDetail>()
                .ForMember(dest => dest.Id, src => src.MapFrom(src => src.Id))
                .ForMember(dest => dest.MemberId, src => src.MapFrom(src => src.MemberId))
                .ForMember(dest => dest.LoanRequestId, src => src.MapFrom(src => src.LoanRequestId))
                .ForMember(dest => dest.IsDeleted, src => src.MapFrom(src => src.IsDeleted))
                .ForMember(dest => dest.CreatedBy, src => src.MapFrom(src => src.CreatedBy))
                .ForMember(dest => dest.CreatedDate, src => src.MapFrom(src => src.CreatedDate))
                .ForMember(dest => dest.ModifiedBy, src => src.MapFrom(src => src.ModifiedBy))
                .ForMember(dest => dest.ModifiedDate, src => src.MapFrom(src => src.ModifiedDate))
                .ForAllOtherMembers(opt => opt.Ignore());

            CreateMap<TieUpCompanyDetailVM, TieUpCompanyDetail>()
             .ForMember(dest => dest.Id, src => src.MapFrom(src => src.Id))
                .ForMember(dest => dest.TieUpCompanyId, src => src.MapFrom(src => src.TieUpCompanyId))
                .ForMember(dest => dest.TieupLetterDate, src => src.MapFrom(src => src.TieupLetterDate))
                .ForMember(dest => dest.MaximumLoanAmount, src => src.MapFrom(src => src.MaximumLoanAmount))
                .ForMember(dest => dest.LoanRequestId, src => src.MapFrom(src => src.LoanRequestId))
                .ForMember(dest => dest.IsDeleted, src => src.MapFrom(src => src.IsDeleted))
                .ForMember(dest => dest.CreatedBy, src => src.MapFrom(src => src.CreatedBy))
                .ForMember(dest => dest.CreatedDate, src => src.MapFrom(src => src.CreatedDate))
                .ForMember(dest => dest.ModifiedBy, src => src.MapFrom(src => src.ModifiedBy))
                .ForMember(dest => dest.ModifiedDate, src => src.MapFrom(src => src.ModifiedDate))
                .ForAllOtherMembers(opt => opt.Ignore());

            CreateMap<JlgLoanMemberDetailVM, JlgLoanMemberDetail>()
               .ForMember(dest => dest.LoanRequest, src => src.Ignore())
               .ForMember(dest => dest.Member, src => src.Ignore())
                //.ForMember(dest => dest.Id, src => src.MapFrom(src => src.Id))
                //.ForMember(dest => dest.MemberId, src => src.MapFrom(src => src.MemberId))
                //.ForMember(dest => dest.LoanRequestId, src => src.MapFrom(src => src.LoanRequestId))
                //.ForMember(dest => dest.IsDeleted, src => src.MapFrom(src => src.IsDeleted))
                //.ForMember(dest => dest.CreatedBy, src => src.MapFrom(src => src.CreatedBy))
                //.ForMember(dest => dest.CreatedDate, src => src.MapFrom(src => src.CreatedDate))
                //.ForMember(dest => dest.ModifiedBy, src => src.MapFrom(src => src.ModifiedBy))
                //.ForMember(dest => dest.ModifiedDate, src => src.MapFrom(src => src.ModifiedDate))
                //.ForAllOtherMembers(opt => opt.Ignore())
                ;

            #endregion

            #region Domain Modals to View Modals

            CreateMap<LoanRequestHeader, LoanRequestHeaderVM>()
               .ForMember(dest => dest.Id, src => src.MapFrom(src => src.Id))
               .ForMember(dest => dest.CreatedBy, src => src.MapFrom(src => src.CreatedBy))
               .ForMember(dest => dest.CreatedDate, src => src.MapFrom(src => src.CreatedDate))
               .ForMember(dest => dest.IsDeleted, src => src.MapFrom(src => src.IsDeleted))
               .ForMember(dest => dest.MemberID, src => src.MapFrom(src => src.MemberID))
               .ForMember(dest => dest.ModifiedBy, src => src.MapFrom(src => src.ModifiedBy))
               .ForMember(dest => dest.ModifiedDate, src => src.MapFrom(src => src.ModifiedDate))
               .ForMember(dest => dest.RequestNo, src => src.MapFrom(src => src.RequestNo))
               .ForMember(dest => dest.RequestAmount, src => src.MapFrom(src => src.RequestAmount))
               .ForMember(dest => dest.PacsId, src => src.MapFrom(src => src.PacsId))
               .ForMember(dest => dest.FYearId, src => src.MapFrom(src => src.FYearId))
               .ForMember(dest => dest.PasalaiYear, src => src.MapFrom(src => src.PasalaiYear))
               .ForMember(dest => dest.IsAdangal, src => src.MapFrom(src => src.IsAdangal))
               .ForMember(dest => dest.RequestDate, src => src.MapFrom(src => src.RequestDate))
               .ForMember(dest => dest.LoanTypeID, src => src.MapFrom(src => src.LoanTypeID))
               .ForMember(dest => dest.LoanRequestDetails, src => src.MapFrom(src => src.LoanRequestDetails))
               .ForMember(dest => dest.JewelPledgedDetails, src => src.MapFrom(src => src.JewelPledgedDetails))
               .ForMember(dest => dest.JlgLoanTypeDetails, src => src.MapFrom(src => src.JlgLoanTypeDetails))
               .ForMember(dest => dest.LandPledgedDetails, src => src.MapFrom(src => src.LandPledgedDetails))
               .ForMember(dest => dest.SuretyDetails, src => src.MapFrom(src => src.SuretyDetails))
               .ForMember(dest => dest.JlgLoanMemberDetails, src => src.MapFrom(src => src.JlgLoanMemberDetails))
               .ForAllOtherMembers(opt => opt.Ignore());

            CreateMap<LoanRequestDetail, LoanRequestDetailVM>()
                 .ForMember(dest => dest.LoanRequestId, src => src.MapFrom(src => src.LoanRequestId))
                 .ForMember(dest => dest.CropId, src => src.MapFrom(src => src.CropId))
                 .ForMember(dest => dest.Acre, src => src.MapFrom(src => src.Acre))
                 .ForMember(dest => dest.CultivationAcre, src => src.MapFrom(src => src.CultivationAcre))
                 .ForMember(dest => dest.VaoDetailId, src => src.MapFrom(src => src.VaoDetailId))
                 .ForMember(dest => dest.VaoDetail, src => src.MapFrom(src => src.VaoDetail))
                 .ForMember(dest => dest.LoanDuePeriod, src => src.MapFrom(src => src.LoanDuePeriod))
                 .ForMember(dest => dest.RequestAmount, src => src.MapFrom(src => src.RequestAmount))
                 .ForMember(dest => dest.Id, src => src.MapFrom(src => src.Id))
                 .ForMember(dest => dest.IsDeleted, src => src.MapFrom(src => src.IsDeleted))
                 .ForMember(dest => dest.CreatedBy, src => src.MapFrom(src => src.CreatedBy))
                 .ForMember(dest => dest.CreatedDate, src => src.MapFrom(src => src.CreatedDate))
                 .ForMember(dest => dest.ModifiedBy, src => src.MapFrom(src => src.ModifiedBy))
                 .ForMember(dest => dest.ModifiedDate, src => src.MapFrom(src => src.ModifiedDate))
                 .ForAllOtherMembers(opt => opt.Ignore());

            CreateMap<JewelPledgedDetail, JewelPledgedDetailVM>()
                 .ForMember(dest => dest.Id, src => src.MapFrom(src => src.Id))
                 .ForMember(dest => dest.IsDeleted, src => src.MapFrom(src => src.IsDeleted))
                 .ForMember(dest => dest.CreatedBy, src => src.MapFrom(src => src.CreatedBy))
                 .ForMember(dest => dest.CreatedDate, src => src.MapFrom(src => src.CreatedDate))
                 .ForMember(dest => dest.ModifiedBy, src => src.MapFrom(src => src.ModifiedBy))
                 .ForMember(dest => dest.LoanRequestId, src => src.MapFrom(src => src.LoanRequestId))
                 .ForMember(dest => dest.JewelMasterId, src => src.MapFrom(src => src.JewelMasterId))
                 .ForMember(dest => dest.NoOfItem, src => src.MapFrom(src => src.NoOfItem))
                 .ForMember(dest => dest.TotalWeight, src => src.MapFrom(src => src.TotalWeight))
                 .ForMember(dest => dest.DisallowedWt, src => src.MapFrom(src => src.DisallowedWt))
                 .ForMember(dest => dest.EstimateWeight, src => src.MapFrom(src => src.EstimateWeight))
                 .ForMember(dest => dest.EstimationValue, src => src.MapFrom(src => src.EstimationValue))
                 .ForMember(dest => dest.PacsValue, src => src.MapFrom(src => src.PacsValue))
                 .ForAllOtherMembers(opt => opt.Ignore());


            CreateMap<JlgLoanTypeDetail, JlgLoanTypeDetailVM>()
                 .ForMember(dest => dest.Id, src => src.MapFrom(src => src.Id))
                 .ForMember(dest => dest.IsDeleted, src => src.MapFrom(src => src.IsDeleted))
                 .ForMember(dest => dest.CreatedBy, src => src.MapFrom(src => src.CreatedBy))
                 .ForMember(dest => dest.CreatedDate, src => src.MapFrom(src => src.CreatedDate))
                 .ForMember(dest => dest.ModifiedBy, src => src.MapFrom(src => src.ModifiedBy))
                 .ForMember(dest => dest.LoanRequestId, src => src.MapFrom(src => src.LoanRequestId))
                 .ForMember(dest => dest.JlgHeaderId, src => src.MapFrom(src => src.JlgHeaderId))
                 .ForMember(dest => dest.ResolutionNumber, src => src.MapFrom(src => src.ResolutionNumber))
                 .ForMember(dest => dest.ResolutionDate, src => src.MapFrom(src => src.ResolutionDate))
                 .ForMember(dest => dest.MemberSavingsAmount, src => src.MapFrom(src => src.MemberSavingsAmount))
                 .ForMember(dest => dest.GovtRFSubsidyAmount, src => src.MapFrom(src => src.GovtRFSubsidyAmount))
                 .ForMember(dest => dest.LoanOutstanding, src => src.MapFrom(src => src.LoanOutstanding))
                 .ForMember(dest => dest.MembersODLoanAmount, src => src.MapFrom(src => src.MembersODLoanAmount))
                 .ForMember(dest => dest.InterestIncome, src => src.MapFrom(src => src.InterestIncome))
                 .ForMember(dest => dest.JLGCashBalance, src => src.MapFrom(src => src.JLGCashBalance))
                 .ForMember(dest => dest.BalanceAmount, src => src.MapFrom(src => src.BalanceAmount))
                .ForAllOtherMembers(opt => opt.Ignore());


            CreateMap<LandPledgedDetail, LandPledgedDetailVM>()
                .ForMember(dest => dest.Id, src => src.MapFrom(src => src.Id))
                 .ForMember(dest => dest.IsDeleted, src => src.MapFrom(src => src.IsDeleted))
                 .ForMember(dest => dest.CreatedBy, src => src.MapFrom(src => src.CreatedBy))
                 .ForMember(dest => dest.CreatedDate, src => src.MapFrom(src => src.CreatedDate))
                 .ForMember(dest => dest.ModifiedBy, src => src.MapFrom(src => src.ModifiedBy))
                 .ForMember(dest => dest.LoanRequestId, src => src.MapFrom(src => src.LoanRequestId))
                 .ForMember(dest => dest.SubRegisterId, src => src.MapFrom(src => src.SubRegisterId))
                 .ForMember(dest => dest.MortgageRegNo, src => src.MapFrom(src => src.MortgageRegNo))
                 .ForMember(dest => dest.DateOfMortgage, src => src.MapFrom(src => src.DateOfMortgage))
                 .ForMember(dest => dest.MortgageAmount, src => src.MapFrom(src => src.MortgageAmount))
                 .ForAllOtherMembers(opt => opt.Ignore());


            CreateMap<SuretyDetail, SuretyDetailVM>()
                .ForMember(dest => dest.Id, src => src.MapFrom(src => src.Id))
                .ForMember(dest => dest.MemberId, src => src.MapFrom(src => src.MemberId))
                .ForMember(dest => dest.LoanRequestId, src => src.MapFrom(src => src.LoanRequestId))
                .ForMember(dest => dest.IsDeleted, src => src.MapFrom(src => src.IsDeleted))
                .ForMember(dest => dest.CreatedBy, src => src.MapFrom(src => src.CreatedBy))
                .ForMember(dest => dest.CreatedDate, src => src.MapFrom(src => src.CreatedDate))
                .ForMember(dest => dest.ModifiedBy, src => src.MapFrom(src => src.ModifiedBy))
                .ForMember(dest => dest.ModifiedDate, src => src.MapFrom(src => src.ModifiedDate))
                .ForAllOtherMembers(opt => opt.Ignore());


            CreateMap<TieUpCompanyDetail, TieUpCompanyDetailVM>()
             .ForMember(dest => dest.Id, src => src.MapFrom(src => src.Id))
                .ForMember(dest => dest.TieUpCompanyId, src => src.MapFrom(src => src.TieUpCompanyId))
                .ForMember(dest => dest.TieupLetterDate, src => src.MapFrom(src => src.TieupLetterDate))
                .ForMember(dest => dest.MaximumLoanAmount, src => src.MapFrom(src => src.MaximumLoanAmount))
                .ForMember(dest => dest.LoanRequestId, src => src.MapFrom(src => src.LoanRequestId))
                .ForMember(dest => dest.IsDeleted, src => src.MapFrom(src => src.IsDeleted))
                .ForMember(dest => dest.CreatedBy, src => src.MapFrom(src => src.CreatedBy))
                .ForMember(dest => dest.CreatedDate, src => src.MapFrom(src => src.CreatedDate))
                .ForMember(dest => dest.ModifiedBy, src => src.MapFrom(src => src.ModifiedBy))
                .ForMember(dest => dest.ModifiedDate, src => src.MapFrom(src => src.ModifiedDate))
                .ForAllOtherMembers(opt => opt.Ignore());


            CreateMap<JlgLoanMemberDetail, JlgLoanMemberDetailVM>()
                .ForMember(dest => dest.Id, src => src.MapFrom(src => src.Id))
               .ForMember(dest => dest.MemberId, src => src.MapFrom(src => src.MemberId))
               .ForMember(dest => dest.LoanRequestId, src => src.MapFrom(src => src.LoanRequestId))
               .ForMember(dest => dest.IsDeleted, src => src.MapFrom(src => src.IsDeleted))
               .ForMember(dest => dest.CreatedBy, src => src.MapFrom(src => src.CreatedBy))
               .ForMember(dest => dest.CreatedDate, src => src.MapFrom(src => src.CreatedDate))
               .ForMember(dest => dest.ModifiedBy, src => src.MapFrom(src => src.ModifiedBy))
               .ForMember(dest => dest.ModifiedDate, src => src.MapFrom(src => src.ModifiedDate))
               .ForAllOtherMembers(opt => opt.Ignore());

            CreateMap<VW_ListLoanRequest, ListLoanRequestVM>();


            #endregion
        }
    }
}
