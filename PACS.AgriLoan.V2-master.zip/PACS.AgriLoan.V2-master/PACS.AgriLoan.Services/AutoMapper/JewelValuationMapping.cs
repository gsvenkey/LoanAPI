﻿using AutoMapper;
using PACS.AgriLoan.ViewModel;
using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Services.AutoMapper
{
  public  class JewelValuationMapping : Profile
    {
        public JewelValuationMapping()
        {
            CreateMap<JewelValuation, JewelValuationVM>()
                .ForMember(dest => dest.Message, opt => opt.Ignore());

            CreateMap<JewelValuationVM, JewelValuation>()
                .ForMember(dest => dest.Pacs, opt => opt.Ignore());


        }
    }
}
