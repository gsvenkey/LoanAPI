﻿using AutoMapper;
using PACS.AgriLoan.ViewModel;
using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Services.AutoMapper
{
   public class PacsReportMappings : Profile
    {
        public PacsReportMappings()
        {
            #region BondReport
           
            CreateMap<VW_Rpt_IssueSummary, BondReportVM>()
                 .ForMember(dest => dest.Id, src => src.MapFrom(src => src.Id))
                 .ForMember(dest => dest.PacsId, src => src.MapFrom(src => src.PacsId))
                 .ForMember(dest => dest.LoanTypeID, src => src.MapFrom(src => src.LoanTypeID))
                 .ForMember(dest => dest.LoanTypeName, src => src.MapFrom(src => src.LoanTypeName))
                 .ForMember(dest => dest.LoanTypeNameInTamil, src => src.MapFrom(src => src.LoanTypeNameInTamil))
                 .ForMember(dest => dest.RateOfInterestId, src => src.MapFrom(src => src.RateOfInterestId))
                 .ForMember(dest => dest.Normal, src => src.MapFrom(src => src.Normal))
                 .ForMember(dest => dest.Penal, src => src.MapFrom(src => src.Penal))
                 .ForMember(dest => dest.SanctionAmount, src => src.MapFrom(src => src.SanctionAmount))
                 .ForMember(dest => dest.IssueAmount, src => src.MapFrom(src => src.IssueAmount))
                 .ForMember(dest => dest.MemberId, src => src.MapFrom(src => src.MemberId))
                 .ForMember(dest => dest.MemberName, src => src.MapFrom(src => src.MemberName))
                 .ForMember(dest => dest.GardianName, src => src.MapFrom(src => src.GardianName))
                 .ForMember(dest => dest.Relationship, src => src.MapFrom(src => src.Relationship))
                 .ForMember(dest => dest.Address1, src => src.MapFrom(src => src.Address1))
                 .ForMember(dest => dest.Address2, src => src.MapFrom(src => src.Address2))
                 .ForMember(dest => dest.Address3, src => src.MapFrom(src => src.Address3))
                 .ForMember(dest => dest.Address4, src => src.MapFrom(src => src.Address4))
                 .ForMember(dest => dest.VillageName, src => src.MapFrom(src => src.VillageName))
                 .ForMember(dest => dest.Pincode, src => src.MapFrom(src => src.Pincode))
                 .ForMember(dest => dest.PacsNameInTamil, src => src.MapFrom(src => src.PacsNameInTamil))
                 .ForMember(dest => dest.IssueDate, src => src.MapFrom(src => src.IssueDate))
                 .ForMember(dest => dest.DueDate, src => src.MapFrom(src => src.DueDate))
                 .ForMember(dest => dest.IssueNo, src => src.MapFrom(src => src.IssueNo))
                 .ForMember(dest => dest.LoanNo, src => src.MapFrom(src => src.LoanNo))
                 .ForMember(dest => dest.MemberNumber, src => src.MapFrom(src => src.MemberNumber))
                 .ForMember(dest => dest.PacsAddress, src => src.MapFrom(src => src.PacsAddress))
                 
                 .ForAllOtherMembers(opt => opt.Ignore());

            #endregion
        }
    }
}
