﻿using AutoMapper;
using PACS.AgriLoan.ViewModel;
using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Services.AutoMapper
{
  public  class JlgMapping : Profile
    {
        public JlgMapping()
        {
            CreateMap<VW_GetJlgMembersInfo, JlgMembersInfoVM>();
        }
    }
}
