﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using PACS.AgriLoan.Business.Interface;
using PACS.AgriLoan.Interface.Common;
using PACS.AgriLoan.ViewModel;
using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Services.Implementation
{
    public class LoanRequestBL : ILoanRequestBL
    {

        #region Properties

        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;
        private readonly ILogger<LoanRequestBL> _logger;

        #endregion

        #region Constructor

        public LoanRequestBL(IUnitOfWork unitOfWork, IMapper mapper, ILogger<LoanRequestBL> logger)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
            _logger = logger;
        }



        #endregion

        #region CURD
        public async Task<bool> Add(LoanRequestHeaderVM loanRequestHeader)
        {
            bool status = false;
            try
            {
              
                var obj = _mapper.Map<LoanRequestHeader>(loanRequestHeader);
                obj.RequestNo = await _unitOfWork.LoanRequest.GetNextNo(obj.PacsId, obj.LoanTypeID);

           

                //params object[] myObjArray = { obj.PacsId, obj.LoanTypeID };

                // obj.RequestNo = _unitOfWork.LoanRequest.GetWithRawSql().GetWithRawSql("select [dbo].[fn_GetLoanRequestNextNo]({0},{1})", myObjArray);
                await _unitOfWork.LoanRequest.AddAsync(obj);
                status = await _unitOfWork.Commit();
            }
            catch (Exception ex)
            {
                _logger.LogError("Invoked Add in LoanRequestBL & Object is : " + loanRequestHeader);
                _logger.LogError("Message is  : " + Convert.ToString("" + ex.Message));
                _logger.LogError("Inner Exception is  : " + Convert.ToString("" + ex.InnerException));

            }
            return status;

        }

        public async Task<bool> Update(LoanRequestHeaderVM loanRequestHeader)
        {
            bool status = false;
            try
            {
                var obj = _mapper.Map<LoanRequestHeader>(loanRequestHeader);
                _unitOfWork.LoanRequest.Update(obj);
                status = await _unitOfWork.Commit();
            }
            catch (Exception ex)
            {
                _logger.LogError("Invoked Update in LoanRequestBL & Object is : " + loanRequestHeader);
                _logger.LogError("Message is  : " + Convert.ToString("" + ex.Message));
                _logger.LogError("Inner Exception is  : " + Convert.ToString("" + ex.InnerException));

            }
            return status;

        }

        public async Task<LoanRequestHeaderVM> GetById(long Id)
        {
            var obj = await _unitOfWork.LoanRequest.GetFirstOrDefault(c => c.Id == Id, includeProperties: "LoanRequestDetails," +
                                                                     "JewelPledgedDetails,LandPledgedDetails,SuretyDetails,TieUpCompanyDetails," +
                                                                     "JlgLoanTypeDetails,JlgLoanMemberDetails");

            //foreach (LoanRequestDetail Item in obj.LoanRequestDetails)
            //{
            //    Item.VaoDetail = await _unitOfWork.VAOCertificate.GetVaoCertificateDetailById(Item.VaoDetailId);
            //    obj.LoanRequestDetails.Add(Item);
            //}

            var VM = _mapper.Map<LoanRequestHeaderVM>(obj);

            foreach (LoanRequestDetailVM Item in VM.LoanRequestDetails)
            {
                Item.CropCategoryId = await _unitOfWork.CropCategory.getCropCategoryId(Item.CropId);
            }

            return VM;


        }


        public async Task<LoanRequestHeaderVM> GetLoanTypeDetails(long Id)
        {
            var obj = await _unitOfWork.LoanRequest.GetFirstOrDefault(c => c.Id == Id, includeProperties: "JewelPledgedDetails,LandPledgedDetails," +
                                 "SuretyDetails,TieUpCompanyDetails,JlgLoanTypeDetails,JlgLoanMemberDetails");
            return _mapper.Map<LoanRequestHeaderVM>(obj);
        }

        public async Task<bool> SoftDelete(long id)
        {
            _unitOfWork.LoanRequest.Remove(id);
            return await _unitOfWork.Commit();
        }

        public async Task<IEnumerable<ListLoanRequestVM>> GetList(long pacsId, long fYearId)
        {
            var obj = await _unitOfWork.LoanRequest.GetList(pacsId, fYearId);
            return _mapper.Map<IEnumerable<ListLoanRequestVM>>(obj);
        }


        #endregion

        public async Task<IEnumerable<SelectListItem>> SelectRequestNo(long pacsId, long memberId)
        {
            return await _unitOfWork.LoanRequest.SelectRequestNo(pacsId, memberId);
        }


    }
}
