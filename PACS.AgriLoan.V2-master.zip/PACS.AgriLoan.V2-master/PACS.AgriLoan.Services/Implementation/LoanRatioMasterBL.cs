﻿using AutoMapper;
using PACS.AgriLoan.Business.Interface;
using PACS.AgriLoan.Interface.Common;
using PACS.AgriLoan.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Services.Implementation
{
    public class LoanRatioMasterBL : ILoanRatioMasterBL
    {
        #region Properties

        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;

        #endregion

        #region Constructor

        public LoanRatioMasterBL(IUnitOfWork unitOfWork, IMapper mapper)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
        }



        #endregion

        public async Task<decimal> GetEstimationAmount(long pacsId, long cropId, decimal acre)
        {
            var estimateAmount = Roundoff(await _unitOfWork.LoanRatioMaster.GetEstimationAmount(pacsId, cropId) * acre);
            return estimateAmount;
        }

        public async Task<LoanRatioMasterVM> GetLoanRatioForCrop(long pacsId, long cropId, decimal acre)
        {

            var LoanRatio = await _unitOfWork.LoanRatioMaster.GetLoanRatioForCrop(pacsId, cropId);

            if (LoanRatio != null)
            {
                var AppConfig = await _unitOfWork.ApplicationConfiguration.GetFirstOrDefault();
                var LoanRatioVM = _mapper.Map<LoanRatioMasterVM>(LoanRatio);

                LoanRatioVM.AcreCash = Roundoff(LoanRatioVM.Cash * acre);
                LoanRatioVM.CashFertilizer = CalculatAmount(acre, AppConfig.CashForFertilizer, LoanRatioVM.Fertilizer);
                LoanRatioVM.CashSeed = CalculatAmount(acre, AppConfig.CashForSeed, LoanRatioVM.Seed);
                LoanRatioVM.CashPesticide = CalculatAmount(acre, AppConfig.CashForPesticide, LoanRatioVM.Pesticide);
                LoanRatioVM.KindFertilizer = CalculatAmount(acre, AppConfig.KindForFertilizer, LoanRatioVM.Fertilizer);
                LoanRatioVM.KindSeed = CalculatAmount(acre, AppConfig.KindForSeed, LoanRatioVM.Seed);
                LoanRatioVM.KindPesticide = CalculatAmount(acre, AppConfig.KindForPesticide, LoanRatioVM.Pesticide);
                LoanRatioVM.Maintanance = Roundoff(LoanRatioVM.Maintanance * acre);
                return LoanRatioVM;
            }
            else
            {
                return null;
            }
        }

        #region Private Methods

        private decimal CalculatAmount(decimal acre, decimal percentage, decimal perAcreValue)
        {
            return Roundoff(((acre * perAcreValue) / 100) * percentage);
        }

        private decimal Roundoff(decimal rawAmount)
        {
            return Math.Round(rawAmount);
        }
        #endregion
    }
}
