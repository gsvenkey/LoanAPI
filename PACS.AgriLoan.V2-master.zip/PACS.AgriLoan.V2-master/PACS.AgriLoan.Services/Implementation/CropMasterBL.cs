﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc.Rendering;
using PACS.AgriLoan.Business.Interface;
using PACS.AgriLoan.Interface.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Services.Implementation
{
    public class CropMasterBL : ICropMasterBL
    {
        #region Properties

        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;

        #endregion

        #region Constructor

        public CropMasterBL(IUnitOfWork unitOfWork, IMapper mapper)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
        }

        #endregion



        public async Task<IEnumerable<SelectListItem>> SelectCrop(long categoryId)
        {
            return await _unitOfWork.CropMaster.SelectCrop(categoryId);
        }

        public async Task<IEnumerable<SelectListItem>> SelectCrop(long pacsId,long categoryId)
        {
            return await _unitOfWork.CropMaster.SelectCrop(pacsId,categoryId);
        }
    }
}
