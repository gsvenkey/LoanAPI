﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc.Rendering;
using PACS.AgriLoan.Business.Interface;
using PACS.AgriLoan.Interface.Common;
using PACS.AgriLoan.ViewModel;
using PASC.AgriLoan.DomainModels.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Services.Implementation
{
    public class DistrictMasterBL : IDistrictMasterBL
    {
        #region Properties

        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;

        #endregion

        #region Constructor
        
        public DistrictMasterBL(IUnitOfWork unitOfWork, IMapper mapper)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
        }
       
        #endregion

        public async Task<IEnumerable<DistrictVM>> GetAll()
        {
            var obj = await _unitOfWork.DistrictMaster.GetAllsync();
            return obj != null ? _mapper.Map<IEnumerable<DistrictVM>>(obj) : null;
        }

        public async Task<IEnumerable<SelectListItem>> SelectDistrict()
        {
            return await _unitOfWork.DistrictMaster.SelectDistrict();
        }


        #region CURD Operation
        public async Task<DistrictVM> Add(DistrictVM districtVM)
        {
            var obj = _mapper.Map<DistrictMaster>(districtVM);
            await _unitOfWork.DistrictMaster.AddAsync(obj);
            await _unitOfWork.Commit();
            return districtVM;
        }

        public async Task<DistrictVM> Update(DistrictVM districtVM)
        {
            _unitOfWork.DistrictMaster.Update(_mapper.Map<DistrictMaster>(districtVM));
            await _unitOfWork.Commit();
            return districtVM;
        }

        public async Task<DistrictVM> GetById(long Id)
        {
            var obj = await _unitOfWork.DistrictMaster.GetByIdsync(Id);
            return obj != null ? _mapper.Map<DistrictVM>(obj) : null;
        }

        public async Task<DistrictVM> SoftDelete(DistrictVM districtVM)
        {
            _unitOfWork.DistrictMaster.Remove(_mapper.Map<DistrictMaster>(districtVM));
            await _unitOfWork.Commit();
            return districtVM;
        }


        #endregion

        #region Valiation
        /// <summary>
        /// Check by ID
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        public async Task<bool> IsDistrictExist(long Id)
        {
            return await _unitOfWork.DistrictMaster.IsExist(Id);
        }
        /// <summary>
        /// Check by Name
        /// </summary>
        /// <param name="Name"></param>
        /// <returns></returns>
        public async Task<bool> IsDistrictExist(string Name)
        {
            return await _unitOfWork.DistrictMaster.IsExist(Name);

        }
        #endregion



    }
}
