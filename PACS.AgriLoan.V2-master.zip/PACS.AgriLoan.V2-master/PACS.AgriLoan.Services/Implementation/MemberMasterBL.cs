﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc.Rendering;
using PACS.AgriLoan.Business.Interface;
using PACS.AgriLoan.Interface.Common;
using PACS.AgriLoan.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Services.Implementation
{
    public class MemberMasterBL : IMemberMasterBL
    {
        #region Properties

        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;

        #endregion

        #region Constructor

        public MemberMasterBL(IUnitOfWork unitOfWork, IMapper mapper)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
        }

        public async Task<MemberMasterVM> GetById(long Id)
        {
            var obj = await _unitOfWork.MemberMaster.GetByIdsync(Id);
            return _mapper.Map<MemberMasterVM>(obj);
        }

        public async Task<MemberInfoVM> GetMemberInfo(long Id)
        {
            var result = await _unitOfWork.MemberMaster.GetMemberInfo(Id);
            return _mapper.Map<MemberInfoVM>(result);
        }

        public async Task<IEnumerable<SelectListItem>> SelectMember(long pacsId)
        {
            return await _unitOfWork.MemberMaster.SelectMember(pacsId);
        }

        #endregion




    }
}
