﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using PACS.AgriLoan.Business.Interface;
using PACS.AgriLoan.Interface.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Services.Implementation
{
    public class SubRegisterOfficeBL : ISubRegisterOfficeBL
    {
        #region Properties

        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;
        private readonly ILogger<SubRegisterOfficeBL> _logger;

        #endregion

        #region Constructor

        public SubRegisterOfficeBL(IUnitOfWork unitOfWork, IMapper mapper, ILogger<SubRegisterOfficeBL> logger)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
            _logger = logger;
        }



        #endregion

        public async Task<IEnumerable<SelectListItem>> SelectSubRegsterDistrict(long pacsId)
        {
            return await _unitOfWork.SubRegisterOffice.SelectSubRegsterDistrict(pacsId);
        }

        public async Task<IEnumerable<SelectListItem>> SelectSubRegsterOffice(long subRegsterDistrictId)
        {
            return await _unitOfWork.SubRegisterOffice.SelectSubRegsterOffice(subRegsterDistrictId);
        }
    }
}
