﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using PACS.AgriLoan.Business.Interface;
using PACS.AgriLoan.Interface.Common;
using PACS.AgriLoan.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Services.Implementation
{
   public class JlgBL : IJlgBL
    {
        #region Properties

        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;
        private readonly ILogger<JlgBL> _logger;

        #endregion

        #region Constructor

        public JlgBL(IUnitOfWork unitOfWork, IMapper mapper, ILogger<JlgBL> logger)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
            _logger = logger;
        }

        public async Task<IEnumerable<JlgMembersInfoVM>> GetJlgMembersInfo(long JlgMemberId)
        {
          var obj = await _unitOfWork.Jlg.GetJlgMembersInfo(JlgMemberId);
            return _mapper.Map<IEnumerable<JlgMembersInfoVM>>(obj);
        }

        public async Task<IEnumerable<SelectListItem>> SelectJlg(long pacsId)
        {
            return await _unitOfWork.Jlg.SelectJlg(pacsId);
        }



        #endregion


    }
}
