﻿using AutoMapper;
using Microsoft.Extensions.Logging;
using PACS.AgriLoan.Business.Interface;
using PACS.AgriLoan.Interface.Common;
using PACS.AgriLoan.ViewModel;
using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Services.Implementation
{
    public class VAOCertificateBL : IVAOCertificateBL
    {
        #region Properties

        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;
        private readonly ILogger<VAOCertificateBL> _logger;

        #endregion

        #region Constructor

        public VAOCertificateBL(IUnitOfWork unitOfWork, IMapper mapper, ILogger<VAOCertificateBL> logger)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
            _logger = logger;
        }



        #endregion
       
        #region CURD
        public async Task<bool> Add(VaoCertificateHeaderVM vaoCertificateHeaderVM)
        {
            bool status = false;
            try
            {
                var obj = _mapper.Map<VaoCertificateHeader>(vaoCertificateHeaderVM);
                await _unitOfWork.VAOCertificate.AddAsync(obj);
                status = await _unitOfWork.Commit();
            }
            catch (Exception ex)
            {
                _logger.LogError("Invoked Add in VAOCertificateBL & Object is : " + vaoCertificateHeaderVM);
                _logger.LogError("Message is  : " + Convert.ToString("" + ex.Message));
                _logger.LogError("Inner Exception is  : " + Convert.ToString("" + ex.InnerException));

            }
            return status;

        }

        public async Task<VaoCertificateHeaderVM> GetById(long Id)
        {
            var obj = await _unitOfWork.VAOCertificate.GetFirstOrDefault(c => c.Id == Id, includeProperties: "VaoCertificateDetails");
            return _mapper.Map<VaoCertificateHeaderVM>(obj);
        }

        #endregion

        public async Task<IEnumerable<ServeyDetailsVM>> GetServeyDetails(long memberId)
        {
            var obj = await _unitOfWork.VAOCertificate.GetSurveyDetails(memberId);
            return obj != null ? _mapper.Map<IEnumerable<ServeyDetailsVM>>(obj) : null;
        }

    }
}
