﻿using AutoMapper;
using Microsoft.Extensions.Logging;
using PACS.AgriLoan.Business.Interface;
using PACS.AgriLoan.Interface.Common;
using PACS.AgriLoan.ViewModel;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Services.Implementation
{
    public class PacsReportBL: IPacsReportBL
    {
        #region Properties

        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;
        private readonly ILogger<PacsReportBL> _logger;

        #endregion

        #region Constructor

        public PacsReportBL(IUnitOfWork unitOfWork, IMapper mapper, ILogger<PacsReportBL> logger)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
            _logger = logger;
        }



        #endregion

        string reportSource = AppSettings.Instance.reportSource;
        string reportDestination = AppSettings.Instance.reportDestination;

        public async Task<BondReportVM> RptIssueSummary(long issueId)
        {
            var bondRpt =  await _unitOfWork.pacsReport.RptIssueSummary(issueId);
            return _mapper.Map<BondReportVM>(bondRpt);
        }


    }
}
