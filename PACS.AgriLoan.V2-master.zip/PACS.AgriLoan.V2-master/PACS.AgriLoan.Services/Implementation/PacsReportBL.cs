﻿using AutoMapper;
using DocumentFormat.OpenXml.Packaging;
using Microsoft.Extensions.Logging;
using PACS.AgriLoan.Business.Interface;
using PACS.AgriLoan.Interface.Common;
using PACS.AgriLoan.ViewModel;
using System;
using System.IO;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Services.Implementation
{
    public class PacsReportBL: IPacsReportBL
    {
        #region Properties

        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;
        private readonly ILogger<PacsReportBL> _logger;

        #endregion

        #region Constructor

        public PacsReportBL(IUnitOfWork unitOfWork, IMapper mapper, ILogger<PacsReportBL> logger)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
            _logger = logger;
        }



        #endregion

        string reportSource = AppSettings.Instance.reportSource;
        string reportDestination = AppSettings.Instance.reportDestination;

        public async Task<BondReportVM> RptIssueSummary(long issueId)
        {
            var bondRpt =  await _unitOfWork.pacsReport.RptIssueSummary(issueId);
            return _mapper.Map<BondReportVM>(bondRpt);
        }

        public async Task<bool> GenerateSuritySanction(long sanctionId, int sdsCode)
        {
            string sourceFile = reportSource + @"\Surity\1.Suriety Loan request.docx";
            string destinationFile= reportDestination +"\\"+ sdsCode.ToString() + @"\Surity";
            try
            {
                if (!Directory.Exists(destinationFile))
                {
                    Directory.CreateDirectory(destinationFile);
                }
                destinationFile = destinationFile + "\\" + sanctionId.ToString() + @"_LoanRequest.docx";
                File.Copy(sourceFile, destinationFile, true);
                var requestHeader = await _unitOfWork.pacsReport.GetRequestHeader(sanctionId);


                using (WordprocessingDocument wordDoc = WordprocessingDocument.Open(destinationFile, true))
                {
                    string docText = null;
                    using (StreamReader sr = new StreamReader(wordDoc.MainDocumentPart.GetStream()))
                    {
                        docText = sr.ReadToEnd();
                    }

                    StringBuilder sb = new StringBuilder(docText);
                    
                    //Member Details
                        
                    sb.Replace("XXMEMBERNAMEXX", requestHeader.MemberName.ToString());
                    sb.Replace("XXMEMBERNOXX", requestHeader.MemberNumber.ToString());
                    sb.Replace("XXADDRESS1XX", Convert.ToString("" + requestHeader.Address1));
                    sb.Replace("XXADDRESS2XX", Convert.ToString(""+ requestHeader.Address2));
                    sb.Replace("XXADDRESS3XX", Convert.ToString(""+ requestHeader.Address3));
                    sb.Replace("XXADDRESS4XX", Convert.ToString(""+ requestHeader.Address4));
                    sb.Replace("XXPINCODEXX", Convert.ToString(""+ requestHeader.Pincode));
                    sb.Replace("XXMOBILENOXX", Convert.ToString(""+ requestHeader.MobileNumber));

                    //Pacs Details
                   
                    sb.Replace("XXPACSNAMEXX", requestHeader.PacsName.ToString());
                    sb.Replace("XXPACSADDRESS1XX", Convert.ToString("" + requestHeader.PacsAddress1));
                    sb.Replace("XXPACSADDRESS2XX", Convert.ToString("" + requestHeader.PacsAddress2));
                    sb.Replace("XXPACSADDRESS3XX", Convert.ToString("" + requestHeader.PacsAddress3));
                    sb.Replace("XXPACSADDRESS4XX", Convert.ToString("" + requestHeader.PacsAddress4));


                    // Sanction Details
                    sb.Replace("XXSANDATEXX", requestHeader.SanctionDate.ToString("dd-MM-yyyy"));

                    string newDocText = sb.ToString();





                    using (StreamWriter sw = new StreamWriter(wordDoc.MainDocumentPart.GetStream(FileMode.Create)))
                    {
                        sw.Write(newDocText, Encoding.Unicode);
                    }
                }


                    return true;
            }
            catch (IOException iox)
            {
                _logger.LogError("Invoked Add in GenerateSuritySanction & Object is : " + sanctionId);
                _logger.LogError("Message is  : " + Convert.ToString("" + iox.Message));
                _logger.LogError("Inner Exception is  : " + Convert.ToString("" + iox.InnerException));
                return false;

            }
        }
    }
}
