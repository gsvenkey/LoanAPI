﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using PACS.AgriLoan.Business.Interface;
using PACS.AgriLoan.Interface.Common;
using PACS.AgriLoan.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Services.Implementation
{
    public class LoanReceiptBL : ILoanReceiptBL
    {
        #region Properties

        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;
        private readonly ILogger<LoanReceiptBL> _logger;

        #endregion

        #region Constructor

        public LoanReceiptBL(IUnitOfWork unitOfWork, IMapper mapper, ILogger<LoanReceiptBL> logger)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
            _logger = logger;
        }



        #endregion


        public Task<bool> Add(LoanReceiptHeaderVM loanReceiptHeaderVM)
        {
            throw new NotImplementedException();
        }

        public async Task<LoanReceiptHeaderVM> getReceiptDetails(long IssueId)
        {
            var header = await _unitOfWork.loanReceipt.getReceiptDetails(IssueId);
            var headerVM = _mapper.Map<LoanReceiptHeaderVM>(header);

            if (header.ReceiptId > 0)
            {
                var detail = await _unitOfWork.loanReceiptDetail.GetAllsync(p => p.ReceiptId == header.ReceiptId && p.IsDeleted == false);
                if (detail.Count() > 0)
                {
                    headerVM.LoanReceiptDetails = _mapper.Map<ICollection<LoanReceiptDetailVM>>(detail);
                }
            }


            return headerVM;
        }

        public async Task<IEnumerable<SelectListItem>> SelectIssueNo(long pacsId, long memberId)
        {
            return await _unitOfWork.loanReceipt.SelectIssueNo(pacsId, memberId);
        }

        public Task<bool> SoftDelete(long id)
        {
            throw new NotImplementedException();
        }

        public Task<bool> Update(LoanReceiptHeaderVM loanReceiptHeaderVM)
        {
            throw new NotImplementedException();
        }
    }
}
