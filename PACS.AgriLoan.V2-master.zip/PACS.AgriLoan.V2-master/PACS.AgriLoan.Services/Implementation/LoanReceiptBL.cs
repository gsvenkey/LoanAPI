﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using PACS.AgriLoan.Business.Interface;
using PACS.AgriLoan.Interface.Common;
using PACS.AgriLoan.ViewModel;
using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Services.Implementation
{
    public class LoanReceiptBL : ILoanReceiptBL
    {
        #region Properties

        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;
        private readonly ILogger<LoanReceiptBL> _logger;

        #endregion

        #region Constructor

        public LoanReceiptBL(IUnitOfWork unitOfWork, IMapper mapper, ILogger<LoanReceiptBL> logger)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
            _logger = logger;
        }



        #endregion

        public async Task<LoanReceiptHeaderVM> getReceiptDetails(long IssueId)
        {
            var header = await _unitOfWork.loanReceipt.getReceiptDetails(IssueId);
            var headerVM = _mapper.Map<LoanReceiptHeaderVM>(header);

            if (header.ReceiptId > 0)
            {
                var detail = await _unitOfWork.loanReceiptDetail.GetAllsync(p => p.ReceiptId == header.ReceiptId && p.IsDeleted == false);
                if (detail.Count() > 0)
                {
                    headerVM.LoanReceiptDetails = _mapper.Map<ICollection<LoanReceiptDetailVM>>(detail);
                }
            }


            return headerVM;
        }

        public async Task<IEnumerable<SelectListItem>> SelectIssueNo(long pacsId, long memberId)
        {
            return await _unitOfWork.loanReceipt.SelectIssueNo(pacsId, memberId);
        }


        public async Task<bool> Add(LoanReceiptHeaderVM loanReceiptHeaderVM)
        {
            bool status = false;
            decimal receiptAmt = 0;
            if (loanReceiptHeaderVM.Id == 0)
            {
                try
                {
                    var obj = _mapper.Map<LoanReceiptHeader>(loanReceiptHeaderVM);


                    foreach (var item in obj.LoanReceiptDetails)
                    {
                        item.ReceiptNo = await _unitOfWork.loanReceipt.GetNextNo(obj.PacsId);
                        obj.LoanReceiptDetails.Add(item);
                        receiptAmt += item.Principal;
                    }

                    await _unitOfWork.loanReceipt.AddAsync(obj);
                    if (receiptAmt >= loanReceiptHeaderVM.IssueAmount)
                    {
                        await LoanClosure(loanReceiptHeaderVM);
                    }

                    status = await _unitOfWork.Commit();
                }
                catch (Exception ex)
                {
                    _logger.LogError("Invoked Add in LoanReceiptBL & Object is : " + loanReceiptHeaderVM);
                    _logger.LogError("Message is  : " + Convert.ToString("" + ex.Message));
                    _logger.LogError("Inner Exception is  : " + Convert.ToString("" + ex.InnerException));
                    status = false;

                }
            }
            else
            {
                try
                {
                    var obj = _mapper.Map<LoanReceiptDetail>(loanReceiptHeaderVM.LoanReceiptDetails);
                    obj.ReceiptNo = await _unitOfWork.loanReceipt.GetNextNo(loanReceiptHeaderVM.PacsId);
                    await _unitOfWork.loanReceiptDetail.AddAsync(obj);
                    var PreviousRcptAmt = await _unitOfWork.loanReceiptDetail.GetPreviousRcptAmt(obj.ReceiptId);
                    if (PreviousRcptAmt + obj.Principal >= loanReceiptHeaderVM.IssueAmount)
                    {
                        await LoanClosure(loanReceiptHeaderVM);
                    }
                    status = await _unitOfWork.Commit();
                }
                catch (Exception ex)
                {
                    _logger.LogError("Invoked Add in LoanReceiptBL & Object is : " + loanReceiptHeaderVM);
                    _logger.LogError("Message is  : " + Convert.ToString("" + ex.Message));
                    _logger.LogError("Inner Exception is  : " + Convert.ToString("" + ex.InnerException));
                    status = false;

                }
            }

            return status;


        }

        //public Task<bool> Update(LoanReceiptHeaderVM loanReceiptHeaderVM)
        //{
        //    throw new NotImplementedException();
        //}

        public async Task<bool> SoftDelete(long id)
        {
            _unitOfWork.loanReceiptDetail.Remove(id);
            if (await IsLoanClosureExist(id) == true)
            {
                DeleteLoanClosure(id);
            }
            return await _unitOfWork.Commit();
        }


        #region  private functions
        private async Task LoanClosure(LoanReceiptHeaderVM loanReceiptHeaderVM)
        {
            var Closure = new LoanClosure();
            Closure.ClosedDate = DateTime.Today;
            Closure.Comments = loanReceiptHeaderVM.LoanClosureComments;
            Closure.IssueId = loanReceiptHeaderVM.IssueId;
            Closure.CreatedBy = loanReceiptHeaderVM.CreatedBy;
            await _unitOfWork.LoanClosure.AddAsync(Closure);
        }

        private void DeleteLoanClosure(long id)
        {
            _unitOfWork.LoanClosure.Remove(id);
        }


        private async Task<bool> IsLoanClosureExist(long Id)
        {
            return await _unitOfWork.LoanClosure.IsExist(Id);
        }
        #endregion

    }
}
