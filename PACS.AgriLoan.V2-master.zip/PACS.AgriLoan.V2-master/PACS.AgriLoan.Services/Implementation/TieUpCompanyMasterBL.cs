﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc.Rendering;
using PACS.AgriLoan.Business.Interface;
using PACS.AgriLoan.Interface.Common;
using PACS.AgriLoan.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Services.Implementation
{
    public class TieUpCompanyMasterBL : ITieUpCompanyMasterBL
    {
        #region Properties

        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;

        #endregion

        #region Constructor

        public TieUpCompanyMasterBL(IUnitOfWork unitOfWork, IMapper mapper)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
        }

        public async Task<TieUpCompanyMasterVM> GetCompanyDetails(long id)
        {
            var obj = await _unitOfWork.TieUpCompanyMaster.GetByIdsync(id);
            return _mapper.Map<TieUpCompanyMasterVM>(obj);
        }

        #endregion

        public async Task<IEnumerable<SelectListItem>> SelectCompany(long pacsId)
        {
            return await _unitOfWork.TieUpCompanyMaster.SelectCompany(pacsId);
        }
    }
}
