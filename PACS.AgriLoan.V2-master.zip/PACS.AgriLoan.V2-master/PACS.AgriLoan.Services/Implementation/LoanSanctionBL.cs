﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using PACS.AgriLoan.Business.Interface;
using PACS.AgriLoan.Interface.Common;
using PACS.AgriLoan.ViewModel;
using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Services.Implementation
{
    public class LoanSanctionBL : ILoanSanctionBL
    {

        #region Properties

        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;
        private readonly ILogger<LoanSanctionBL> _logger;

        #endregion

        #region Constructor

        public LoanSanctionBL(IUnitOfWork unitOfWork, IMapper mapper, ILogger<LoanSanctionBL> logger)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
            _logger = logger;
        }



        #endregion

        public async Task<LoanSanctionHeaderVM> GetLoanRequestDetails(long requestId)
        {

            try
            {
                var header = await _unitOfWork.LoanSanction.GetLoanRequestHeader(requestId);
                var Detail = await _unitOfWork.LoanSanction.GetLoanRequestDetail(requestId);


                var headerVM = _mapper.Map<LoanSanctionHeaderVM>(header);
                if (Detail.Count() > 0)
                {
                    headerVM.LoanSanctionDetails = _mapper.Map<ICollection<LoanSanctionDetailVM>>(Detail);
                }

              


                return headerVM;
            }
            catch (Exception ex)
            {
                _logger.LogError("Invoked Add in GetLoanRequestDetails & Object is : " + requestId);
                _logger.LogError("Message is  : " + Convert.ToString("" + ex.Message));
                _logger.LogError("Inner Exception is  : " + Convert.ToString("" + ex.InnerException));
                return null;

            }

        }

        public async Task<IEnumerable<SelectListItem>> SelectSanctionNo(long pacsId, long memberId)
        {
            return await _unitOfWork.LoanSanction.SelectSanctionNo(pacsId, memberId);
        }

        #region CURD
        public async Task<bool> Add(LoanSanctionHeaderVM loanSanctionHeader)
        {
            bool status = false;
            try
            {
                var obj = _mapper.Map<LoanSanctionHeader>(loanSanctionHeader);

                obj.SanctionNo = await _unitOfWork.LoanSanction.GetNextNo(obj.PacsId, obj.LoanTypeID);

                await _unitOfWork.LoanSanction.AddAsync(obj);
                status = await _unitOfWork.Commit();
            }
            catch (Exception ex)
            {
                _logger.LogError("Invoked Add in LoanSanctionBL & Object is : " + loanSanctionHeader);
                _logger.LogError("Message is  : " + Convert.ToString("" + ex.Message));
                _logger.LogError("Inner Exception is  : " + Convert.ToString("" + ex.InnerException));

            }
            return status;
        }

        public async Task<bool> Update(LoanSanctionHeaderVM loanSanctionHeader)
        {
            bool status = false;
            try
            {
                var obj = _mapper.Map<LoanSanctionHeader>(loanSanctionHeader);
                _unitOfWork.LoanSanction.Update(obj);
                status = await _unitOfWork.Commit();
            }
            catch (Exception ex)
            {
                _logger.LogError("Invoked Update in LoanSanctionBL & Object is : " + loanSanctionHeader);
                _logger.LogError("Message is  : " + Convert.ToString("" + ex.Message));
                _logger.LogError("Inner Exception is  : " + Convert.ToString("" + ex.InnerException));

            }
            return status;

        }

        public async Task<LoanSanctionHeaderVM> GetById(long Id)
        {
            var obj = await _unitOfWork.LoanSanction.GetFirstOrDefault(c => c.Id == Id, includeProperties: "LoanSanctionDetails");

            foreach (LoanSanctionDetail Item in obj.LoanSanctionDetails)
            {
                Item.VaoDetail = await _unitOfWork.VAOCertificate.GetVaoCertificateDetailById(Item.VaoDetailId);
                obj.LoanSanctionDetails.Add(Item);
            }

            var VM =  _mapper.Map<LoanSanctionHeaderVM>(obj);


            foreach (LoanSanctionDetailVM Item in VM.LoanSanctionDetails)
            {
                var CropName = await _unitOfWork.CropMaster.getCropName(Item.CropId);
                string[] CropNameList = CropName.Split("~");
                Item.CropName = CropNameList[0];
                Item.CropNameInTamil = CropNameList[1];
            }

            return VM;

        }

        public async Task<bool> SoftDelete(long id)
        {
            bool status;
            try
            {
                _unitOfWork.LoanSanction.Remove(id);
                status = await _unitOfWork.Commit();
            }
            catch (Exception ex)
            {
                _logger.LogError("Invoked Update in LoanSanctionBL & Object is : " + id);
                _logger.LogError("Message is  : " + Convert.ToString("" + ex.Message));
                _logger.LogError("Inner Exception is  : " + Convert.ToString("" + ex.InnerException));
                status = false;

            }
            return status;
        }

        public async Task<IEnumerable<ListLoanSanctionVM>> GetList(long pacsId, long fYearId)
        {
            try
            {
                var obj = await _unitOfWork.LoanSanction.GetList(pacsId, fYearId);
                return _mapper.Map<IEnumerable<ListLoanSanctionVM>>(obj);
            }

            catch (Exception ex)
            {
                _logger.LogError("Invoked Add in LoanSanctionBL & Object is : " + fYearId );
                _logger.LogError("Message is  : " + Convert.ToString("" + ex.Message));
                _logger.LogError("Inner Exception is  : " + Convert.ToString("" + ex.InnerException));
                return null;
            }

        }

       

        #endregion
    }
}
