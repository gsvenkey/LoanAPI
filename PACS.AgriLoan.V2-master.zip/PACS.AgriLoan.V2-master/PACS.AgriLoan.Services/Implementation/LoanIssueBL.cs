﻿using AutoMapper;
using Microsoft.Extensions.Logging;
using PACS.AgriLoan.Business.Interface;
using PACS.AgriLoan.Interface.Common;
using PACS.AgriLoan.ViewModel;
using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Services.Implementation
{
    public class LoanIssueBL : ILoanIssueBL
    {
        #region Properties

        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;
        private readonly ILogger<LoanIssueBL> _logger;

        #endregion

        #region Constructor

        public LoanIssueBL(IUnitOfWork unitOfWork, IMapper mapper, ILogger<LoanIssueBL> logger)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
            _logger = logger;
        }



        #endregion

        public async Task<LoanIssueHeaderVM> GetLoanSanctionDetails(long sanctionId)
        {
            var headerVM = new LoanIssueHeaderVM();

            try
            {
                var header = await _unitOfWork.LoanIssue.GetLoanSanctionHeader(sanctionId);
                var Detail = await _unitOfWork.LoanIssue.GetLoanSanctionDetail(sanctionId);
                headerVM = _mapper.Map<LoanIssueHeaderVM>(header);
                if (Detail.Count() > 0)
                {
                    headerVM.LoanIssueDetails = _mapper.Map<ICollection<LoanIssueDetailVM>>(Detail);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("Invoked Add in GetLoanSanctionDetails & Object is : " + sanctionId);
                _logger.LogError("Message is  : " + Convert.ToString("" + ex.Message));
                _logger.LogError("Inner Exception is  : " + Convert.ToString("" + ex.InnerException));

            }
            return headerVM;
        }

        #region CURD
       
        public async Task<bool> Add(LoanIssueHeaderVM loanIssueHeaderVM)
        {
            bool status = false;
            try
            {
                var obj = _mapper.Map<LoanIssueHeader>(loanIssueHeaderVM);
               
                //int SDSCode = 0;
                //long nextRequestNo = 0;
                //string loanTypeCode = "";

                obj.RateOfInterestId = await _unitOfWork.RateOfIntrestMaster.GetRateOfInterestId(obj.LoanTypeID);
                obj.IssueNo = await _unitOfWork.LoanIssue.GetNextNo(obj.PacsId, obj.LoanTypeID);

                //obj.LoanNo = 
                await _unitOfWork.LoanIssue.AddAsync(obj);
                status = await _unitOfWork.Commit();
            }
            catch (Exception ex)
            {
                _logger.LogError("Invoked Add in LoanIssueBL & Object is : " + loanIssueHeaderVM);
                _logger.LogError("Message is  : " + Convert.ToString("" + ex.Message));
                _logger.LogError("Inner Exception is  : " + Convert.ToString("" + ex.InnerException));

            }
            return status;
        }


        public async Task<bool> Update(LoanIssueHeaderVM loanIssueHeaderVM)
        {
            bool status = false;
            try
            {
                var obj = _mapper.Map<LoanIssueHeader>(loanIssueHeaderVM);
                obj.RateOfInterestId = await _unitOfWork.RateOfIntrestMaster.GetRateOfInterestId(obj.LoanTypeID);
                _unitOfWork.LoanIssue.Update(obj);
                status = await _unitOfWork.Commit();
            }
            catch (Exception ex)
            {
                _logger.LogError("Invoked Update in LoanIssueBL & Object is : " + loanIssueHeaderVM);
                _logger.LogError("Message is  : " + Convert.ToString("" + ex.Message));
                _logger.LogError("Inner Exception is  : " + Convert.ToString("" + ex.InnerException));

            }
            return status;

        }



        public async Task<LoanIssueHeaderVM> GetById(long Id)
        {
            var obj = await _unitOfWork.LoanIssue.GetFirstOrDefault(c => c.Id == Id, includeProperties: "LoanIssueDetails");

            foreach (LoanIssueDetail Item in obj.LoanIssueDetails)
            {
                Item.VaoDetail = await _unitOfWork.VAOCertificate.GetVaoCertificateDetailById(Item.VaoDetailId);
                obj.LoanIssueDetails.Add(Item);
            }

            var VM = _mapper.Map<LoanIssueHeaderVM>(obj);


            foreach (LoanIssueDetailVM Item in VM.LoanIssueDetails)
            {
                var CropName = await _unitOfWork.CropMaster.getCropName(Item.CropId);
                string[] CropNameList = CropName.Split("~");
                Item.CropName = CropNameList[0];
                Item.CropNameInTamil = CropNameList[1];
            }

            return VM;
        }

        public async Task<bool> SoftDelete(long id)
        {
            bool status;
            try
            {
                _unitOfWork.LoanIssue.Remove(id);
                status = await _unitOfWork.Commit();
            }
            catch (Exception ex)
            {
                _logger.LogError("Invoked Update in LoanIssueBL & Object is : " + id);
                _logger.LogError("Message is  : " + Convert.ToString("" + ex.Message));
                _logger.LogError("Inner Exception is  : " + Convert.ToString("" + ex.InnerException));
                status = false;

            }
            return status;
        }

        public async Task<IEnumerable<ListLoanIssueVM>> GetList(long pacsId, long fYearId)
        {
            var obj = await _unitOfWork.LoanIssue.GetList(pacsId, fYearId);
            return _mapper.Map<IEnumerable<ListLoanIssueVM>>(obj);
        }


        #endregion
    }
}
