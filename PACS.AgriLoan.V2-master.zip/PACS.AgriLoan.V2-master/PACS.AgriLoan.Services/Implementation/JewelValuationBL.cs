﻿using AutoMapper;
using Microsoft.Extensions.Logging;
using PACS.AgriLoan.Business.Interface;
using PACS.AgriLoan.Interface.Common;
using PACS.AgriLoan.ViewModel;
using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Services.Implementation
{
    public class JewelValuationBL : IJewelValuationBL
    {
        #region Properties

        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;
        private readonly ILogger<JewelValuationBL> _logger;

        #endregion

        #region Constructor

        public JewelValuationBL(IUnitOfWork unitOfWork, IMapper mapper, ILogger<JewelValuationBL> logger)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
            _logger = logger;
        }



        #endregion

        public async Task<bool> Add(JewelValuationVM jewelValuationVM)
        {
            if (jewelValuationVM.Id > 0)
            {
                var obj = _mapper.Map<JewelValuation>(jewelValuationVM);
                await _unitOfWork.JewelValuation.AddAsync(obj);
                return await _unitOfWork.Commit();
            }

            else
            {
                var obj = _mapper.Map<JewelValuation>(jewelValuationVM);
                _unitOfWork.JewelValuation.Update(obj);
                return await _unitOfWork.Commit();
            }

        }

        public async Task<JewelValuationVM> GetJewelValuation(long pacsId)
        {
            var obj = await _unitOfWork.JewelValuation.GetJewelValuation(pacsId);
            if (obj != null)
                return _mapper.Map<JewelValuationVM>(obj);
            else
                return null;
        }

        public async Task<decimal> GetPacsJewelValue(long pacsId)
        {
            return await _unitOfWork.JewelValuation.GetPacsJewelValue(pacsId);
        }
    }
}
