﻿using AutoMapper;
using Microsoft.Extensions.Logging;
using PACS.AgriLoan.Business.Interface;
using PACS.AgriLoan.Interface.Common;
using PACS.AgriLoan.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Services.Implementation
{
    public class ValidationBL : IValidationBL
    {

        #region Properties

        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;
        private readonly ILogger<ValidationBL> _logger;

        #endregion

        #region Constructor

        public ValidationBL(IUnitOfWork unitOfWork, IMapper mapper, ILogger<ValidationBL> logger)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
            _logger = logger;
        }



        #endregion



        public async Task<ValidationVM> ValidateLoanRequest(LoanRequestHeaderVM requestHeaderVM)
        {
            ValidationVM validation = await CommonValidation(requestHeaderVM.LoanTypeID, requestHeaderVM.MemberID, requestHeaderVM.RequestAmount);
            if (validation.IsValid == true)
            {
                switch (requestHeaderVM.LoanTypeID)
                {
                    case 1:
                        long surityMemberId = (from Surity in requestHeaderVM.SuretyDetails select (Surity.MemberId)).FirstOrDefault();
                        validation = await ValidateSurity(requestHeaderVM.PacsId, surityMemberId);
                        break;
                    case 5:
                        List<JlgValidationVM> jlgSurveyDtl = new List<JlgValidationVM>();
                        foreach (var item in requestHeaderVM.LoanRequestDetails)
                        {
                            var SurveyRowItem = new JlgValidationVM();
                            SurveyRowItem.VaoDetailId = item.VaoDetailId;
                            SurveyRowItem.LoanAmount = item.RequestAmount;
                            SurveyRowItem.MemberId = 0;
                            SurveyRowItem.MemberName = "";
                            SurveyRowItem.SurveyNo = 0;
                            SurveyRowItem.SubDivisionNo = "";
                            jlgSurveyDtl.Add(SurveyRowItem);
                        }
                        validation = await ValidateJLGLoan(jlgSurveyDtl);
                        break;
                }
            }
            return validation;
        }

        public async Task<ValidationVM> ValidateLoanSanction(LoanSanctionHeaderVM SanctionHeaderVM)
        {
            ValidationVM validation = await CommonValidation(SanctionHeaderVM.LoanTypeID, SanctionHeaderVM.MemberID, SanctionHeaderVM.SanctionAmount);
            if (validation.IsValid == true)
            {
                switch (SanctionHeaderVM.LoanTypeID)
                {
                    case 2:
                        validation = await ValidateJewelMortgage(SanctionHeaderVM.LoanRequestId, SanctionHeaderVM.SanctionAmount);
                        break;
                    case 3:
                        validation = await ValidateLandMortgage(SanctionHeaderVM.LoanRequestId, SanctionHeaderVM.SanctionAmount);
                        break;
                    case 4:
                        validation = await ValidateTieupLoan(SanctionHeaderVM.LoanRequestId, SanctionHeaderVM.SanctionAmount);
                        break;
                    case 5:
                        List<JlgValidationVM> jlgSurveyDtl = new List<JlgValidationVM>();
                        foreach (var item in SanctionHeaderVM.LoanSanctionDetails)
                        {
                            var SurveyRowItem = new JlgValidationVM();

                            var total = Convert.ToDecimal("0" + item.Cash) + Convert.ToDecimal("0" + item.Pesticide) + Convert.ToDecimal("0" + item.Fertilizer)
                                 + Convert.ToDecimal("0" + item.Seed) + Convert.ToDecimal("0" + item.KindPesticide) + Convert.ToDecimal("0" + item.KindFertilizer)
                                 + Convert.ToDecimal("0" + item.KindSeed);

                            SurveyRowItem.VaoDetailId = item.VaoDetailId;
                            SurveyRowItem.LoanAmount = total;
                            SurveyRowItem.MemberId = 0;
                            SurveyRowItem.MemberName = "";
                            SurveyRowItem.SurveyNo = 0;
                            SurveyRowItem.SubDivisionNo = "";
                            jlgSurveyDtl.Add(SurveyRowItem);
                        }
                        validation = await ValidateJLGLoan(jlgSurveyDtl);
                        break;
                }
            }
            return validation;
        }

        public async Task<ValidationVM> ValidateLoanIssue(LoanIssueHeaderVM loanIssueHeader)
        {
            //var validation = new ValidationVM();
            ValidationVM validation = await CommonValidation(loanIssueHeader.LoanTypeID, loanIssueHeader.MemberID, loanIssueHeader.IssueAmount);
            if (validation.IsValid == true)
            {
                switch (loanIssueHeader.LoanTypeID)
                {
                    case 2:
                        validation = await ValidateJewelMortgage(loanIssueHeader.SanctionId, loanIssueHeader.IssueAmount);
                        break;
                    case 3:
                        validation = await ValidateLandMortgage(loanIssueHeader.SanctionId, loanIssueHeader.IssueAmount);
                        break;
                    case 4:
                        validation = await ValidateTieupLoan(loanIssueHeader.SanctionId, loanIssueHeader.IssueAmount);
                        break;
                    case 5:
                        List<JlgValidationVM> jlgSurveyDtl = new List<JlgValidationVM>();
                        foreach (var item in loanIssueHeader.LoanIssueDetails)
                        {
                            var SurveyRowItem = new JlgValidationVM();

                            var total = Convert.ToDecimal("0" + item.Cash) + Convert.ToDecimal("0" + item.Pesticide) + Convert.ToDecimal("0" + item.Manure)
                                 + Convert.ToDecimal("0" + item.Seed) + Convert.ToDecimal("0" + item.KindPesticide) + Convert.ToDecimal("0" + item.KindFertilizer)
                                 + Convert.ToDecimal("0" + item.KindSeed);

                            SurveyRowItem.VaoDetailId = item.VaoDetailId;
                            SurveyRowItem.LoanAmount = total;
                            SurveyRowItem.MemberId = 0;
                            SurveyRowItem.MemberName = "";
                            SurveyRowItem.SurveyNo = 0;
                            SurveyRowItem.SubDivisionNo = "";
                            jlgSurveyDtl.Add(SurveyRowItem);
                        }
                        validation = await ValidateJLGLoan(jlgSurveyDtl);
                        break;
                }
            }
            return validation;
        }

        #region Private Methods

        private async Task<decimal> GetMaxLimitForLoanType(long loanTypeId)
        {
            return await _unitOfWork.LoanTypeMaster.GetMaxLimit(loanTypeId);
        }

        private async Task<decimal> GetMaxLimitForMember()
        {
            return await _unitOfWork.ApplicationConfiguration.GetMaxLimitPerMember();
        }

        private async Task<decimal> GetJlgMaxLimitPerMember()
        {
            return await _unitOfWork.ApplicationConfiguration.GetJlgMaxLimitPerMember();
        }
        #endregion

        #region Common Validation for All Loans
        private async Task<ValidationVM> CommonValidation(long loanTypeId, long memberId, decimal loanAmount)
        {
            var validation = new ValidationVM();
            var MaxLimitForLoanType = await GetMaxLimitForLoanType(loanTypeId);


            /// Check Max Limit for Loan Type

            if (loanAmount > MaxLimitForLoanType)
            {
                validation.IsValid = false;
                validation.ValidationMessage = "Loan amount should not exceeds maximum limit of Rs. " + Convert.ToString("" + MaxLimitForLoanType);
            }


            if (loanTypeId != 5)
            {
                decimal MaxLimitForMember = await GetMaxLimitForMember();
                long AadharNo = await _unitOfWork.Validation.GetAadharNo(memberId);
                decimal MemberOutstandingByAadhar = await _unitOfWork.Validation.GetMemberOutstandingByAadhar(AadharNo);
                decimal EligibleAmount = MaxLimitForMember - MemberOutstandingByAadhar;
                if (loanAmount > EligibleAmount)
                {
                    validation.IsValid = false;
                    validation.ValidationMessage = "Member has Outstanding of Rs. " + Convert.ToString("" + MemberOutstandingByAadhar) + " . So Loan amount should not exceeds Rs. " + Convert.ToString("0" + (MaxLimitForMember - MemberOutstandingByAadhar));
                }

            }

            if (loanTypeId == 5)
            {
                decimal MemberOutstanding = await _unitOfWork.Validation.GetMemberOutstanding(memberId);
                decimal EligibleAmount = MaxLimitForLoanType - MemberOutstanding;

                if (loanAmount > EligibleAmount)
                {
                    validation.IsValid = false;
                    validation.ValidationMessage = "Member has Outstanding of Rs. " + Convert.ToString("" + MemberOutstanding) + " . So Loan amount should not exceeds Rs. " + Convert.ToString("0" + (MaxLimitForLoanType - MemberOutstanding));
                }
            }



            return validation;



        }


        #endregion

        #region Loan Type == Surity

        private async Task<ValidationVM> ValidateSurity(long pacsId, long surityMemberId)
        {
            var validation = new ValidationVM();
            int count = await _unitOfWork.Validation.CheckSurityCount(pacsId, surityMemberId);
            if (count >= 2)
            {
                validation.IsValid = false;
                validation.ValidationMessage = "Surity Member has exceeded his Surity count of  " + Convert.ToString("" + count);
            }
            return validation;

        }

        #endregion

        #region Loan Type == Jewel Mortgage

        private async Task<ValidationVM> ValidateJewelMortgage(long requestId, decimal loanAmount)
        {
            var validation = new ValidationVM();
            decimal JewelValue = await _unitOfWork.Validation.GetJewelValue(requestId);
            if (loanAmount > JewelValue)
            {
                validation.IsValid = false;
                validation.ValidationMessage = "Jewel Value is   " + Convert.ToString("" + JewelValue) + " Decrease your sanction Limit ";
            }
            return validation;

        }

        #endregion

        #region Loan Type == Land Mortgage

        private async Task<ValidationVM> ValidateLandMortgage(long requestId, decimal loanAmount)
        {
            var validation = new ValidationVM();
            decimal LandValue = await _unitOfWork.Validation.GetLandValue(requestId);
            if (loanAmount > LandValue)
            {
                validation.IsValid = false;
                validation.ValidationMessage = "Land Value is   " + Convert.ToString("" + LandValue) + " Decrease your sanction Limit ";
            }
            return validation;

        }

        #endregion

        #region Loan Type == Tieup Loan

        private async Task<ValidationVM> ValidateTieupLoan(long requestId, decimal loanAmount)
        {
            var validation = new ValidationVM();
            decimal LandValue = await _unitOfWork.Validation.GetLandValue(requestId);
            if (loanAmount > LandValue)
            {
                validation.IsValid = false;
                validation.ValidationMessage = "Tieup Value is   " + Convert.ToString("" + LandValue) + " Decrease your sanction Limit ";
            }
            return validation;
        }

        #endregion

        #region Loan Type == Join Liability Group

        private async Task<ValidationVM> ValidateJLGLoan(List<JlgValidationVM> jlgValidations)
        {
            var validation = new ValidationVM();
            var jlgSurveyDtl = new List<JlgValidationVM>();

            foreach (var item in jlgValidations)
            {
                var SurveyRowItem = new JlgValidationVM();
                SurveyRowItem.LoanAmount = item.LoanAmount;
                SurveyRowItem.VaoDetailId = item.VaoDetailId;

                var memberDetail = await _unitOfWork.Validation.GetSurveyDetail(item.VaoDetailId);

                item.MemberId = memberDetail.MemberId;
                item.MemberName = Convert.ToString("" + memberDetail.MemberNumber) + "-" + memberDetail.Name;
                item.SurveyNo = memberDetail.ServeyNo;
                item.SubDivisionNo = memberDetail.SubDivisionNo;
                item.AdhaarNumber = memberDetail.AdhaarNumber;
                jlgSurveyDtl.Add(SurveyRowItem);
            }


            var Summary = jlgSurveyDtl.GroupBy(x => (x.MemberId, x.MemberName, x.AdhaarNumber))
                                     .Select(g => (g.Key.MemberId, g.Key.MemberName, g.Key.AdhaarNumber, Total: g.Sum(x => x.LoanAmount)));

            StringBuilder sb = new StringBuilder();
            sb.Append("Validation Results");
            foreach (var item in Summary)
            {
                var OutstandingAmt = await _unitOfWork.Validation.GetMemberOutstandingByAadhar(item.AdhaarNumber);
                var MaxLimitForMember = await GetMaxLimitForMember();
                var EligibleAmount = MaxLimitForMember - OutstandingAmt;
                var JlgMaxLimitPerMember = await GetJlgMaxLimitPerMember();
                if (item.Total > EligibleAmount)
                {
                    validation.IsValid = false;


                    var individualDtl = (from member in jlgSurveyDtl.Where(c => c.MemberId == item.MemberId)
                                         select
                                         (
                                         member.MemberName,
                                         member.SurveyNo,
                                         member.SubDivisionNo
                                         )
                                         ).ToList();
                    sb.AppendLine("The following Member has Previous outstanding amount of Rs.");
                    sb.AppendFormat("{0:C} ", OutstandingAmt);
                    sb.AppendLine("His Eligible amount is Rs.");
                    sb.AppendFormat("{0:C} ", EligibleAmount);
                    sb.AppendLine("His Survey Details as Follows.");
                    foreach (var individualitem in individualDtl)
                    {
                        sb.Append(individualitem.MemberName);
                        sb.Append(" Survey No.");
                        sb.Append(individualitem.SurveyNo);
                        sb.Append(" SubDivision No.");
                        sb.Append(individualitem.SubDivisionNo);
                        sb.Append(" SubDivision No.");
                        sb.AppendLine("****************************************************************************");
                        sb.AppendLine();
                        sb.AppendLine();
                    }

                    validation.ValidationMessage = Convert.ToString("" + sb);

                }
                if (item.Total > JlgMaxLimitPerMember)
                {
                    validation.IsValid = false;

                    var individualDtl = (from member in jlgSurveyDtl.Where(c => c.MemberId == item.MemberId)
                                         select
                                         (
                                         member.MemberName,
                                         member.SurveyNo,
                                         member.SubDivisionNo
                                         )
                                         ).ToList();
                    sb.AppendLine("The following Member has Exceeding Limit of JLG Rs.");
                    sb.AppendFormat("{0:C} ", item.Total);
                    sb.AppendLine("His Eligible amount is Rs.");
                    sb.AppendFormat("{0:C} ", JlgMaxLimitPerMember);
                    sb.AppendLine("His Survey Details as Follows.");
                    foreach (var individualitem in individualDtl)
                    {
                        sb.Append(individualitem.MemberName);
                        sb.Append(" Survey No.");
                        sb.Append(individualitem.SurveyNo);
                        sb.Append(" SubDivision No.");
                        sb.Append(individualitem.SubDivisionNo);
                        sb.Append(" SubDivision No.");
                        sb.AppendLine("****************************************************************************");
                        sb.AppendLine();
                        sb.AppendLine();
                    }

                    validation.ValidationMessage = Convert.ToString("" + sb);
                }
            }


            return validation;
        }

        #endregion
    }

}
