﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc.Rendering;
using PACS.AgriLoan.Business.Interface;
using PACS.AgriLoan.Interface.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Services.Implementation
{
    public class CropCategoryBL : ICropCategoryBL
    {
        #region Properties

        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;

        #endregion

        #region Constructor

        public CropCategoryBL(IUnitOfWork unitOfWork, IMapper mapper)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
        }

       



        #endregion



        public async Task<IEnumerable<SelectListItem>> SelectCropCategory()
        {
            return await _unitOfWork.CropCategory.SelectCropCategory();
        }


        public async Task<long> getCropCategoryId(long cropId)
        {
            return await _unitOfWork.CropCategory.getCropCategoryId(cropId);
        }

    }
}
