﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using PACS.AgriLoan.Business.Interface;
using PACS.AgriLoan.Interface.Common;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Services.Implementation
{
    public class LoanTypeMasterBL : ILoanTypeMasterBL
    {
        #region Properties

        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;
        private readonly ILogger<LoanTypeMasterBL> _logger;

        #endregion

        #region Constructor

        public LoanTypeMasterBL(IUnitOfWork unitOfWork, IMapper mapper, ILogger<LoanTypeMasterBL> logger)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
            _logger = logger;
        }

        #endregion

        public async Task<IEnumerable<SelectListItem>> SelectLoanType()
        {
            return await _unitOfWork.LoanTypeMaster.SelectLoanType();
        }

        public async Task<decimal> GetMaxLimit(long LoanTypeId)
        {
           return await _unitOfWork.LoanTypeMaster.GetMaxLimit(LoanTypeId);
        }
    }
}
