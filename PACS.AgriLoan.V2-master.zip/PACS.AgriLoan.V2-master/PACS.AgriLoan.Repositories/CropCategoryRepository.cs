﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using PACS.AgriLoan.Interface;
using PACS.AgriLoan.Repositories.Common;
using PACS.AgriLoan.Repositories.DbContext;
using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Repositories
{
   public class CropCategoryRepository : GenericRepository<CropCategory>, ICropCategoryRepository
    {
        private readonly AppDbContext _db;

        public CropCategoryRepository(AppDbContext db) : base(db)
        {
            _db = db;
        }

        public async Task<long> getCropCategoryId(long cropId)
        {
            return await (
               from category in _db.CropCategories
               join crop in _db.CropMasters on category.Id equals crop.CategoryId
               where crop.Id == cropId
               select category.Id
               ).FirstOrDefaultAsync();
        }

        public async Task<IEnumerable<SelectListItem>> SelectCropCategory()
        {
            return await _db.CropCategories.AsNoTracking().Where(c => c.IsDeleted == false).OrderBy(n => n.Name)
                 .Select(n => new SelectListItem
                 {
                     Value = n.Id.ToString(),
                     Text = n.Name
                 }).ToListAsync();
        }

        public async Task<IEnumerable<SelectListItem>> SelectCropCategory(long pacsId)
        {
            return await (
                            from category in _db.CropCategories where category.IsDeleted == false
                            join crop in _db.CropMasters on category.Id equals crop.CategoryId where crop.IsDeleted == false
                            join Ratio in _db.LoanRatioMasters on crop.Id equals Ratio.CropId where crop.IsDeleted == false
                            join district in _db.DistrictMasters on Ratio.DistrictId equals district.Id where district.IsDeleted == false
                            join pacs in _db.PacsMasters on district.Id equals pacs.DistrictId where pacs.Id == pacsId
                            select new SelectListItem
                            {
                                Value = crop.Id.ToString(),
                                Text = crop.Name
                            }
                        ).ToListAsync();
        }

        public async Task<string> getCropCategoryByCropId(long cropId)
        {
            return await (from cropCat in _db.CropCategories
                          join crop in _db.CropMasters on cropCat.Id equals crop.CategoryId
                          where crop.Id == cropId
                          select (
                          Convert.ToString("" + cropCat.Id ) + '~'+ cropCat.Name + '~' + cropCat.NameInTamil)
                          ).FirstOrDefaultAsync();
        }
    }
}
