﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using PACS.AgriLoan.Interface;
using PACS.AgriLoan.Repositories.Common;
using PACS.AgriLoan.Repositories.DbContext;
using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Repositories
{
    public class LookUpCodeMasterRepository : GenericRepository<LookupCodeMaster>, ILookUpCodeMasterRepository
    {
        private readonly AppDbContext _db;

        public LookUpCodeMasterRepository(AppDbContext db) : base(db)
        {
            _db = db;
        }

        public async Task<IEnumerable<SelectListItem>> SelectLookUp(string lookUpCode)
        {
            return await _db.VW_LookUpMasters.AsNoTracking().Where(c => c.Code.ToUpper() == lookUpCode.ToUpper() ).OrderBy(n => n.Name)
                .Select(n => new SelectListItem
                {
                    Value = n.Id.ToString(),
                    Text = n.Name
                }).ToListAsync();
        }

        public async Task<IEnumerable<SelectListItem>> SelectLookUpInTamil(string lookUpCode)
        {
            return await _db.VW_LookUpMasters.AsNoTracking().Where(c => c.Code.ToUpper() == lookUpCode.ToUpper()).OrderBy(n => n.Name)
                .Select(n => new SelectListItem
                {
                    Value = n.Id.ToString(),
                    Text = n.Name
                }).ToListAsync();
        }
    }
}
