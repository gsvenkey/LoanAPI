﻿using Microsoft.EntityFrameworkCore;
using PACS.AgriLoan.Interface;
using PACS.AgriLoan.Repositories.DbContext;
using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Repositories
{
    public class ValidationRepository : IValidationRepository
    {
        private readonly AppDbContext _db;

        public ValidationRepository(AppDbContext db)
        {
            _db = db;
        }

        public async Task<int> CheckSurityCount(long pacsId, long surityMemberId)
        {
            return await _db.VW_OutStandingSurities.Where(p => p.pacsId == pacsId && p.SurityMemberId == surityMemberId).CountAsync() ;
        }

        public async Task<long> GetAadharNo(long memberId)
        {
            return await _db.MemberMasters.Where(r => r.Id == memberId).Select(c => c.AdhaarNumber).FirstOrDefaultAsync();
        }

        public async Task<decimal> GetJewelValue(long requestId)
        {
            return await _db.JewelPledgedDetails.Where(r => r.LoanRequestId == requestId && r.IsDeleted == false).Select(c => Convert.ToDecimal("0.00" + c.EstimationValue)).SumAsync();
        }

        public async Task<decimal> GetLandValue(long requestId)
        {
            return await _db.LandPledgedDetails.Where(r => r.LoanRequestId == requestId && r.IsDeleted == false).Select(c => Convert.ToDecimal("0.00" + c.MortgageAmount)).FirstOrDefaultAsync();
        }

        public async Task<decimal> GetMemberOutstanding(long memberId)
        {
            return await _db.VW_TotalLoanOutStandings.Where(r => r.MemberId == memberId).Select(c => c.IssueAmount).SumAsync();
        }

        public async Task<decimal> GetMemberOutstandingByAadhar(long aadharNo)
        {
            return await _db.VW_MemberWiseOutstandingDetails.Where(r => r.AdhaarNumber == aadharNo).Select(c => Convert.ToDecimal("0.00" + c.IssueAmount)).SumAsync();
        }

        public async Task<VW_GetSurveyDetailsForJlg> GetSurveyDetail(long vaoDetailId)
        {
            return await _db.VW_GetSurveyDetailsForJlgs.Where(r => r.VaoDetailId == vaoDetailId).FirstOrDefaultAsync();
        }

        public async Task<decimal> GetTieupValue(long requestId)
        {
            return await _db.TieUpCompanyDetails.Where(r => r.LoanRequestId == requestId && r.IsDeleted == false).Select(c => Convert.ToDecimal("0.00" + c.MaximumLoanAmount)).FirstOrDefaultAsync();
        }
    }
}
