﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using PACS.AgriLoan.Interface;
using PACS.AgriLoan.Interface.Common;
using PACS.AgriLoan.Repositories.Common;
using PACS.AgriLoan.Repositories.DbContext;
using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Repositories
{
    public class SubRegisterOfficeRepository : GenericRepository<SubRegisterMaster>, ISubRegisterOfficeRepository
    {
        private readonly AppDbContext _db;

        public SubRegisterOfficeRepository(AppDbContext db) : base(db)
        {
            _db = db;
        }

        public async Task<IEnumerable<SelectListItem>> SelectSubRegsterDistrict(long pacsId)
        {
            return await (
               from District in _db.SubRegisterDistrictMasters
               join zone in _db.ZoneMasters on District.ZoneMasterId equals zone.Id
               join pacs in _db.PacsMasters on zone.Id equals pacs.ZoneId
               where pacs.Id == pacsId && District.IsDeleted == false && zone.IsDeleted == false


               select new SelectListItem
               {
                   Value = District.Id.ToString(),
                   Text = District.NameInTamil
               }


              ).ToListAsync();
        }

        public async Task<IEnumerable<SelectListItem>> SelectSubRegsterOffice(long subRegsterDistrictId)
        {
            return await _db.SubRegisterMasters.AsNoTracking().Where(c => c.IsDeleted == false && c.SubRegisterDistrictId == subRegsterDistrictId).OrderBy(n => n.NameInTamil)
              .Select(n => new SelectListItem
              {
                  Value = n.Id.ToString(),
                  Text = n.NameInTamil
              }).ToListAsync();
        }
    }
}
 
