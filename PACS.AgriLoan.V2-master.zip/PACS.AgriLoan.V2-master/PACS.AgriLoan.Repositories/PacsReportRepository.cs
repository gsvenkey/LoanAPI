﻿using Microsoft.EntityFrameworkCore;
using PACS.AgriLoan.Interface;
using PACS.AgriLoan.Repositories.DbContext;
using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Repositories
{
   public class PacsReportRepository : IPacsReportRepository
    {
        private readonly AppDbContext _db;

        public PacsReportRepository(AppDbContext db) 
        {
            _db = db;
        }

        public async Task<VW_Rpt_IssueSummary> RptIssueSummary(long issueId)
        {
            return await _db.VW_Rpt_IssueSummaries.Where(c => c.Id == issueId).FirstOrDefaultAsync();
        }
    }
}
