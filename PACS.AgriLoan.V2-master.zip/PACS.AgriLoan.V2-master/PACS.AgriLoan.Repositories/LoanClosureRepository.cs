﻿using Microsoft.EntityFrameworkCore;
using PACS.AgriLoan.Interface;
using PACS.AgriLoan.Repositories.Common;
using PACS.AgriLoan.Repositories.DbContext;
using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Repositories
{
    public class LoanClosureRepository : GenericRepository<LoanClosure>, ILoanClosureRepository
    {
        private readonly AppDbContext _db;

        public LoanClosureRepository(AppDbContext db) : base(db)
        {
            _db = db;
        }

        public async Task<bool> IsExist(long Id)
        {
			return await _db.LoanClosures.AnyAsync(i => i.Id == Id);
        }

        
    }
}
