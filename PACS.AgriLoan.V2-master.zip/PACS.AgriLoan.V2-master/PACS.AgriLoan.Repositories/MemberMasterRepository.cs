﻿using Microsoft.AspNetCore.Mvc.Rendering;
using PACS.AgriLoan.Interface;
using PACS.AgriLoan.Repositories.Common;
using PACS.AgriLoan.Repositories.DbContext;
using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using System.IO;

namespace PACS.AgriLoan.Repositories
{
    public class MemberMasterRepository : GenericRepository<MemberMaster>, IMemberMasterRepository
    {
        private readonly AppDbContext _db;

        public MemberMasterRepository(AppDbContext db) : base(db)
        {
            _db = db;
        }

        public async Task<VW_GetMemberInfo> GetMemberInfo(long Id)
        {
            return await _db.VW_GetMemberInfos.AsNoTracking().Where(c => c.Id == Id).FirstOrDefaultAsync();
        }

        public async Task<IEnumerable<SelectListItem>> SelectMember(long pacsId, bool IsJlg)
        {
            return await _db.MemberMasters.AsNoTracking().Where(c => c.PacsId == pacsId && c.IsJointLiabilityGroupMember == IsJlg &&
            c.IsDeleted == false).OrderBy(n => n.MemberNumber).ThenBy(n => n.Name)
                .Select(n => new SelectListItem
                {
                    Value = n.Id.ToString(),
                    Text = n.MemberNumber + " - " + n.Name
                }).ToListAsync();

        }

        public async Task<IEnumerable<SelectListItem>> SelectJlgMember(long pacsId)
        {
            return await _db.MemberMasters.AsNoTracking().Where(c => c.PacsId == pacsId && c.IsJointLiabilityGroupMember == true 
                            && c.IsDeleted == false).OrderBy(n => n.MemberNumber).ThenBy(n => n.Name)
                .Select(n => new SelectListItem
                {
                    Value = n.Id.ToString(),
                    Text = n.MemberNumber + " - " + n.Name
                }).ToListAsync();

        }

        public async Task<IEnumerable<SelectListItem>> SelectAllMember(long pacsId)
        {
            return await _db.MemberMasters.AsNoTracking().Where(c => c.PacsId == pacsId 
                            && c.IsDeleted == false).OrderBy(n => n.MemberNumber).ThenBy(n => n.Name)
                .Select(n => new SelectListItem
                {
                    Value = n.Id.ToString(),
                    Text = n.MemberNumber + " - " + n.Name
                }).ToListAsync();

        }

        public async Task<string> UploadFileToBlobAsync(long Id, string strFileName, byte[] fileData, string fileMimeType)
        {
            try
            {

                CloudStorageAccount cloudStorageAccount = CloudStorageAccount.Parse(AppConfiguration.GetConfiguration("PhotoBlob"));
                CloudBlobClient cloudBlobClient = cloudStorageAccount.CreateCloudBlobClient();
                string strContainerName = "photos";
                CloudBlobContainer cloudBlobContainer = cloudBlobClient.GetContainerReference(strContainerName);
                string fileName = this.GenerateFileName(Id, strFileName);

                if (await cloudBlobContainer.CreateIfNotExistsAsync())
                {
                    await cloudBlobContainer.SetPermissionsAsync(new BlobContainerPermissions { PublicAccess = BlobContainerPublicAccessType.Blob });
                }

                if (fileName != null && fileData != null)
                {
                    CloudBlockBlob cloudBlockBlob = cloudBlobContainer.GetBlockBlobReference(fileName);
                    cloudBlockBlob.Properties.ContentType = fileMimeType;
                    await cloudBlockBlob.UploadFromByteArrayAsync(fileData, 0, fileData.Length);
                    return cloudBlockBlob.Uri.AbsoluteUri;
                }
                return "";
            }
            catch (Exception)
            {
                throw;
            }
        }

        private string GenerateFileName(long Id, string fileName)
        {
            string[] strName = fileName.Split('.');
            string strFileName = Convert.ToString("" + Id) + "." + strName[strName.Length - 1];
            return strFileName;
        }

        public async void DeleteBlobData(string fileUrl)
        {
            Uri uriObj = new Uri(fileUrl);
            string BlobName = Path.GetFileName(uriObj.LocalPath);

            CloudStorageAccount cloudStorageAccount = CloudStorageAccount.Parse(AppConfiguration.GetConfiguration("PhotoBlob"));
            CloudBlobClient cloudBlobClient = cloudStorageAccount.CreateCloudBlobClient();
            string strContainerName = "photos";
            CloudBlobContainer cloudBlobContainer = cloudBlobClient.GetContainerReference(strContainerName);

            string pathPrefix = DateTime.Now.ToUniversalTime().ToString("yyyy-MM-dd") + "/";
            CloudBlobDirectory blobDirectory = cloudBlobContainer.GetDirectoryReference(pathPrefix);
            // get block blob refarence  
            CloudBlockBlob blockBlob = blobDirectory.GetBlockBlobReference(BlobName);

            // delete blob from container      
            await blockBlob.DeleteAsync();
        }
    }
}
