﻿using Microsoft.EntityFrameworkCore;
using PACS.AgriLoan.Interface;
using PACS.AgriLoan.Repositories.Common;
using PACS.AgriLoan.Repositories.DbContext;
using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Repositories
{
    public class JewelValuationRepository : GenericRepository<JewelValuation>, IJewelValuationRepository
    {

        private readonly AppDbContext _db;

        public JewelValuationRepository(AppDbContext db) : base(db)
        {
            _db = db;
        }

        public async Task<JewelValuation> GetJewelValuation(long pacsId)
        {
            return await _db.JewelValuations.AsNoTracking().Where(c => c.PacsId == pacsId && c.PriceDate == DateTime.Today).FirstOrDefaultAsync();
        }

        public async Task<decimal> GetPacsJewelValue(long pacsId)
        {
            return await _db.JewelValuations.AsNoTracking().Where(c => c.PacsId == pacsId
           //&& c.PriceDate == DateTime.Today
           ).Select(p => p.PacsValue).FirstOrDefaultAsync();
        }

        public void Update(JewelValuation entity)
        {
            if (entity == null)
            {
                throw new ArgumentNullException(nameof(entity));
            }
            try
            {
                GetEntities().Update(entity);
            }
            catch (Exception ex)
            {
                ex.ToString();
            }
        }
    }
}
