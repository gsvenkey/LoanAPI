﻿using Microsoft.EntityFrameworkCore;
using PACS.AgriLoan.Interface;
using PACS.AgriLoan.Repositories.Common;
using PACS.AgriLoan.Repositories.DbContext;
using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Repositories
{
    public class VAOCertificateRepository : GenericRepository<VaoCertificateHeader>, IVAOCertificateRepository
    {
        private readonly AppDbContext _db;

        public VAOCertificateRepository(AppDbContext db) : base(db)
        {
            _db = db;
        }

        public Task<IEnumerable<VW_GetSurveyDetail>> GetJlgMemberServeyDetails(long jlgMemberId)
        {
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<VW_GetSurveyDetail>> GetSurveyDetails(long memberId)
        {
            return await _db.VW_GetSurveyDetails.AsNoTracking().Where(c => c.MemberId == memberId).ToListAsync();
        }

        public void Update(VaoCertificateHeader entity)
        {
            if (entity == null)
            {
                throw new ArgumentNullException(nameof(entity));
            }
            try
            {
                GetEntities().Update(entity);
            }
            catch (Exception ex)
            {
                ex.ToString();
            }
        }

        public async Task<VaoCertificateDetail> GetVaoCertificateDetailById(long Id)
        {
            return await _db.VaoCertificateDetails.FindAsync(Id);
        }

        public async Task<IEnumerable<VW_VaoCertificateDetail>> GetList(long pacsId)
        {
            return await _db.VW_VaoCertificateDetails.AsNoTracking().Where(c => c.PacsId == pacsId ).ToListAsync();
        }
    }
}
