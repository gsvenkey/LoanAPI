﻿using Microsoft.EntityFrameworkCore;
using PACS.AgriLoan.Interface;
using PACS.AgriLoan.Repositories.Common;
using PACS.AgriLoan.Repositories.DbContext;
using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Repositories
{
    public class VAOCertificateRepository : GenericRepository<VaoCertificateHeader>, IVAOCertificateRepository
    {
        private readonly AppDbContext _db;


        public VAOCertificateRepository(AppDbContext db) : base(db)
        {
            _db = db;
        }

        public async Task<IEnumerable<VW_GetSurveyDetail>> GetSurveyDetails(long memberId)
        {
            return await _db.VW_GetSurveyDetails.AsNoTracking().Where(c => c.MemberId == memberId).ToListAsync();
        }

        
    }
}
