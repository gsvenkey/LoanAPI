﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Repositories.DbContext
{
    public static class AppConfiguration
    {
        
        public static string GetConfiguration(string config)
        {
            string c = Directory.GetCurrentDirectory();
            IConfigurationRoot configuration = new ConfigurationBuilder().SetBasePath(c).AddJsonFile("appsettings.json").Build();
            var connectionStringIs = configuration.GetConnectionString(config);
            return connectionStringIs;
        }
    }
}
