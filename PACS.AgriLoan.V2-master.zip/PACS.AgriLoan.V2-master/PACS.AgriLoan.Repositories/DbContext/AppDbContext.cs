﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Repositories.DbContext
{
    public  class AppDbContext : PACSContext
	{
		public AppDbContext()
		{

		}

		public AppDbContext(DbContextOptions<PACSContext> options)
			: base(options)
		{
		}

		//[DbFunction("fn_GetLoanRequestNextNo", "dbo")]
		//public static long GetLoanRequestNextNo(long pacsId, long loanTypeId)
		//{
		//	throw new NotImplementedException();
		//}


		//public DbQuery<MemberMaster> dbQuery { get; set; }


		protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
		{
			if (!optionsBuilder.IsConfigured)
			{
				//#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
				optionsBuilder.UseSqlServer(AppConfiguration.GetConfiguration("agriLoanDb"));
            }
		}

		public override int SaveChanges()
		{
			foreach (var entry in ChangeTracker.Entries())
			{
				var entity = entry.Entity;
				if (entry.State == EntityState.Added)
				{
					entry.State = EntityState.Modified;
					entity.GetType().GetProperty("CreatedDate").SetValue(entity, DateTime.Now);
					entity.GetType().GetProperty("IsDeleted").SetValue(entity, false);
					entity.GetType().GetProperty("ModifiedDate").SetValue(entity, null);
					entity.GetType().GetProperty("ModifiedBy").SetValue(entity, null);
				}

				if (entry.State == EntityState.Modified)
				{
					 
					entity.GetType().GetProperty("IsDeleted").SetValue(entity, false);
					entity.GetType().GetProperty("ModifiedDate").SetValue(entity, DateTime.Now);
				}

				if (entry.State == EntityState.Deleted)
				{
					entry.State = EntityState.Modified;
					entity.GetType().GetProperty("IsDeleted").SetValue(entity, true);
					entity.GetType().GetProperty("ModifiedDate").SetValue(entity, DateTime.Now);
				}
			}
			return base.SaveChanges();

		}

		public override Task<int> SaveChangesAsync(bool acceptAllChangesOnSuccess, CancellationToken cancellationToken = default)
		{
			foreach (var entry in ChangeTracker.Entries())
			{
				var entity = entry.Entity;
				if (entry.State == EntityState.Added)
				{
					entity.GetType().GetProperty("CreatedDate").SetValue(entity, DateTime.Now);
					entity.GetType().GetProperty("IsDeleted").SetValue(entity, false);
					entity.GetType().GetProperty("ModifiedDate").SetValue(entity, null);
					entity.GetType().GetProperty("ModifiedBy").SetValue(entity, null);
				}

				if (entry.State == EntityState.Modified)
				{
				 
					entity.GetType().GetProperty("IsDeleted").SetValue(entity, false);
					entity.GetType().GetProperty("ModifiedDate").SetValue(entity, DateTime.Now);
				}

				if (entry.State == EntityState.Deleted)
				{
					entry.State = EntityState.Modified;
					entity.GetType().GetProperty("IsDeleted").SetValue(entity, true);
					entity.GetType().GetProperty("ModifiedDate").SetValue(entity, DateTime.Now);
				}
			}
			return base.SaveChangesAsync(acceptAllChangesOnSuccess, cancellationToken);
		}
	}
}
