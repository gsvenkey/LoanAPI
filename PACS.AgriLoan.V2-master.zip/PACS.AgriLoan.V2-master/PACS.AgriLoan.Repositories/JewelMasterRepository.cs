﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using PACS.AgriLoan.Interface;
using PACS.AgriLoan.Repositories.Common;
using PACS.AgriLoan.Repositories.DbContext;
using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Repositories
{
    public class JewelMasterRepository : GenericRepository<JewelMaster>, IJewelMasterRepository
    {
        private readonly AppDbContext _db;

        public JewelMasterRepository(AppDbContext db) : base(db)
        {
            _db = db;
        }

         

        public async Task<IEnumerable<SelectListItem>> SelectJewel()
        {
            return await _db.JewelMasters.AsNoTracking().Where(c => c.IsDeleted == false).OrderBy(n => n.Name)
               .Select(n => new SelectListItem
               {
                   Value = n.Id.ToString(),
                   Text = n.NameInTamil
               }).ToListAsync();
        }
    }
}
