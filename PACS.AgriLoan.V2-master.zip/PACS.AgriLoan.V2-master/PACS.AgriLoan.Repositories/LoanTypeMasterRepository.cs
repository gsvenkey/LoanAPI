﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using PACS.AgriLoan.Interface;
using PACS.AgriLoan.Repositories.Common;
using PACS.AgriLoan.Repositories.DbContext;
using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Repositories
{
   public class LoanTypeMasterRepository : GenericRepository<LoanTypeMaster>, ILoanTypeMasterRepository
    {
        private readonly AppDbContext _db;

        public LoanTypeMasterRepository(AppDbContext db) : base(db)
        {
            _db = db;
        }

        public async Task<IEnumerable<SelectListItem>> SelectLoanType()
        {
            return await _db.LoanTypeMasters.AsNoTracking().Where(c => c.IsDeleted == false).OrderBy(n => n.Name)
                 .Select(n => new SelectListItem
                 {
                     Value = n.Id.ToString(),
                     Text = n.Name
                 }).ToListAsync();
        }

        public async Task<IEnumerable<SelectListItem>> SelectLoanTypeInTamil()
        {
            return await _db.LoanTypeMasters.AsNoTracking().Where(c => c.IsDeleted == false).OrderBy(n => n.NameInTamil)
                .Select(n => new SelectListItem
                {
                    Value = n.Id.ToString(),
                    Text = n.NameInTamil
                }).ToListAsync();
        }
    }
}
