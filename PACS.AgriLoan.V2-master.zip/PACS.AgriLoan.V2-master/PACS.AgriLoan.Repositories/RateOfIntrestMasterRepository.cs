﻿using PACS.AgriLoan.Interface;
using PACS.AgriLoan.Repositories.Common;
using PACS.AgriLoan.Repositories.DbContext;
using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.EntityFrameworkCore;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Repositories
{
    public class RateOfIntrestMasterRepository : GenericRepository<RateOfIntrestMaster>, IRateOfIntrestMasterRepository
    {
        private readonly AppDbContext _db;

        public RateOfIntrestMasterRepository(AppDbContext db) : base(db)
        {
            _db = db;
        }

        public async Task<long> GetRateOfInterestId(long loanTypeId)
        {
            return await  _db.VW_GetCurrentRateOfInterests.Where(c => c.LoanTypeId == loanTypeId).Select(p => p.Id).FirstOrDefaultAsync();
        }
    }
}
