﻿using Microsoft.EntityFrameworkCore;
using PACS.AgriLoan.Interface;
using PACS.AgriLoan.Repositories.Common;
using PACS.AgriLoan.Repositories.DbContext;
using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Repositories
{
    public class LoanRequestRepository :  GenericRepository<LoanRequestHeader>, ILoanRequestRepository
    {
        private readonly AppDbContext _db;

        public LoanRequestRepository(AppDbContext db) : base(db)
        {
            _db = db;
        }

        public async Task<IEnumerable<VW_ListLoanRequest>> GetList(long pacsId, long fYearId)
        {
            return await _db.VW_ListLoanRequests.AsNoTracking().Where(c => c.PacsId == pacsId && c.FYearId == fYearId).ToListAsync();
        }

        public void Update(LoanRequestHeader entity)
        {
            if (entity == null)
            {
                throw new ArgumentNullException(nameof(entity));
            }
            try
            {
                GetEntities().Update(entity);
            }
            catch (Exception ex)
            {
                ex.ToString();
            }
        }
    }
}
