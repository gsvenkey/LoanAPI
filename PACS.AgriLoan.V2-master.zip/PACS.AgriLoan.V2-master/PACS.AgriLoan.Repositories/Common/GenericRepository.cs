﻿using Microsoft.EntityFrameworkCore;
using PACS.AgriLoan.Interface.Common;
using PACS.AgriLoan.Repositories.DbContext;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Repositories.Common
{
    public partial class GenericRepository<TEntity> : IGenericRepository<TEntity> where TEntity : class
    {
        #region Fields
        private readonly AppDbContext _db;
        internal DbSet<TEntity> dbSet;
        #endregion

        #region Constructor
        public GenericRepository(AppDbContext db)
        {
            _db = db;
            this.dbSet = _db.Set<TEntity>();
        }
        #endregion

        #region Methods

        public virtual async Task<TEntity> GetByIdsync(object id)
        {
            return await GetEntities().FindAsync(id);
        }

        public async Task<TEntity> GetFirstOrDefault(Expression<Func<TEntity, bool>> filter = null, string includeProperties = null)
        {
            IQueryable<TEntity> query = dbSet;

            if (filter != null)
            {
                query = query.Where(filter);
            }

            if (includeProperties != null)
            {
                foreach (var includeProp in includeProperties.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    query = query.Include(includeProp);
                }
            }
            return await query.AsTracking().FirstOrDefaultAsync();
        }

        public IEnumerable<TEntity> GetAll(Expression<Func<TEntity, bool>> filter = null, Func<IQueryable<TEntity>, IOrderedQueryable<TEntity>> orderBy = null, string includeProperties = null)
        {
            IQueryable<TEntity> query = dbSet;

            if (filter != null)
            {
                query = query.Where(filter);
            }

            if (includeProperties != null)
            {
                foreach (var includeProp in includeProperties.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    query = query.Include(includeProp);
                }
            }

            return orderBy != null ? orderBy(query).AsNoTracking().ToList() : query.AsNoTracking().ToList();
        }

        public async Task<IEnumerable<TEntity>> GetAllsync(Expression<Func<TEntity, bool>> filter = null, Func<IQueryable<TEntity>, IOrderedQueryable<TEntity>> orderBy = null, string includeProperties = null)
        {
            IQueryable<TEntity> query = dbSet;

            if (filter != null)
            {
                query = query.Where(filter);
            }

            if (includeProperties != null)
            {
                foreach (var includeProp in includeProperties.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    query = query.Include(includeProp);
                }
            }

            return orderBy != null ? await orderBy(query).AsNoTracking().ToListAsync() : await query.AsNoTracking().ToListAsync();
        }

        public virtual async Task AddAsync(TEntity entity)
        {
            if (entity == null)
            {
                throw new ArgumentNullException(nameof(entity));
            }
            await GetEntities().AddAsync(entity);
        }
       
        public virtual async Task AddAsync(IEnumerable<TEntity> entities)
        {
            if (entities == null)
            {
                throw new ArgumentNullException(nameof(entities));
            }
            await GetEntities().AddRangeAsync(entities);
        }

        public void Attach(TEntity entity)
        {
            GetEntities().Attach(entity);
        }

        public void AttachRange(IEnumerable<TEntity> entities)
        {
            GetEntities().AttachRange(entities);
        }

        public virtual void Remove(long id)
        {
            TEntity entity = GetEntities().Find(id);
            Remove(entity);
        }

        public void Remove(TEntity entities)
        {
            if (entities == null)
            {
                throw new ArgumentNullException(nameof(entities));
            }
            GetEntities().Remove(entities);
        }
       
        public virtual void RemoveRange(IEnumerable<TEntity> entities)
        {
            GetEntities().RemoveRange(entities);
        }

        public IQueryable<TEntity> Get(Expression<Func<TEntity, bool>> filter = null, Func<IQueryable<TEntity>, IOrderedQueryable<TEntity>> orderBy = null, string includeProperties = "")
        {
            IQueryable<TEntity> query = GetEntities();

            if (filter != null)
            {
                query = query.Where(filter);
            }

            if (includeProperties != null)
            {
                foreach (var includeProperty in includeProperties.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries))
                {
                    query = query.Include(includeProperty);
                }
            }

            if (orderBy != null)
            {
                return orderBy(query).AsNoTracking();
            }
            else
            {
                return query.AsNoTracking();
            }
        }
       
        public IQueryable<TEntity> GetWithRawSql(string query, params object[] parameters)
        {
            return GetEntities().FromSqlRaw(query, parameters);
        }

       

        #endregion

        #region Properties

        /// <summary>
        /// Gets a table
        /// </summary>
        public virtual IQueryable<TEntity> Table => GetEntities();

        /// <summary>
        /// Gets a table with "no tracking" enabled (EF feature) Use it only when you load record(s) only for read-only operations
        /// </summary>
        public virtual IQueryable<TEntity> TableNoTracking => GetEntities().AsNoTracking();

        /// <summary>
        /// Gets an entity set
        /// </summary>
        protected virtual DbSet<TEntity> GetEntities()
        {
            if (dbSet == null)
            {
                dbSet = _db.Set<TEntity>();
            }

            return dbSet;
        }












        #endregion

    }
}
