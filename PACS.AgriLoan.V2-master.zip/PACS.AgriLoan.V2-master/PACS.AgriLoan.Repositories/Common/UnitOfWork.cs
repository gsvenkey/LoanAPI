﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using PACS.AgriLoan.ILogger.SeriLog;
using PACS.AgriLoan.Interface;
using PACS.AgriLoan.Interface.Common;
using PACS.AgriLoan.Repositories.DbContext;
using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity.Validation;
//using System.Data.Entity.Validation;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Repositories.Common
{
    public class UnitOfWork : IUnitOfWork
    {
        private readonly AppDbContext _db;

        #region Master

        public IApplicationConfigurationRepository ApplicationConfiguration { get; private set; }
        public IDistrictMasterRepository DistrictMaster { get; private set; }
        public ITalukMasterRepository TalukMaster { get; private set; }
        public IFirkaMasterRepository FirkaMaster { get; private set; }
        public IRevenueVillageMasterRepository RevenueVillageMaster { get; private set; }
        public ICropCategoryRepository CropCategory { get; private set; }
        public ICropMasterRepository CropMaster { get; private set; }
        public ILookUpCodeMasterRepository LookUpCodeMaster { get; private set; }
        public ILoanTypeMasterRepository LoanTypeMaster { get; private set; }
        public ISubRegisterOfficeRepository SubRegisterOffice { get; private set; }
        public IJewelMasterRepository JewelMaster { get; private set; }
        public ILoanRatioMasterRepository LoanRatioMaster { get; private set; }
        public IRateOfIntrestMasterRepository RateOfIntrestMaster { get; private set; }


        #endregion

        #region Transactions

        public IMemberMasterRepository MemberMaster { get; private set; }
        public IVAOCertificateRepository VAOCertificate { get; private set; }
        public ILoanRequestRepository LoanRequest { get; private set; }
        public ILoanSanctionRepository LoanSanction { get; private set; }
        public ILoanIssueRepository LoanIssue { get; private set; }
        public ITieUpCompanyMasterRepository TieUpCompanyMaster { get; private set; }
        public IJlgRepository Jlg { get; private set; }
        public ILoanReceiptHeaderRepository loanReceipt { get; private set; }
        public ILoanReceiptDetailRepository loanReceiptDetail { get; private set; }


        #endregion

        #region Reports
        
        public IPacsReportRepository pacsReport { get; private set; }

        #endregion


        public UnitOfWork(AppDbContext db)
        {
            _db = db;

            #region Master

            ApplicationConfiguration = new ApplicationConfigurationRepository(_db);
            DistrictMaster = new DistrictMasterRepository(_db);
            TalukMaster = new TalukMasterRepository(_db);
            FirkaMaster = new FirkaMasterRepository(_db);
            RevenueVillageMaster = new RevenueVillageMasterRepository(_db);
            CropCategory = new CropCategoryRepository(_db);
            CropMaster = new CropMasterRepository(_db);
            LookUpCodeMaster = new LookUpCodeMasterRepository(_db);
            LoanTypeMaster = new LoanTypeMasterRepository(_db);
            SubRegisterOffice = new SubRegisterOfficeRepository(_db);
            JewelMaster = new JewelMasterRepository(_db);
            LoanRatioMaster = new LoanRatioMasterRepository(_db);
            RateOfIntrestMaster = new RateOfIntrestMasterRepository(_db);

            #endregion

            #region Transactions

            MemberMaster = new MemberMasterRepository(_db);
            VAOCertificate = new VAOCertificateRepository(_db);
            LoanRequest = new LoanRequestRepository(_db);
            LoanSanction = new LoanSanctionRepository(_db);
            LoanIssue = new LoanIssueRepository(_db);
            TieUpCompanyMaster = new TieUpCompanyMasterRepository(_db);
            Jlg = new JlgRepository(_db);
            loanReceipt = new LoanReceiptRepository(_db);


            #endregion


            #region Transactions
            pacsReport = new PacsReportRepository(_db);
            #endregion


        }

        #region Transaction
        public void Dispose()
        {
            _db.DisposeAsync();

            if (_db != null)
            {
                _db.DisposeAsync();
            }
            GC.SuppressFinalize(this);
        }

        public async Task<bool> Commit()
        {
            bool returnValue = true;
            using (var dbContextTransaction = _db.Database.BeginTransaction())
            {
                try
                {
                    await _db.SaveChangesAsync();
                    await dbContextTransaction.CommitAsync();
                }
                catch (DbEntityValidationException e)
                {
                    dbContextTransaction.Rollback();
                    Logger.Logging(GetValidationErrorMessage(e) + "\n Inner Exception :" + Convert.ToString("" + e.InnerException)
                        , Serilog.Events.LogEventLevel.Error);
                    returnValue = false;
                }
                catch (DbUpdateException ex)
                {
                    Logger.Logging(Convert.ToString("" + ex) + "\n Inner Exception : " + Convert.ToString("" + ex),
                        Serilog.Events.LogEventLevel.Error);
                    Logger.Logging(Convert.ToString("" + ex) + "\n Inner Exception : " + Convert.ToString("" + ex.InnerException),
                        Serilog.Events.LogEventLevel.Error);
                    returnValue = false;
                    dbContextTransaction.Rollback();
                }

                catch (Exception ex)
                {
                    Logger.Logging(Convert.ToString("" + ex) + "\n Inner Exception : " + Convert.ToString("" + ex),
                       Serilog.Events.LogEventLevel.Error);

                    Logger.Logging(Convert.ToString("" + ex) + "\n Inner Exception : " + Convert.ToString("" + ex.InnerException),
                        Serilog.Events.LogEventLevel.Error);
                    returnValue = false;
                    dbContextTransaction.Rollback();
                }

                finally
                {
                    _db.Dispose();
                }
                return returnValue;

            }
        }





        #endregion

        #region private methods

        /// <summary>
        /// Gets the validation error message.
        /// </summary>
        /// <param name="ex">The ex.</param>
        /// <returns></returns>
        private string GetValidationErrorMessage(DbEntityValidationException ex)
        {
            var validationErrorMessage = new StringBuilder();
            foreach (var error in ex.EntityValidationErrors)
            {
                if (error.Entry != null && error.Entry.Entity != null)
                {
                    validationErrorMessage.Append(string.Format("Validation error in entity [{0}]:\r\n", error.Entry.Entity.GetType()));
                }

                foreach (var validationError in error.ValidationErrors)
                {
                    validationErrorMessage.Append(string.Format("[{0}]:{1}\r\n", validationError.PropertyName, validationError.ErrorMessage));
                }
            }

            return validationErrorMessage.ToString();
        }

        #endregion
    }
}
