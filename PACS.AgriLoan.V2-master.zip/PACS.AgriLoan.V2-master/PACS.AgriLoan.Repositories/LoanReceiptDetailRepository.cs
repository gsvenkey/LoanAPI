﻿using Microsoft.EntityFrameworkCore;
using PACS.AgriLoan.Interface;
using PACS.AgriLoan.Repositories.Common;
using PACS.AgriLoan.Repositories.DbContext;
using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Repositories
{
    public class LoanReceiptDetailRepository : GenericRepository<LoanReceiptDetail>, ILoanReceiptDetailRepository
    {
        private readonly AppDbContext _db;

        public LoanReceiptDetailRepository(AppDbContext db) : base(db)
        {
            _db = db;
        }
        public async Task<long> GetNextNo(long pacsId, long loanTypeId)
        {
            return await _db.LoanReceiptHeaders.Where(p => p.PacsId == pacsId && p.LoanTypeID == loanTypeId).LongCountAsync() + 1;
        }
    }
}
