﻿using Microsoft.EntityFrameworkCore;
using PACS.AgriLoan.Interface;
using PACS.AgriLoan.Repositories.Common;
using PACS.AgriLoan.Repositories.DbContext;
using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Repositories
{
    public class LoanReceiptDetailRepository : GenericRepository<LoanReceiptDetail>, ILoanReceiptDetailRepository
    {
        private readonly AppDbContext _db;

        public LoanReceiptDetailRepository(AppDbContext db) : base(db)
        {
            _db = db;
        }
        public async Task<long> GetNextNo(long pacsId, long loanTypeId)
        {
            return await _db.LoanReceiptHeaders.Where(p => p.PacsId == pacsId && p.LoanTypeID == loanTypeId).LongCountAsync() + 1;
        }

        public async Task<decimal> GetPreviousRcptAmt(long receiptId)
        {
            return await (from rcpthdr in _db.LoanReceiptHeaders
                          join rcptdtl in _db.LoanReceiptDetails on rcpthdr.Id equals rcptdtl.ReceiptId
                          where rcpthdr.Id == receiptId && rcptdtl.IsDeleted == false && rcpthdr.IsDeleted == false
                          select (rcptdtl.Principal)
                          ).SumAsync();
        }

        public void Update(LoanReceiptDetail entity)
        {

            if (entity == null)
            {
                throw new ArgumentNullException(nameof(entity));
            }
            try
            {
                GetEntities().Update(entity);
            }
            catch (Exception ex)
            {
                ex.ToString();
            }

        }
    }
}
