﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using PACS.AgriLoan.Interface;
using PACS.AgriLoan.Repositories.Common;
using PACS.AgriLoan.Repositories.DbContext;
using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Repositories
{
    public class JlgRepository : GenericRepository<JlgHeader>, IJlgRepository
    {
        private readonly AppDbContext _db;

        public JlgRepository(AppDbContext db) : base(db)
        {
            _db = db;
        }

        public async Task<IEnumerable<VW_GetJlgMembersInfo>> GetJlgMembersInfo(long JlgMemberId)
        {
            return await _db.VW_GetJlgMembersInfos.AsNoTracking().Where(c => c.JlgMemberId == JlgMemberId).ToListAsync();
        }



        public async Task<IEnumerable<SelectListItem>> SelectJlg(long pacsId)
        {
            return await (
                from member in _db.MemberMasters
                where member.IsDeleted == false
                join Jlg in _db.JlgHeaders on member.Id equals Jlg.JlgMemberId
                where Jlg.IsDeleted == false
                join pacs in _db.PacsMasters on member.PacsId equals pacs.Id
                where pacs.Id == pacsId

                select new SelectListItem
                {
                    Value = Jlg.Id.ToString(),
                    Text = member.MemberNumber + " - " + member.Name
                }
               ).ToListAsync();
        }
    }
}
