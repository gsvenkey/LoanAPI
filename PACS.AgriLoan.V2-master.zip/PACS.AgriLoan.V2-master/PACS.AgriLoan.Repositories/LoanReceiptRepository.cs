﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using PACS.AgriLoan.Interface;
using PACS.AgriLoan.Repositories.Common;
using PACS.AgriLoan.Repositories.DbContext;
using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace PACS.AgriLoan.Repositories
{
    public class LoanReceiptRepository : GenericRepository<LoanReceiptHeader>, ILoanReceiptHeaderRepository
    {
        private readonly AppDbContext _db;

        public LoanReceiptRepository(AppDbContext db) : base(db)
        {
            _db = db;
        }

        public async Task<VW_GetLoanReceiptPendingDetail> getReceiptDetails(long IssueId)
        {
            return await _db.VW_GetLoanReceiptPendingDetails.AsNoTracking().Where(p=> p.IssueId == IssueId).FirstOrDefaultAsync();
        }

        public async Task<IEnumerable<SelectListItem>> SelectIssueNo(long pacsId, long memberId)
        {
            return await (
                            from Issue in _db.LoanIssueHeaders
                            where Issue.IsDeleted == false
                            join pacs in _db.PacsMasters on Issue.PacsId equals pacs.Id
                            join Closure in _db.LoanClosures on Issue.Id equals Closure.IssueId into leftJ
                            from lj in leftJ.DefaultIfEmpty()
                            where pacs.Id == pacsId
                            select new SelectListItem
                            {
                                Value = Issue.Id.ToString(),
                                Text = Issue.IssueNo.ToString()
                            }
                        ).ToListAsync();
        }

        


    }
}
