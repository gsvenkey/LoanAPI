﻿using Microsoft.AspNetCore.Mvc.Rendering;
using PACS.AgriLoan.Interface;
using PACS.AgriLoan.Repositories.DbContext;
using PASC.AgriLoan.DomainModels.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PACS.AgriLoan.Repositories.Common;

namespace PACS.AgriLoan.Repositories
{
    public class TalukMasterRepository : GenericRepository<TalukMaster>, ITalukMasterRepository
    {
        private readonly AppDbContext _db;

        public TalukMasterRepository(AppDbContext db) : base(db)
        {
            _db = db;
        }

		public async Task<IEnumerable<SelectListItem>> SelectTaluk(long districtId)
		{
            if (districtId > 0)
            {
                return await _db.TalukMasters.AsNoTracking().Where(c => c.IsDeleted == false && c.DistrictId == districtId).OrderBy(n => n.Name)
                    .Select(n => new SelectListItem
                    {
                        Value = n.Id.ToString(),
                        Text = n.Name
                    }).ToListAsync();
            }

            else
            {
                return await _db.TalukMasters.AsNoTracking().Where(c => c.IsDeleted == false).OrderBy(n => n.Name)
                                    .Select(n => new SelectListItem
                                    {
                                        Value = n.Id.ToString(),
                                        Text = n.Name
                                    }).ToListAsync();
            }
        }

		public async Task<bool> IsExist(string name)
		{
			return await _db.TalukMasters.Where(c => c.IsDeleted == false).AnyAsync(e => e.Name.ToUpper() == name.ToUpper());
		}

		public void Update(TalukMaster entity)
		{
			if (entity == null)
			{
				throw new ArgumentNullException(nameof(entity));
			}
			GetEntities().Update(entity);
		}

        public async Task<bool> IsExist(long Id)
        {
			return await _db.TalukMasters.AnyAsync(i => i.Id == Id);
		}

        
    }
}
