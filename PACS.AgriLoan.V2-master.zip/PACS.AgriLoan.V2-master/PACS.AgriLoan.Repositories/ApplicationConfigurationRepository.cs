﻿using Microsoft.EntityFrameworkCore;
using PACS.AgriLoan.Interface;
using PACS.AgriLoan.Repositories.Common;
using PACS.AgriLoan.Repositories.DbContext;
using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Repositories
{
   public class ApplicationConfigurationRepository : GenericRepository<ApplicationConfiguration>, IApplicationConfigurationRepository
    {
        private readonly AppDbContext _db;

        public ApplicationConfigurationRepository(AppDbContext db) : base(db)
        {
            _db = db;
        }

        public async Task<decimal> GetJlgMaxLimitPerMember()
        {
            return await _db.ApplicationConfigurations.Select(c => c.MaxLimitForMember).FirstOrDefaultAsync();
        }

        public async Task<decimal> GetMaxLimitPerMember()
        {
            return await _db.ApplicationConfigurations.Select(c => c.MaxLimitForMember).FirstOrDefaultAsync();
        }
    }
}
