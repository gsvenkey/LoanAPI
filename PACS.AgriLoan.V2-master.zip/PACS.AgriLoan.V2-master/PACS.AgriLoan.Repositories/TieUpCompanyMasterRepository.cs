﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using PACS.AgriLoan.Interface;
using PACS.AgriLoan.Repositories.Common;
using PACS.AgriLoan.Repositories.DbContext;
using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Repositories
{
    public class TieUpCompanyMasterRepository : GenericRepository<TieUpCompanyMaster>, ITieUpCompanyMasterRepository
    {
        private readonly AppDbContext _db;

        public TieUpCompanyMasterRepository(AppDbContext db) : base(db)
        {
            _db = db;
        }
        public async Task<IEnumerable<SelectListItem>> SelectCompany(long pacsId)
        {
            return await(
              from Comp in _db.TieUpCompanyMasters
              join district in _db.DistrictMasters on Comp.DistrictId equals district.Id
              join pacs in _db.PacsMasters on district.Id equals pacs.DistrictId
              where pacs.Id == pacsId

              select new SelectListItem
              {
                  Value = Comp.Id.ToString(),
                  Text = Comp.CompanyName
              }


             ).ToListAsync();

        }

       
    }
}
