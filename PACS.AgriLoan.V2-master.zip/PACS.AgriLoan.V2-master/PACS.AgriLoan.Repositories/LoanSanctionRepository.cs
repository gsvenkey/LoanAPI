﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using PACS.AgriLoan.Interface;
using PACS.AgriLoan.Repositories.Common;
using PACS.AgriLoan.Repositories.DbContext;
using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Repositories
{
  public  class LoanSanctionRepository : GenericRepository<LoanSanctionHeader>, ILoanSanctionRepository
    {
        private readonly AppDbContext _db;

        public LoanSanctionRepository(AppDbContext db) : base(db)
        {
            _db = db;
        }

        public async Task<IEnumerable<VW_GetLoanRequestDetail>> GetLoanRequestDetail(long requestId)
        {
            return await _db.VW_GetLoanRequestDetails.Where(p => p.RequestId == requestId).ToListAsync();
        }

        public async Task<VW_GetLoanRequestHeader> GetLoanRequestHeader(long requestId)
        {
            return await _db.VW_GetLoanRequestHeaders.AsNoTracking().Where(c => c.Id == requestId).FirstOrDefaultAsync();
        }

        public async Task<IEnumerable<SelectListItem>> SelectSanctionNo(long pacsId, long memberId)
        {
            return await _db.VW_GetLoanSanctionHeaders.AsNoTracking().Where(c => c.PacsId == pacsId && c.MemberID == memberId).OrderBy(n => n.SanctionNo)
                .Select(n => new SelectListItem
                {
                    Value = n.Id.ToString(),
                    Text = Convert.ToString("" + n.SanctionNo)
                }).ToListAsync();
        }

        public async Task<IEnumerable<VW_ListLoanSanction>> GetList(long pacsId, long fYearId)
        {
            return await _db.VW_ListLoanSanctions.AsNoTracking().Where(c => c.PacsId == pacsId && c.FYearId == fYearId).ToListAsync();
        }

        public void Update(LoanSanctionHeader entity)
        {
            if (entity == null)
            {
                throw new ArgumentNullException(nameof(entity));
            }
            try
            {
                GetEntities().Update(entity);
            }
            catch (Exception ex)
            {
                ex.ToString();
            }
        }


        public async Task<long> GetNextNo(long pacsId, long loanTypeId)
        {

            //List<SqlParameter> parameterList = new List<SqlParameter>();
            //parameterList.Add(new SqlParameter("@PacsId", pacsId));
            //parameterList.Add(new SqlParameter("@LoanTypeId", loanTypeId));
            //SqlParameter[] parameters = parameterList.ToArray();
            //int NextNo = await _db.Database.ExecuteSqlRawAsync("select [dbo].[fn_GetLoanRequestNextNo]", parameters);
            //return NextNo;

            //return AppDbContext.GetLoanRequestNextNo(pacsId, loanTypeId);

            return await _db.LoanSanctionHeaders.Where(p => p.PacsId == pacsId && p.LoanTypeID == loanTypeId).LongCountAsync() + 1;

        }
    }
}
