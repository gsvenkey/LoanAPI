﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Table("RoleMenuMaster")]
    public partial class RoleMenuMaster
    {
        [Key]
        public long Id { get; set; }
        public long Roleid { get; set; }
        public long Menuid { get; set; }

        [ForeignKey(nameof(Menuid))]
        [InverseProperty(nameof(MenuMaster.RoleMenuMasters))]
        public virtual MenuMaster Menu { get; set; }
        [ForeignKey(nameof(Roleid))]
        [InverseProperty(nameof(LookupCodeMaster.RoleMenuMasters))]
        public virtual LookupCodeMaster Role { get; set; }
    }
}
