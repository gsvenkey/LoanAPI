﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Keyless]
    public partial class VW_GetCurrentRateOfInterest
    {
        public long Id { get; set; }
        public long LoanTypeId { get; set; }
        [Column(TypeName = "date")]
        public DateTime? EffectFrom { get; set; }
        [Column(TypeName = "numeric(5, 2)")]
        public decimal Normal { get; set; }
        [Column(TypeName = "numeric(5, 2)")]
        public decimal Penal { get; set; }
    }
}
