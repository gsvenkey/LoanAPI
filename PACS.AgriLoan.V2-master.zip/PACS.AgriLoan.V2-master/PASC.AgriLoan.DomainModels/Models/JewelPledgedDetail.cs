﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    public partial class JewelPledgedDetail
    {
        [Key]
        public long Id { get; set; }
        public long LoanRequestId { get; set; }
        public long JewelMasterId { get; set; }
        [Column(TypeName = "numeric(8, 3)")]
        public decimal NoOfItem { get; set; }
        [Column(TypeName = "numeric(8, 3)")]
        public decimal TotalWeight { get; set; }
        [Column(TypeName = "numeric(8, 3)")]
        public decimal DisallowedWt { get; set; }
        [Column(TypeName = "numeric(8, 3)")]
        public decimal EstimateWeight { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal PacsValue { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal EstimationValue { get; set; }
        public bool IsDeleted { get; set; }
        public int? CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        public int? ModifiedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDate { get; set; }

        [ForeignKey(nameof(JewelMasterId))]
        [InverseProperty("JewelPledgedDetails")]
        public virtual JewelMaster JewelMaster { get; set; }
        [ForeignKey(nameof(LoanRequestId))]
        [InverseProperty(nameof(LoanRequestHeader.JewelPledgedDetails))]
        public virtual LoanRequestHeader LoanRequest { get; set; }
    }
}
