﻿using System;
using System.Collections.Generic;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    public partial class VwLookUpMaster
    {
        public long Id { get; set; }
        public string Name { get; set; }
        public long CodeId { get; set; }
        public string Code { get; set; }
    }
}
