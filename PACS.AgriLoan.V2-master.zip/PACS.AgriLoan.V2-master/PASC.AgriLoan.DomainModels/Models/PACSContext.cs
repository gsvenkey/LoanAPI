﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    public partial class PACSContext : DbContext
    {
        public PACSContext()
        {
        }

        public PACSContext(DbContextOptions<PACSContext> options)
            : base(options)
        {
        }

        public virtual DbSet<ApplicationConfiguration> ApplicationConfigurations { get; set; }
        public virtual DbSet<BlockMaster> BlockMasters { get; set; }
        public virtual DbSet<CropCategory> CropCategories { get; set; }
        public virtual DbSet<CropMaster> CropMasters { get; set; }
        public virtual DbSet<DB_Error> DB_Errors { get; set; }
        public virtual DbSet<DccbBankMaster> DccbBankMasters { get; set; }
        public virtual DbSet<DccbSanctionOrder> DccbSanctionOrders { get; set; }
        public virtual DbSet<DistrictMaster> DistrictMasters { get; set; }
        public virtual DbSet<EmployeeMaster> EmployeeMasters { get; set; }
        public virtual DbSet<FinancialYear> FinancialYears { get; set; }
        public virtual DbSet<FirkaMaster> FirkaMasters { get; set; }
        public virtual DbSet<JewelMaster> JewelMasters { get; set; }
        public virtual DbSet<JewelPledgedDetail> JewelPledgedDetails { get; set; }
        public virtual DbSet<JewelValuation> JewelValuations { get; set; }
        public virtual DbSet<JlgDetail> JlgDetails { get; set; }
        public virtual DbSet<JlgHeader> JlgHeaders { get; set; }
        public virtual DbSet<JlgLoanMemberDetail> JlgLoanMemberDetails { get; set; }
        public virtual DbSet<JlgLoanTypeDetail> JlgLoanTypeDetails { get; set; }
        public virtual DbSet<LandPledgedDetail> LandPledgedDetails { get; set; }
        public virtual DbSet<LoanIssueDetail> LoanIssueDetails { get; set; }
        public virtual DbSet<LoanIssueHeader> LoanIssueHeaders { get; set; }
        public virtual DbSet<LoanRatioMaster> LoanRatioMasters { get; set; }
        public virtual DbSet<LoanReceipt> LoanReceipts { get; set; }
        public virtual DbSet<LoanRequestDetail> LoanRequestDetails { get; set; }
        public virtual DbSet<LoanRequestHeader> LoanRequestHeaders { get; set; }
        public virtual DbSet<LoanSanctionDetail> LoanSanctionDetails { get; set; }
        public virtual DbSet<LoanSanctionHeader> LoanSanctionHeaders { get; set; }
        public virtual DbSet<LoanTypeLimtationMaster> LoanTypeLimtationMasters { get; set; }
        public virtual DbSet<LoanTypeMaster> LoanTypeMasters { get; set; }
        public virtual DbSet<LookupCodeMaster> LookupCodeMasters { get; set; }
        public virtual DbSet<LookupTypeMaster> LookupTypeMasters { get; set; }
        public virtual DbSet<MemberMaster> MemberMasters { get; set; }
        public virtual DbSet<MenuMaster> MenuMasters { get; set; }
        public virtual DbSet<PacsMaster> PacsMasters { get; set; }
        public virtual DbSet<RateOfIntrestMaster> RateOfIntrestMasters { get; set; }
        public virtual DbSet<ReportingAreaOffice> ReportingAreaOffices { get; set; }
        public virtual DbSet<RevenueVillageMaster> RevenueVillageMasters { get; set; }
        public virtual DbSet<RoleMenuMaster> RoleMenuMasters { get; set; }
        public virtual DbSet<ShareValueMaster> ShareValueMasters { get; set; }
        public virtual DbSet<SubRegisterDistrictMaster> SubRegisterDistrictMasters { get; set; }
        public virtual DbSet<SubRegisterMaster> SubRegisterMasters { get; set; }
        public virtual DbSet<SuretyDetail> SuretyDetails { get; set; }
        public virtual DbSet<TalukMaster> TalukMasters { get; set; }
        public virtual DbSet<TieUpCompanyDetail> TieUpCompanyDetails { get; set; }
        public virtual DbSet<TieUpCompanyMaster> TieUpCompanyMasters { get; set; }
        public virtual DbSet<VW_GetLoanRatioForCrop> VW_GetLoanRatioForCrops { get; set; }
        public virtual DbSet<VW_GetLoanRequestDetail> VW_GetLoanRequestDetails { get; set; }
        public virtual DbSet<VW_GetLoanRequestHeader> VW_GetLoanRequestHeaders { get; set; }
        public virtual DbSet<VW_GetMemberInfo> VW_GetMemberInfos { get; set; }
        public virtual DbSet<VW_GetSurveyDetail> VW_GetSurveyDetails { get; set; }
        public virtual DbSet<VW_ListLoanRequest> VW_ListLoanRequests { get; set; }
        public virtual DbSet<VW_LookUpMaster> VW_LookUpMasters { get; set; }
        public virtual DbSet<VW_MenuMaster> VW_MenuMasters { get; set; }
        public virtual DbSet<VaoCertificateDetail> VaoCertificateDetails { get; set; }
        public virtual DbSet<VaoCertificateHeader> VaoCertificateHeaders { get; set; }
        public virtual DbSet<ZoneMaster> ZoneMasters { get; set; }
        public virtual DbSet<temp_Block> temp_Blocks { get; set; }
        public virtual DbSet<temp_Crop> temp_Crops { get; set; }
        public virtual DbSet<temp_CropCategory> temp_CropCategories { get; set; }
        public virtual DbSet<temp_Firka> temp_Firkas { get; set; }
        public virtual DbSet<temp_Jewel> temp_Jewels { get; set; }
        public virtual DbSet<temp_Loanratio> temp_Loanratios { get; set; }
        public virtual DbSet<temp_Member> temp_Members { get; set; }
        public virtual DbSet<temp_RevenueVillage> temp_RevenueVillages { get; set; }
        public virtual DbSet<temp_SubRegister> temp_SubRegisters { get; set; }
        public virtual DbSet<temp_district> temp_districts { get; set; }
        public virtual DbSet<temp_taluk> temp_taluks { get; set; }

       

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "SQL_Latin1_General_CP1_CI_AS");

            modelBuilder.Entity<ApplicationConfiguration>(entity =>
            {
                entity.Property(e => e.Name).IsUnicode(false);
            });

            modelBuilder.Entity<BlockMaster>(entity =>
            {
                entity.Property(e => e.Code).IsUnicode(false);

                entity.Property(e => e.Name).IsUnicode(false);

                entity.Property(e => e.ShortName).IsUnicode(false);

                entity.HasOne(d => d.Taluk)
                    .WithMany(p => p.BlockMasters)
                    .HasForeignKey(d => d.TalukId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_BlockMaster_TalukMaster_ID");
            });

            modelBuilder.Entity<CropCategory>(entity =>
            {
                entity.Property(e => e.Name).IsUnicode(false);
            });

            modelBuilder.Entity<CropMaster>(entity =>
            {
                entity.Property(e => e.Name).IsUnicode(false);

                entity.HasOne(d => d.Category)
                    .WithMany(p => p.CropMasters)
                    .HasForeignKey(d => d.CategoryId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_CropMaster_CropCategory_Id");
            });

            modelBuilder.Entity<DB_Error>(entity =>
            {
                entity.Property(e => e.ErrorID).ValueGeneratedOnAdd();

                entity.Property(e => e.ErrorMessage).IsUnicode(false);

                entity.Property(e => e.ErrorProcedure).IsUnicode(false);

                entity.Property(e => e.UserName).IsUnicode(false);
            });

            modelBuilder.Entity<DccbBankMaster>(entity =>
            {
                entity.Property(e => e.Name).IsUnicode(false);

                entity.Property(e => e.PhoneNo).IsUnicode(false);

                entity.Property(e => e.PinCode).IsUnicode(false);

                entity.Property(e => e.ShortName).IsUnicode(false);

                entity.HasOne(d => d.District)
                    .WithMany(p => p.DccbBankMasters)
                    .HasForeignKey(d => d.DistrictId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_DccbBankMaster_DistrictMaster_ID");

                entity.HasOne(d => d.Ho)
                    .WithMany(p => p.InverseHo)
                    .HasForeignKey(d => d.HoID)
                    .HasConstraintName("FK_DccbBankMaster_DccbBankMaster_ID");
            });

            modelBuilder.Entity<DccbSanctionOrder>(entity =>
            {
                entity.HasOne(d => d.FYear)
                    .WithMany(p => p.DccbSanctionOrders)
                    .HasForeignKey(d => d.FYearId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_DccbSanctionOrder_FinancialYear");

                entity.HasOne(d => d.LoanType)
                    .WithMany(p => p.DccbSanctionOrders)
                    .HasForeignKey(d => d.LoanTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_DccbSanctionOrder_LoanTypeMaster");

                entity.HasOne(d => d.Pacs)
                    .WithMany(p => p.DccbSanctionOrders)
                    .HasForeignKey(d => d.PacsId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_DccbSanctionOrder_PacsMaster");
            });

            modelBuilder.Entity<DistrictMaster>(entity =>
            {
                entity.Property(e => e.Name).IsUnicode(false);

                entity.Property(e => e.ShortName).IsUnicode(false);
            });

            modelBuilder.Entity<EmployeeMaster>(entity =>
            {
                entity.Property(e => e.Name).IsUnicode(false);

                entity.Property(e => e.Password).IsUnicode(false);

                entity.Property(e => e.UserName).IsUnicode(false);

                entity.HasOne(d => d.Designation)
                    .WithMany(p => p.EmployeeMasterDesignations)
                    .HasForeignKey(d => d.DesignationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_EmployeeMaster_LookUp_Designation");

                entity.HasOne(d => d.District)
                    .WithMany(p => p.EmployeeMasters)
                    .HasForeignKey(d => d.DistrictId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_EmployeeMaster_DistrictMaster");

                entity.HasOne(d => d.Pacs)
                    .WithMany(p => p.EmployeeMasters)
                    .HasForeignKey(d => d.PacsId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_EmployeeMaster_PacsMaster");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.EmployeeMasterRoles)
                    .HasForeignKey(d => d.RoleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_EmployeeMaster_LookUp_Role");
            });

            modelBuilder.Entity<FinancialYear>(entity =>
            {
                entity.Property(e => e.Name).IsUnicode(false);

                entity.Property(e => e.ShortName).IsUnicode(false);
            });

            modelBuilder.Entity<FirkaMaster>(entity =>
            {
                entity.Property(e => e.Name).IsUnicode(false);

                entity.HasOne(d => d.Taluk)
                    .WithMany(p => p.FirkaMasters)
                    .HasForeignKey(d => d.TalukId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_FirkaMaster_TalukMaster");
            });

            modelBuilder.Entity<JewelMaster>(entity =>
            {
                entity.Property(e => e.Name).IsUnicode(false);
            });

            modelBuilder.Entity<JewelPledgedDetail>(entity =>
            {
                entity.HasOne(d => d.JewelMaster)
                    .WithMany(p => p.JewelPledgedDetails)
                    .HasForeignKey(d => d.JewelMasterId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_JewelPledgedDetails_JewelMaster");

                entity.HasOne(d => d.LoanRequest)
                    .WithMany(p => p.JewelPledgedDetails)
                    .HasForeignKey(d => d.LoanRequestId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_JewelPledgedDetails_LoanRequestHeader");
            });

            modelBuilder.Entity<JewelValuation>(entity =>
            {
                entity.HasOne(d => d.Pacs)
                    .WithMany(p => p.JewelValuations)
                    .HasForeignKey(d => d.PacsId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_JewelValuation_PacsMaster");
            });

            modelBuilder.Entity<JlgDetail>(entity =>
            {
                entity.HasOne(d => d.Jlg)
                    .WithMany(p => p.JlgDetails)
                    .HasForeignKey(d => d.JlgId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_JlgDetail_JlgHeader");

                entity.HasOne(d => d.Member)
                    .WithMany(p => p.JlgDetails)
                    .HasForeignKey(d => d.MemberId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_JlgDetail_MemberMaster");
            });

            modelBuilder.Entity<JlgHeader>(entity =>
            {
                entity.HasOne(d => d.Pacs)
                    .WithMany(p => p.JlgHeaders)
                    .HasForeignKey(d => d.PacsId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_JlgHeader_PacsMaster");

                entity.HasOne(d => d.UkkunarMember)
                    .WithMany(p => p.JlgHeaders)
                    .HasForeignKey(d => d.UkkunarMemberId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_JlgHeader_MemberMaster");
            });

            modelBuilder.Entity<JlgLoanMemberDetail>(entity =>
            {
                entity.HasOne(d => d.LoanRequest)
                    .WithMany(p => p.JlgLoanMemberDetails)
                    .HasForeignKey(d => d.LoanRequestId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_JlgLoanMemberDetails_LoanRequestHeader");

                entity.HasOne(d => d.Member)
                    .WithMany(p => p.JlgLoanMemberDetails)
                    .HasForeignKey(d => d.MemberId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_JlgLoanMemberDetails_MemebrMaster");
            });

            modelBuilder.Entity<JlgLoanTypeDetail>(entity =>
            {
                entity.HasOne(d => d.LoanRequest)
                    .WithMany(p => p.JlgLoanTypeDetails)
                    .HasForeignKey(d => d.LoanRequestId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_JlgLoanTypeDetails_LoanRequestHeader");

                entity.HasOne(d => d.Member)
                    .WithMany(p => p.JlgLoanTypeDetails)
                    .HasForeignKey(d => d.MemberId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_JlgLoanTypeDetails_MemberMaster");
            });

            modelBuilder.Entity<LandPledgedDetail>(entity =>
            {
                entity.Property(e => e.MortgageRegNo).IsUnicode(false);

                entity.HasOne(d => d.LoanRequest)
                    .WithMany(p => p.LandPledgedDetails)
                    .HasForeignKey(d => d.LoanRequestId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_LandPledgedDetails_LoanRequestHeader");

                entity.HasOne(d => d.SubRegister)
                    .WithMany(p => p.LandPledgedDetails)
                    .HasForeignKey(d => d.SubRegisterId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_LandPledgedDetails_SubRegisterMaster");
            });

            modelBuilder.Entity<LoanIssueDetail>(entity =>
            {
                entity.HasOne(d => d.Crop)
                    .WithMany(p => p.LoanIssueDetails)
                    .HasForeignKey(d => d.CropId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_LoanIssueDetail_CropMaster");

                entity.HasOne(d => d.Sanction)
                    .WithMany(p => p.LoanIssueDetails)
                    .HasForeignKey(d => d.SanctionId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_LoanIssueDetail_LoanSanctionHeader");
            });

            modelBuilder.Entity<LoanIssueHeader>(entity =>
            {
                entity.Property(e => e.LoanNo).IsUnicode(false);

                entity.HasOne(d => d.FYear)
                    .WithMany(p => p.LoanIssueHeaders)
                    .HasForeignKey(d => d.FYearId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_LoanIssueHeader_FinancialYear");

                entity.HasOne(d => d.Member)
                    .WithMany(p => p.LoanIssueHeaders)
                    .HasForeignKey(d => d.MemberID)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_LoanIssueHeader_MemebrMaster");

                entity.HasOne(d => d.Pacs)
                    .WithMany(p => p.LoanIssueHeaders)
                    .HasForeignKey(d => d.PacsId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_LoanIssueHeader_PacsMaster");

                entity.HasOne(d => d.Sanction)
                    .WithMany(p => p.LoanIssueHeaders)
                    .HasForeignKey(d => d.SanctionId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_LoanIssueHeader_LoanSanctionHeader");
            });

            modelBuilder.Entity<LoanRatioMaster>(entity =>
            {
                entity.HasOne(d => d.Crop)
                    .WithMany(p => p.LoanRatioMasters)
                    .HasForeignKey(d => d.CropId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_LoanRatioMaster_CropMaster");

                entity.HasOne(d => d.District)
                    .WithMany(p => p.LoanRatioMasters)
                    .HasForeignKey(d => d.DistrictId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_LoanRatioMaster_DistrictMaster");
            });

            modelBuilder.Entity<LoanReceipt>(entity =>
            {
                entity.Property(e => e.LoanNo).IsUnicode(false);

                entity.HasOne(d => d.FYear)
                    .WithMany(p => p.LoanReceipts)
                    .HasForeignKey(d => d.FYearId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_LoanReceipt_FinancialYear");

                entity.HasOne(d => d.Issue)
                    .WithMany(p => p.LoanReceipts)
                    .HasForeignKey(d => d.IssueId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_LoanReceipt_LoanIssueHeader");

                entity.HasOne(d => d.Member)
                    .WithMany(p => p.LoanReceipts)
                    .HasForeignKey(d => d.MemberID)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_LoanReceipt_MemberMaster");

                entity.HasOne(d => d.Pacs)
                    .WithMany(p => p.LoanReceipts)
                    .HasForeignKey(d => d.PacsId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_LoanReceipt_PacsMaster");
            });

            modelBuilder.Entity<LoanRequestDetail>(entity =>
            {
                entity.HasOne(d => d.Crop)
                    .WithMany(p => p.LoanRequestDetails)
                    .HasForeignKey(d => d.CropId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_LoanRequestDetail_CropMaster");

                entity.HasOne(d => d.LoanRequest)
                    .WithMany(p => p.LoanRequestDetails)
                    .HasForeignKey(d => d.LoanRequestId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_LoanRequestDetail_LoanRequestHeader");
            });

            modelBuilder.Entity<LoanRequestHeader>(entity =>
            {
                entity.HasOne(d => d.FYear)
                    .WithMany(p => p.LoanRequestHeaders)
                    .HasForeignKey(d => d.FYearId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_LoanRequestHeader_FinancialYear_Id");

                entity.HasOne(d => d.LoanType)
                    .WithMany(p => p.LoanRequestHeaders)
                    .HasForeignKey(d => d.LoanTypeID)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_LoanRequestHeader_LoanTypeMaster");

                entity.HasOne(d => d.Member)
                    .WithMany(p => p.LoanRequestHeaders)
                    .HasForeignKey(d => d.MemberID)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_LoanRequestHeader_MemberMaster");

                entity.HasOne(d => d.Pacs)
                    .WithMany(p => p.LoanRequestHeaders)
                    .HasForeignKey(d => d.PacsId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_LoanRequestHeader_PacsMaster");

                entity.HasOne(d => d.VaoCertificateHeader)
                    .WithMany(p => p.LoanRequestHeaders)
                    .HasForeignKey(d => d.VaoCertificateHeaderId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_LoanRequestHeader_VaoCertificateHeader");
            });

            modelBuilder.Entity<LoanSanctionDetail>(entity =>
            {
                entity.HasOne(d => d.Crop)
                    .WithMany(p => p.LoanSanctionDetails)
                    .HasForeignKey(d => d.CropId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_LoanSanctionDetail_CropMaster");

                entity.HasOne(d => d.LoanRequest)
                    .WithMany(p => p.LoanSanctionDetails)
                    .HasForeignKey(d => d.LoanRequestId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_LoanSanctionDetail_LoanRequestHeader");
            });

            modelBuilder.Entity<LoanSanctionHeader>(entity =>
            {
                entity.HasOne(d => d.FYear)
                    .WithMany(p => p.LoanSanctionHeaders)
                    .HasForeignKey(d => d.FYearId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_LoanSanctionHeader_FinancialYear");

                entity.HasOne(d => d.LoanRequest)
                    .WithMany(p => p.LoanSanctionHeaders)
                    .HasForeignKey(d => d.LoanRequestId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_LoanSanctionHeader_LoanRequestHeader");

                entity.HasOne(d => d.Member)
                    .WithMany(p => p.LoanSanctionHeaders)
                    .HasForeignKey(d => d.MemberID)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_LoanSanctionHeader_MemebrMaster");

                entity.HasOne(d => d.Pacs)
                    .WithMany(p => p.LoanSanctionHeaders)
                    .HasForeignKey(d => d.PacsId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_LoanSanctionHeader_PacsMaster");
            });

            modelBuilder.Entity<LoanTypeLimtationMaster>(entity =>
            {
                entity.HasOne(d => d.LoanType)
                    .WithMany(p => p.LoanTypeLimtationMasters)
                    .HasForeignKey(d => d.LoanTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_LoanTypeLimtationMaster_LoanTypeMaster");
            });

            modelBuilder.Entity<LoanTypeMaster>(entity =>
            {
                entity.Property(e => e.Name).IsUnicode(false);

                entity.Property(e => e.ShortName).IsUnicode(false);
            });

            modelBuilder.Entity<LookupCodeMaster>(entity =>
            {
                entity.Property(e => e.Name).IsUnicode(false);

                entity.Property(e => e.PrintName).IsUnicode(false);

                entity.Property(e => e.ShortName).IsUnicode(false);

                entity.HasOne(d => d.LoolkUpType)
                    .WithMany(p => p.LookupCodeMasters)
                    .HasForeignKey(d => d.LoolkUpTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_LookupCodeMaster_LookupTypeMaster");

                entity.HasOne(d => d.Parent)
                    .WithMany(p => p.InverseParent)
                    .HasForeignKey(d => d.ParentId)
                    .HasConstraintName("FK_LookupCodeMaster_LookupCodeMaster");
            });

            modelBuilder.Entity<LookupTypeMaster>(entity =>
            {
                entity.Property(e => e.Name).IsUnicode(false);

                entity.Property(e => e.ShortName).IsUnicode(false);
            });

            modelBuilder.Entity<MemberMaster>(entity =>
            {
                entity.Property(e => e.PANNumber).IsUnicode(false);

                entity.Property(e => e.SmartCardNumber).IsUnicode(false);

                entity.HasOne(d => d.Community)
                    .WithMany(p => p.MemberMasterCommunities)
                    .HasForeignKey(d => d.CommunityId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MemberMaster_LookUpCodeMaster_Community");

                entity.HasOne(d => d.Gender)
                    .WithMany(p => p.MemberMasterGenders)
                    .HasForeignKey(d => d.GenderId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MemberMaster_LookUpCodeMaster_Gender");

                entity.HasOne(d => d.MembershipType)
                    .WithMany(p => p.MemberMasterMembershipTypes)
                    .HasForeignKey(d => d.MembershipTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MemberMaster_LookUpCodeMaster_MembershipType");

                entity.HasOne(d => d.Pacs)
                    .WithMany(p => p.MemberMasters)
                    .HasForeignKey(d => d.PacsId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MemberMaster_PacsMaster");

                entity.HasOne(d => d.Religion)
                    .WithMany(p => p.MemberMasterReligions)
                    .HasForeignKey(d => d.ReligionId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MemberMaster_LookUpCodeMaster_Relegion");

                entity.HasOne(d => d.ShareType)
                    .WithMany(p => p.MemberMasterShareTypes)
                    .HasForeignKey(d => d.ShareTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MemberMaster_LookUpCodeMaster_ShareType");
            });

            modelBuilder.Entity<MenuMaster>(entity =>
            {
                entity.Property(e => e.ActionMethod).IsUnicode(false);

                entity.Property(e => e.Active).HasDefaultValueSql("((1))");

                entity.Property(e => e.ControllerName).IsUnicode(false);

                entity.Property(e => e.Displayname).IsUnicode(false);

                entity.Property(e => e.Icon).IsUnicode(false);

                entity.Property(e => e.Name).IsUnicode(false);

                entity.Property(e => e.Url).IsUnicode(false);

                entity.HasOne(d => d.MenuType)
                    .WithMany(p => p.MenuMasters)
                    .HasForeignKey(d => d.MenuTypeId)
                    .HasConstraintName("FK_MenuMaster_LookUp_MenuType");
            });

            modelBuilder.Entity<PacsMaster>(entity =>
            {
                entity.Property(e => e.Name).IsUnicode(false);

                entity.Property(e => e.ShortName).IsUnicode(false);

                entity.HasOne(d => d.Block)
                    .WithMany(p => p.PacsMasters)
                    .HasForeignKey(d => d.BlockId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_PACSMaster_BlockMaster_ID");

                entity.HasOne(d => d.Dccb)
                    .WithMany(p => p.PacsMasters)
                    .HasForeignKey(d => d.DccbId)
                    .HasConstraintName("FK_PACSMaster_DccbBankMaster_ID");

                entity.HasOne(d => d.District)
                    .WithMany(p => p.PacsMasters)
                    .HasForeignKey(d => d.DistrictId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_PACSMaster_DistrictMaster_ID");

                entity.HasOne(d => d.Taluk)
                    .WithMany(p => p.PacsMasters)
                    .HasForeignKey(d => d.TalukId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_PACSMaster_TalukMaster_ID");

                entity.HasOne(d => d.Zone)
                    .WithMany(p => p.PacsMasters)
                    .HasForeignKey(d => d.ZoneId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_PACSMaster_ZoneMaster_Id");
            });

            modelBuilder.Entity<ReportingAreaOffice>(entity =>
            {
                entity.Property(e => e.Name).IsUnicode(false);

                entity.Property(e => e.ShortName).IsUnicode(false);

                entity.HasOne(d => d.District)
                    .WithMany(p => p.ReportingAreaOffices)
                    .HasForeignKey(d => d.DistrictId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ReportingAreaOffice_DistrictMaster");

                entity.HasOne(d => d.Taluk)
                    .WithMany(p => p.ReportingAreaOffices)
                    .HasForeignKey(d => d.TalukId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_ReportingAreaOffice_TalukMaster");
            });

            modelBuilder.Entity<RevenueVillageMaster>(entity =>
            {
                entity.Property(e => e.Name).IsUnicode(false);

                entity.HasOne(d => d.Firka)
                    .WithMany(p => p.RevenueVillageMasters)
                    .HasForeignKey(d => d.FirkaId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_RevenueVillageMaster_FirkaMaster");
            });

            modelBuilder.Entity<RoleMenuMaster>(entity =>
            {
                entity.HasOne(d => d.Menu)
                    .WithMany(p => p.RoleMenuMasters)
                    .HasForeignKey(d => d.Menuid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_RoleMenuMaster_MenuMaster");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.RoleMenuMasters)
                    .HasForeignKey(d => d.Roleid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_MenuMaster_LookUp_RoleType");
            });

            modelBuilder.Entity<SubRegisterDistrictMaster>(entity =>
            {
                entity.Property(e => e.Name).IsUnicode(false);

                entity.HasOne(d => d.ZoneMaster)
                    .WithMany(p => p.SubRegisterDistrictMasters)
                    .HasForeignKey(d => d.ZoneMasterId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_SubRegisterDistrictMaster_ZoneMaster");
            });

            modelBuilder.Entity<SubRegisterMaster>(entity =>
            {
                entity.Property(e => e.Name).IsUnicode(false);

                entity.HasOne(d => d.SubRegisterDistrict)
                    .WithMany(p => p.SubRegisterMasters)
                    .HasForeignKey(d => d.SubRegisterDistrictId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_SubRegisterMaster_SubRegisterDistrictMaster");
            });

            modelBuilder.Entity<SuretyDetail>(entity =>
            {
                entity.HasOne(d => d.LoanRequest)
                    .WithMany(p => p.SuretyDetails)
                    .HasForeignKey(d => d.LoanRequestId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_SuretyDetails_LoanRequestHeader");

                entity.HasOne(d => d.Member)
                    .WithMany(p => p.SuretyDetails)
                    .HasForeignKey(d => d.MemberId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_SuretyDetails_MemebrMaster");
            });

            modelBuilder.Entity<TalukMaster>(entity =>
            {
                entity.Property(e => e.Name).IsUnicode(false);

                entity.Property(e => e.ShortName).IsUnicode(false);

                entity.HasOne(d => d.District)
                    .WithMany(p => p.TalukMasters)
                    .HasForeignKey(d => d.DistrictId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_TalukMaster_DistrictMaster_ID");
            });

            modelBuilder.Entity<TieUpCompanyDetail>(entity =>
            {
                entity.HasOne(d => d.LoanRequest)
                    .WithMany(p => p.TieUpCompanyDetails)
                    .HasForeignKey(d => d.LoanRequestId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_TieUpCompanyDetails_LoanRequestHeader");

                entity.HasOne(d => d.TieUpCompany)
                    .WithMany(p => p.TieUpCompanyDetails)
                    .HasForeignKey(d => d.TieUpCompanyId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_TieUpCompanyDetails_TieUpCompanyMaster");
            });

            modelBuilder.Entity<TieUpCompanyMaster>(entity =>
            {
                entity.HasOne(d => d.District)
                    .WithMany(p => p.TieUpCompanyMasters)
                    .HasForeignKey(d => d.DistrictId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_TieUpCompanyMaster_DistrictMaster");
            });

            modelBuilder.Entity<VW_GetLoanRatioForCrop>(entity =>
            {
                entity.ToView("VW_GetLoanRatioForCrop");

                entity.Property(e => e.Name).IsUnicode(false);
            });

            modelBuilder.Entity<VW_GetLoanRequestDetail>(entity =>
            {
                entity.ToView("VW_GetLoanRequestDetail");

                entity.Property(e => e.CropName).IsUnicode(false);
            });

            modelBuilder.Entity<VW_GetLoanRequestHeader>(entity =>
            {
                entity.ToView("VW_GetLoanRequestHeader");

                entity.Property(e => e.LoanTypeName).IsUnicode(false);
            });

            modelBuilder.Entity<VW_GetMemberInfo>(entity =>
            {
                entity.ToView("VW_GetMemberInfo");

                entity.Property(e => e.Id).ValueGeneratedOnAdd();
            });

            modelBuilder.Entity<VW_GetSurveyDetail>(entity =>
            {
                entity.ToView("VW_GetSurveyDetails");
            });

            modelBuilder.Entity<VW_ListLoanRequest>(entity =>
            {
                entity.ToView("VW_ListLoanRequest");
            });

            modelBuilder.Entity<VW_LookUpMaster>(entity =>
            {
                entity.ToView("VW_LookUpMaster");

                entity.Property(e => e.Code).IsUnicode(false);

                entity.Property(e => e.Name).IsUnicode(false);
            });

            modelBuilder.Entity<VW_MenuMaster>(entity =>
            {
                entity.ToView("VW_MenuMaster");

                entity.Property(e => e.ActionMethod).IsUnicode(false);

                entity.Property(e => e.ControllerName).IsUnicode(false);

                entity.Property(e => e.Displayname).IsUnicode(false);

                entity.Property(e => e.Icon).IsUnicode(false);

                entity.Property(e => e.MenuType).IsUnicode(false);

                entity.Property(e => e.Name).IsUnicode(false);

                entity.Property(e => e.ParentMenu).IsUnicode(false);

                entity.Property(e => e.RoleName).IsUnicode(false);

                entity.Property(e => e.Url).IsUnicode(false);
            });

            modelBuilder.Entity<VaoCertificateDetail>(entity =>
            {
                entity.HasOne(d => d.VaoCertificate)
                    .WithMany(p => p.VaoCertificateDetails)
                    .HasForeignKey(d => d.VaoCertificateId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_VaoCertificateDetail_VaoCertificateHeader");
            });

            modelBuilder.Entity<VaoCertificateHeader>(entity =>
            {
                entity.HasOne(d => d.Firka)
                    .WithMany(p => p.VaoCertificateHeaders)
                    .HasForeignKey(d => d.FirkaId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_VaoCertificateHeader_FirkaMaster");

                entity.HasOne(d => d.IrrigationType)
                    .WithMany(p => p.VaoCertificateHeaderIrrigationTypes)
                    .HasForeignKey(d => d.IrrigationTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_VaoCertificateHeader_LookUp_IrrigationType");

                entity.HasOne(d => d.Member)
                    .WithMany(p => p.VaoCertificateHeaders)
                    .HasForeignKey(d => d.MemberId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_VaoCertificateHeader_MemberMaster");

                entity.HasOne(d => d.OwnerShipType)
                    .WithMany(p => p.VaoCertificateHeaderOwnerShipTypes)
                    .HasForeignKey(d => d.OwnerShipTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_VaoCertificateHeader_LookUp_OwnerShipType");

                entity.HasOne(d => d.RevenueVillage)
                    .WithMany(p => p.VaoCertificateHeaders)
                    .HasForeignKey(d => d.RevenueVillageId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_VaoCertificateHeader_RevenueVillageMaster");
            });

            modelBuilder.Entity<ZoneMaster>(entity =>
            {
                entity.Property(e => e.Name).IsUnicode(false);
            });

            modelBuilder.Entity<temp_Block>(entity =>
            {
                entity.Property(e => e.Code).IsUnicode(false);

                entity.Property(e => e.Name).IsUnicode(false);

                entity.Property(e => e.ShortName).IsUnicode(false);

                entity.Property(e => e.TalukName).IsUnicode(false);
            });

            modelBuilder.Entity<temp_Crop>(entity =>
            {
                entity.Property(e => e.CropName).IsUnicode(false);
            });

            modelBuilder.Entity<temp_CropCategory>(entity =>
            {
                entity.Property(e => e.Category).IsUnicode(false);
            });

            modelBuilder.Entity<temp_Firka>(entity =>
            {
                entity.Property(e => e.Name).IsUnicode(false);

                entity.Property(e => e.Taluk).IsUnicode(false);
            });

            modelBuilder.Entity<temp_Jewel>(entity =>
            {
                entity.Property(e => e.Name).IsUnicode(false);
            });

            modelBuilder.Entity<temp_Loanratio>(entity =>
            {
                entity.Property(e => e.CropName).IsUnicode(false);

                entity.Property(e => e.DistrictName).IsUnicode(false);

                entity.Property(e => e.MonthNumber).IsUnicode(false);
            });

            modelBuilder.Entity<temp_Member>(entity =>
            {
                entity.Property(e => e.Community).IsUnicode(false);

                entity.Property(e => e.Gender).IsUnicode(false);

                entity.Property(e => e.MembershipType).IsUnicode(false);

                entity.Property(e => e.PANnumber).IsUnicode(false);

                entity.Property(e => e.Pacs).IsUnicode(false);

                entity.Property(e => e.Religion).IsUnicode(false);

                entity.Property(e => e.ShareType).IsUnicode(false);

                entity.Property(e => e.SmartCardNumber).IsUnicode(false);
            });

            modelBuilder.Entity<temp_RevenueVillage>(entity =>
            {
                entity.Property(e => e.FirkaName).IsUnicode(false);

                entity.Property(e => e.Name).IsUnicode(false);
            });

            modelBuilder.Entity<temp_SubRegister>(entity =>
            {
                entity.Property(e => e.DistrictName).IsUnicode(false);

                entity.Property(e => e.Name).IsUnicode(false);

                entity.Property(e => e.Zone).IsUnicode(false);
            });

            modelBuilder.Entity<temp_district>(entity =>
            {
                entity.Property(e => e.Name).IsUnicode(false);

                entity.Property(e => e.ShortName).IsUnicode(false);
            });

            modelBuilder.Entity<temp_taluk>(entity =>
            {
                entity.Property(e => e.DistrictName).IsUnicode(false);

                entity.Property(e => e.Name).IsUnicode(false);

                entity.Property(e => e.ShortName).IsUnicode(false);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
