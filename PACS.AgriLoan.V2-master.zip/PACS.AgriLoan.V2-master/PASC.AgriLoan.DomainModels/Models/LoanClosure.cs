﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Table("LoanClosure")]
    public partial class LoanClosure
    {
        [Key]
        public long Id { get; set; }
        public long IssueId { get; set; }
        [Required]
        [StringLength(100)]
        public string ClosedDate { get; set; }
        [StringLength(500)]
        public string Comments { get; set; }
        public bool IsDeleted { get; set; }
        public int? CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        public int? ModifiedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDate { get; set; }

        [ForeignKey(nameof(IssueId))]
        [InverseProperty(nameof(LoanIssueHeader.LoanClosures))]
        public virtual LoanIssueHeader Issue { get; set; }
    }
}
