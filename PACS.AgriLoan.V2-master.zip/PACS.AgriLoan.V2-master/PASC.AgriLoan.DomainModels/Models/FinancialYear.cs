﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Table("FinancialYear")]
    public partial class FinancialYear
    {
        public FinancialYear()
        {
            DccbSanctionOrders = new HashSet<DccbSanctionOrder>();
            LoanIssueHeaders = new HashSet<LoanIssueHeader>();
            LoanReceiptHeaders = new HashSet<LoanReceiptHeader>();
            LoanRequestHeaders = new HashSet<LoanRequestHeader>();
            LoanSanctionHeaders = new HashSet<LoanSanctionHeader>();
        }

        [Key]
        public long Id { get; set; }
        public int FYear { get; set; }
        [Required]
        [StringLength(9)]
        public string Name { get; set; }
        [Required]
        [StringLength(5)]
        public string ShortName { get; set; }
        [Column(TypeName = "date")]
        public DateTime StartDate { get; set; }
        [Column(TypeName = "date")]
        public DateTime EndDate { get; set; }
        public bool IsDeleted { get; set; }
        public int? CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        public int? ModifiedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDate { get; set; }

        [InverseProperty(nameof(DccbSanctionOrder.FYear))]
        public virtual ICollection<DccbSanctionOrder> DccbSanctionOrders { get; set; }
        [InverseProperty(nameof(LoanIssueHeader.FYear))]
        public virtual ICollection<LoanIssueHeader> LoanIssueHeaders { get; set; }
        [InverseProperty(nameof(LoanReceiptHeader.FYear))]
        public virtual ICollection<LoanReceiptHeader> LoanReceiptHeaders { get; set; }
        [InverseProperty(nameof(LoanRequestHeader.FYear))]
        public virtual ICollection<LoanRequestHeader> LoanRequestHeaders { get; set; }
        [InverseProperty(nameof(LoanSanctionHeader.FYear))]
        public virtual ICollection<LoanSanctionHeader> LoanSanctionHeaders { get; set; }
    }
}
