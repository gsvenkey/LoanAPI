﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Table("JewelValuation")]
    public partial class JewelValuation
    {
        [Key]
        public long Id { get; set; }
        public long PacsId { get; set; }
        [Column(TypeName = "date")]
        public DateTime PriceDate { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal MarketPrice { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal PacsValue { get; set; }
        public int? CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        public int? ModifiedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDate { get; set; }

        [ForeignKey(nameof(PacsId))]
        [InverseProperty(nameof(PacsMaster.JewelValuations))]
        public virtual PacsMaster Pacs { get; set; }
    }
}
