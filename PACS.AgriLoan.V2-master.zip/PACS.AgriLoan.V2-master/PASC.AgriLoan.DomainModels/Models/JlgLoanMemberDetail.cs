﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    public partial class JlgLoanMemberDetail
    {
        [Key]
        public long Id { get; set; }
        public long LoanRequestId { get; set; }
        public long MemberId { get; set; }
        public bool IsDeleted { get; set; }
        public int? CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        public int? ModifiedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDate { get; set; }

        [ForeignKey(nameof(LoanRequestId))]
        [InverseProperty(nameof(LoanRequestHeader.JlgLoanMemberDetails))]
        public virtual LoanRequestHeader LoanRequest { get; set; }
        [ForeignKey(nameof(MemberId))]
        [InverseProperty(nameof(MemberMaster.JlgLoanMemberDetails))]
        public virtual MemberMaster Member { get; set; }
    }
}
