﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Table("LookupTypeMaster")]
    public partial class LookupTypeMaster
    {
        public LookupTypeMaster()
        {
            LookupCodeMasters = new HashSet<LookupCodeMaster>();
        }

        [Key]
        public long Id { get; set; }
        [StringLength(50)]
        public string Name { get; set; }
        [StringLength(20)]
        public string ShortName { get; set; }
        public int? CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        public int? ModifiedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDate { get; set; }
        public bool IsDeleted { get; set; }

        [InverseProperty(nameof(LookupCodeMaster.LoolkUpType))]
        public virtual ICollection<LookupCodeMaster> LookupCodeMasters { get; set; }
    }
}
