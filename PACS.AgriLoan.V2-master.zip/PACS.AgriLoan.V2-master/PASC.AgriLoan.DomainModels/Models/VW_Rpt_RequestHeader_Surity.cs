﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Keyless]
    public partial class VW_Rpt_RequestHeader_Surity
    {
        public long pacsId { get; set; }
        public long MemberId { get; set; }
        public long LoanTypeId { get; set; }
        [Required]
        [StringLength(50)]
        public string LoanType { get; set; }
        public long RequestId { get; set; }
        public long SanctionId { get; set; }
        public long FYearId { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal RequestAmount { get; set; }
        public long MemberNumber { get; set; }
        [Required]
        [StringLength(100)]
        public string MemberName { get; set; }
        [Required]
        [StringLength(50)]
        public string Address1 { get; set; }
        [Required]
        [StringLength(100)]
        public string Address2 { get; set; }
        [StringLength(100)]
        public string Address3 { get; set; }
        [StringLength(100)]
        public string Address4 { get; set; }
        [StringLength(100)]
        public string VillageName { get; set; }
        public int Pincode { get; set; }
        public long MobileNumber { get; set; }
        [StringLength(10)]
        public string PANNumber { get; set; }
        [StringLength(20)]
        public string SmartCardNumber { get; set; }
        public long AdhaarNumber { get; set; }
        public string PhotoUrl { get; set; }
        public long? SocietySBNumber { get; set; }
        public long? DCCBSBNumber { get; set; }
        public long SurityMemberNumber { get; set; }
        [Required]
        [StringLength(100)]
        public string SurityMemberName { get; set; }
        [Required]
        [StringLength(50)]
        public string SurityAddress1 { get; set; }
        [Required]
        [StringLength(100)]
        public string SurityAddress2 { get; set; }
        [StringLength(100)]
        public string SurityAddress3 { get; set; }
        [StringLength(100)]
        public string SurityAddress4 { get; set; }
        [StringLength(100)]
        public string SurityVillageName { get; set; }
        public int SurityPincode { get; set; }
        public long SurityMobileNumber { get; set; }
        [StringLength(10)]
        public string SurityPANNumber { get; set; }
        [StringLength(20)]
        public string SuritySmartCardNumber { get; set; }
        public long SurityAdhaarNumber { get; set; }
        public string SurityPhotoUrl { get; set; }
        public long? SuritySocietySBNumber { get; set; }
        public long? SurityDCCBSBNumber { get; set; }
        public long SanctionNo { get; set; }
        [Column(TypeName = "date")]
        public DateTime SanctionDate { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal SanctionAmount { get; set; }
        public int SDSCode { get; set; }
        [Required]
        [StringLength(150)]
        public string PacsName { get; set; }
        [Required]
        [StringLength(50)]
        public string PacsAddress1 { get; set; }
        [Required]
        [StringLength(50)]
        public string PacsAddress2 { get; set; }
        [Required]
        [StringLength(50)]
        public string PacsAddress3 { get; set; }
        [Required]
        [StringLength(50)]
        public string PacsAddress4 { get; set; }
        public int PacsPincode { get; set; }
    }
}
