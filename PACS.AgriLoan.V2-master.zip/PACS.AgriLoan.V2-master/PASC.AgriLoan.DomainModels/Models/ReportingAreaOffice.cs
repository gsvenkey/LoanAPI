﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Table("ReportingAreaOffice")]
    public partial class ReportingAreaOffice
    {
        [Key]
        public long Id { get; set; }
        public long DistrictId { get; set; }
        public long TalukId { get; set; }
        [Required]
        [StringLength(50)]
        public string Name { get; set; }
        [StringLength(15)]
        public string ShortName { get; set; }
        [Required]
        [StringLength(50)]
        public string NameInTamil { get; set; }
        public bool IsDeleted { get; set; }
        public int? CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        public int? ModifiedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDate { get; set; }

        [ForeignKey(nameof(DistrictId))]
        [InverseProperty(nameof(DistrictMaster.ReportingAreaOffices))]
        public virtual DistrictMaster District { get; set; }
        [ForeignKey(nameof(TalukId))]
        [InverseProperty(nameof(TalukMaster.ReportingAreaOffices))]
        public virtual TalukMaster Taluk { get; set; }
    }
}
