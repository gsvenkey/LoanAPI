﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Table("TieUpCompanyMaster")]
    public partial class TieUpCompanyMaster
    {
        public TieUpCompanyMaster()
        {
            TieUpCompanyDetails = new HashSet<TieUpCompanyDetail>();
        }

        [Key]
        public long Id { get; set; }
        public long DistrictId { get; set; }
        [Required]
        [StringLength(100)]
        public string CompanyName { get; set; }
        [Required]
        [StringLength(100)]
        public string CompanyAddress { get; set; }
        public long? ContactNo { get; set; }
        [Column(TypeName = "date")]
        public DateTime? LetterFromDate { get; set; }
        [Column(TypeName = "date")]
        public DateTime? LetterEndDate { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? MaxLoanAmount { get; set; }
        public bool IsDeleted { get; set; }
        public int? CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        public int? ModifiedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDate { get; set; }

        [ForeignKey(nameof(DistrictId))]
        [InverseProperty(nameof(DistrictMaster.TieUpCompanyMasters))]
        public virtual DistrictMaster District { get; set; }
        [InverseProperty(nameof(TieUpCompanyDetail.TieUpCompany))]
        public virtual ICollection<TieUpCompanyDetail> TieUpCompanyDetails { get; set; }
    }
}
