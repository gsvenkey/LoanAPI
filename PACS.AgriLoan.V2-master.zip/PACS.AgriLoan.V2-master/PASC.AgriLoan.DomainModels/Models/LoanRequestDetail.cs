﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Table("LoanRequestDetail")]
    public partial class LoanRequestDetail
    {
        [Key]
        public long Id { get; set; }
        public long LoanRequestId { get; set; }
        public long CropId { get; set; }
        [Required]
        [StringLength(50)]
        public string SurveyNo { get; set; }
        [Column(TypeName = "numeric(5, 2)")]
        public decimal Acre { get; set; }
        [Column(TypeName = "numeric(5, 2)")]
        public decimal CultivationAcre { get; set; }
        public bool IsDeleted { get; set; }
        public int? CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        public int? ModifiedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDate { get; set; }

        [ForeignKey(nameof(CropId))]
        [InverseProperty(nameof(CropMaster.LoanRequestDetails))]
        public virtual CropMaster Crop { get; set; }
        [ForeignKey(nameof(LoanRequestId))]
        [InverseProperty(nameof(LoanRequestHeader.LoanRequestDetails))]
        public virtual LoanRequestHeader LoanRequest { get; set; }
    }
}
