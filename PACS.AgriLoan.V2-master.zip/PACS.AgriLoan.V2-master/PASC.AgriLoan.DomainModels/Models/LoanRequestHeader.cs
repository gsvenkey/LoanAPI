﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Table("LoanRequestHeader")]
    [Index(nameof(PacsId), nameof(RequestNo), nameof(LoanTypeID), Name = "UC_LoanRequestHeader_RequestNo", IsUnique = true)]
    public partial class LoanRequestHeader
    {
        public LoanRequestHeader()
        {
            JewelPledgedDetails = new HashSet<JewelPledgedDetail>();
            JlgLoanMemberDetails = new HashSet<JlgLoanMemberDetail>();
            JlgLoanTypeDetails = new HashSet<JlgLoanTypeDetail>();
            LandPledgedDetails = new HashSet<LandPledgedDetail>();
            LoanRequestDetails = new HashSet<LoanRequestDetail>();
            LoanSanctionHeaders = new HashSet<LoanSanctionHeader>();
            SuretyDetails = new HashSet<SuretyDetail>();
            TieUpCompanyDetails = new HashSet<TieUpCompanyDetail>();
        }

        [Key]
        public long Id { get; set; }
        public long RequestNo { get; set; }
        public long PacsId { get; set; }
        public long FYearId { get; set; }
        [Column(TypeName = "date")]
        public DateTime RequestDate { get; set; }
        public long LoanTypeID { get; set; }
        public long MemberID { get; set; }
        public bool IsAdangal { get; set; }
        public int PasalaiYear { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal RequestAmount { get; set; }
        public bool IsDeleted { get; set; }
        public int? CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        public int? ModifiedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDate { get; set; }

        [ForeignKey(nameof(FYearId))]
        [InverseProperty(nameof(FinancialYear.LoanRequestHeaders))]
        public virtual FinancialYear FYear { get; set; }
        [ForeignKey(nameof(LoanTypeID))]
        [InverseProperty(nameof(LoanTypeMaster.LoanRequestHeaders))]
        public virtual LoanTypeMaster LoanType { get; set; }
        [ForeignKey(nameof(MemberID))]
        [InverseProperty(nameof(MemberMaster.LoanRequestHeaders))]
        public virtual MemberMaster Member { get; set; }
        [ForeignKey(nameof(PacsId))]
        [InverseProperty(nameof(PacsMaster.LoanRequestHeaders))]
        public virtual PacsMaster Pacs { get; set; }
        [InverseProperty(nameof(JewelPledgedDetail.LoanRequest))]
        public virtual ICollection<JewelPledgedDetail> JewelPledgedDetails { get; set; }
        [InverseProperty(nameof(JlgLoanMemberDetail.LoanRequest))]
        public virtual ICollection<JlgLoanMemberDetail> JlgLoanMemberDetails { get; set; }
        [InverseProperty(nameof(JlgLoanTypeDetail.LoanRequest))]
        public virtual ICollection<JlgLoanTypeDetail> JlgLoanTypeDetails { get; set; }
        [InverseProperty(nameof(LandPledgedDetail.LoanRequest))]
        public virtual ICollection<LandPledgedDetail> LandPledgedDetails { get; set; }
        [InverseProperty(nameof(LoanRequestDetail.LoanRequest))]
        public virtual ICollection<LoanRequestDetail> LoanRequestDetails { get; set; }
        [InverseProperty(nameof(LoanSanctionHeader.LoanRequest))]
        public virtual ICollection<LoanSanctionHeader> LoanSanctionHeaders { get; set; }
        [InverseProperty(nameof(SuretyDetail.LoanRequest))]
        public virtual ICollection<SuretyDetail> SuretyDetails { get; set; }
        [InverseProperty(nameof(TieUpCompanyDetail.LoanRequest))]
        public virtual ICollection<TieUpCompanyDetail> TieUpCompanyDetails { get; set; }
    }
}
