﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Table("MemberMaster")]
    [Index(nameof(AdhaarNumber), Name = "UC_MemberMaster_AdhaarNumber", IsUnique = true)]
    [Index(nameof(PacsId), nameof(MemberNumber), Name = "UC_MemberMaster_MemberNumber", IsUnique = true)]
    [Index(nameof(PANNumber), Name = "UC_MemberMaster_PANNumber", IsUnique = true)]
    [Index(nameof(SmartCardNumber), Name = "UC_MemberMaster_SmartCardNumber", IsUnique = true)]
    public partial class MemberMaster
    {
        public MemberMaster()
        {
            JlgDetails = new HashSet<JlgDetail>();
            JlgHeaders = new HashSet<JlgHeader>();
            JlgLoanMemberDetails = new HashSet<JlgLoanMemberDetail>();
            JlgLoanTypeDetails = new HashSet<JlgLoanTypeDetail>();
            LoanIssueHeaders = new HashSet<LoanIssueHeader>();
            LoanReceipts = new HashSet<LoanReceipt>();
            LoanRequestHeaders = new HashSet<LoanRequestHeader>();
            LoanSanctionHeaders = new HashSet<LoanSanctionHeader>();
            SuretyDetails = new HashSet<SuretyDetail>();
            VaoCertificateHeaders = new HashSet<VaoCertificateHeader>();
        }

        [Key]
        public long Id { get; set; }
        public long PacsId { get; set; }
        public long ShareTypeId { get; set; }
        public long MembershipTypeId { get; set; }
        [Column(TypeName = "date")]
        public DateTime DateofMembership { get; set; }
        public long MemberNumber { get; set; }
        [Required]
        [StringLength(100)]
        public string Name { get; set; }
        [Required]
        [StringLength(100)]
        public string NameFatherOrHusband { get; set; }
        [Required]
        [StringLength(50)]
        public string Address1 { get; set; }
        [Required]
        [StringLength(100)]
        public string Address2 { get; set; }
        [StringLength(100)]
        public string Address3 { get; set; }
        [StringLength(100)]
        public string Address4 { get; set; }
        [StringLength(100)]
        public string VillageName { get; set; }
        public int Pincode { get; set; }
        public long GenderId { get; set; }
        public long ReligionId { get; set; }
        public long CommunityId { get; set; }
        public long AdhaarNumber { get; set; }
        [StringLength(10)]
        public string PANNumber { get; set; }
        [StringLength(20)]
        public string SmartCardNumber { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal ShareAmount { get; set; }
        public long MobileNumber { get; set; }
        public long SocietySBNumber { get; set; }
        public long DCCBSBNumber { get; set; }
        public long DCCBSBCIFNumber { get; set; }
        public long DCCBLSBACNumber { get; set; }
        public bool IsBoardMember { get; set; }
        public bool IsAgriWaiverAvailed { get; set; }
        public bool IsJointLiabilityGroupMember { get; set; }
        public string PhotoUrl { get; set; }
        public bool IsDeleted { get; set; }
        public int? CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        public int? ModifiedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDate { get; set; }

        [ForeignKey(nameof(CommunityId))]
        [InverseProperty(nameof(LookupCodeMaster.MemberMasterCommunities))]
        public virtual LookupCodeMaster Community { get; set; }
        [ForeignKey(nameof(GenderId))]
        [InverseProperty(nameof(LookupCodeMaster.MemberMasterGenders))]
        public virtual LookupCodeMaster Gender { get; set; }
        [ForeignKey(nameof(MembershipTypeId))]
        [InverseProperty(nameof(LookupCodeMaster.MemberMasterMembershipTypes))]
        public virtual LookupCodeMaster MembershipType { get; set; }
        [ForeignKey(nameof(PacsId))]
        [InverseProperty(nameof(PacsMaster.MemberMasters))]
        public virtual PacsMaster Pacs { get; set; }
        [ForeignKey(nameof(ReligionId))]
        [InverseProperty(nameof(LookupCodeMaster.MemberMasterReligions))]
        public virtual LookupCodeMaster Religion { get; set; }
        [ForeignKey(nameof(ShareTypeId))]
        [InverseProperty(nameof(LookupCodeMaster.MemberMasterShareTypes))]
        public virtual LookupCodeMaster ShareType { get; set; }
        [InverseProperty(nameof(JlgDetail.Member))]
        public virtual ICollection<JlgDetail> JlgDetails { get; set; }
        [InverseProperty(nameof(JlgHeader.UkkunarMember))]
        public virtual ICollection<JlgHeader> JlgHeaders { get; set; }
        [InverseProperty(nameof(JlgLoanMemberDetail.Member))]
        public virtual ICollection<JlgLoanMemberDetail> JlgLoanMemberDetails { get; set; }
        [InverseProperty(nameof(JlgLoanTypeDetail.Member))]
        public virtual ICollection<JlgLoanTypeDetail> JlgLoanTypeDetails { get; set; }
        [InverseProperty(nameof(LoanIssueHeader.Member))]
        public virtual ICollection<LoanIssueHeader> LoanIssueHeaders { get; set; }
        [InverseProperty(nameof(LoanReceipt.Member))]
        public virtual ICollection<LoanReceipt> LoanReceipts { get; set; }
        [InverseProperty(nameof(LoanRequestHeader.Member))]
        public virtual ICollection<LoanRequestHeader> LoanRequestHeaders { get; set; }
        [InverseProperty(nameof(LoanSanctionHeader.Member))]
        public virtual ICollection<LoanSanctionHeader> LoanSanctionHeaders { get; set; }
        [InverseProperty(nameof(SuretyDetail.Member))]
        public virtual ICollection<SuretyDetail> SuretyDetails { get; set; }
        [InverseProperty(nameof(VaoCertificateHeader.Member))]
        public virtual ICollection<VaoCertificateHeader> VaoCertificateHeaders { get; set; }
    }
}
