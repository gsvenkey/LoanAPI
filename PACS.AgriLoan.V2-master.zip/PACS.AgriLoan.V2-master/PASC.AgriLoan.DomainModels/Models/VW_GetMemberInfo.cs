﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Keyless]
    public partial class VW_GetMemberInfo
    {
        public long Id { get; set; }
        public long MemberNumber { get; set; }
        [Required]
        [StringLength(100)]
        public string Name { get; set; }
        [Required]
        [StringLength(50)]
        public string Address1 { get; set; }
        [Required]
        [StringLength(100)]
        public string Address2 { get; set; }
        [StringLength(100)]
        public string Address3 { get; set; }
        [StringLength(100)]
        public string Address4 { get; set; }
        public int Pincode { get; set; }
        public long MobileNumber { get; set; }
        public long AdhaarNumber { get; set; }
        public string PhotoUrl { get; set; }
    }
}
