﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Table("LoanReceiptDetail")]
    public partial class LoanReceiptDetail
    {
        [Key]
        public long Id { get; set; }
        public long ReceiptId { get; set; }
        [Column(TypeName = "date")]
        public DateTime ReceiptDate { get; set; }
        public long ReceiptNo { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal Principal { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? Interest { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? PenalInterest { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? Noticecharge { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? ARCFees { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? EPFees { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? OtherFees { get; set; }
        public bool IsDeleted { get; set; }
        public int? CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        public int? ModifiedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDate { get; set; }

        [ForeignKey(nameof(ReceiptId))]
        [InverseProperty(nameof(LoanReceiptHeader.LoanReceiptDetails))]
        public virtual LoanReceiptHeader Receipt { get; set; }
    }
}
