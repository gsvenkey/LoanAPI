﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Table("DccbBankMaster")]
    public partial class DccbBankMaster
    {
        public DccbBankMaster()
        {
            InverseHo = new HashSet<DccbBankMaster>();
            PacsMasters = new HashSet<PacsMaster>();
        }

        [Key]
        public long Id { get; set; }
        public long DistrictId { get; set; }
        public int SDSCode { get; set; }
        public bool IsHo { get; set; }
        public long? HoID { get; set; }
        [Required]
        [StringLength(50)]
        public string Name { get; set; }
        [StringLength(15)]
        public string ShortName { get; set; }
        [Required]
        [StringLength(50)]
        public string NameInTamil { get; set; }
        [Required]
        [StringLength(50)]
        public string Address1 { get; set; }
        [Required]
        [StringLength(50)]
        public string Address2 { get; set; }
        [StringLength(50)]
        public string Address3 { get; set; }
        [StringLength(50)]
        public string Address4 { get; set; }
        [Required]
        [StringLength(6)]
        public string PinCode { get; set; }
        [StringLength(15)]
        public string PhoneNo { get; set; }
        public bool IsDeleted { get; set; }
        public int? CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        public int? ModifiedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDate { get; set; }

        [ForeignKey(nameof(DistrictId))]
        [InverseProperty(nameof(DistrictMaster.DccbBankMasters))]
        public virtual DistrictMaster District { get; set; }
        [ForeignKey(nameof(HoID))]
        [InverseProperty(nameof(DccbBankMaster.InverseHo))]
        public virtual DccbBankMaster Ho { get; set; }
        [InverseProperty(nameof(DccbBankMaster.Ho))]
        public virtual ICollection<DccbBankMaster> InverseHo { get; set; }
        [InverseProperty(nameof(PacsMaster.Dccb))]
        public virtual ICollection<PacsMaster> PacsMasters { get; set; }
    }
}
