﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Keyless]
    [Table("temp_Crop")]
    public partial class temp_Crop
    {
        public long? Id { get; set; }
        public string Category { get; set; }
        [StringLength(100)]
        public string CropName { get; set; }
        public string CropNameInTamil { get; set; }
        [Column(TypeName = "date")]
        public DateTime? PeriodFrom { get; set; }
        [Column(TypeName = "date")]
        public DateTime? PeriodTo { get; set; }
        public int? LoanDuePeriod { get; set; }
        public string Result { get; set; }
        public bool? outputstatus { get; set; }
    }
}
