﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Table("LandInVillageMaster")]
    public partial class LandInVillageMaster
    {
        public LandInVillageMaster()
        {
            VaoCertificateHeaders = new HashSet<VaoCertificateHeader>();
        }

        [Key]
        public long Id { get; set; }
        public long RevenueVillageId { get; set; }
        [Required]
        [StringLength(50)]
        public string Name { get; set; }
        [StringLength(50)]
        public string ShortName { get; set; }
        [Required]
        [StringLength(50)]
        public string NameInTamil { get; set; }
        public bool IsDeleted { get; set; }
        public int? CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        public int? ModifiedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDate { get; set; }

        [ForeignKey(nameof(RevenueVillageId))]
        [InverseProperty(nameof(RevenueVillageMaster.LandInVillageMasters))]
        public virtual RevenueVillageMaster RevenueVillage { get; set; }
        [InverseProperty(nameof(VaoCertificateHeader.LandInVillage))]
        public virtual ICollection<VaoCertificateHeader> VaoCertificateHeaders { get; set; }
    }
}
