﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Keyless]
    [Table("temp_SubRegister")]
    public partial class temp_SubRegister
    {
        public long? Id { get; set; }
        [StringLength(100)]
        public string Zone { get; set; }
        [StringLength(100)]
        public string DistrictName { get; set; }
        [StringLength(100)]
        public string DistrictNameintamil { get; set; }
        [StringLength(100)]
        public string Name { get; set; }
        [StringLength(100)]
        public string NameInTamil { get; set; }
        public string Result { get; set; }
        public bool? OutPutStatus { get; set; }
    }
}
