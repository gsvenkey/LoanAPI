﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Table("LoanSanctionHeader")]
    public partial class LoanSanctionHeader
    {
        public LoanSanctionHeader()
        {
            LoanIssueDetails = new HashSet<LoanIssueDetail>();
            LoanIssueHeaders = new HashSet<LoanIssueHeader>();
        }

        [Key]
        public long Id { get; set; }
        public long LoanRequestId { get; set; }
        public long PacsId { get; set; }
        public long FYearId { get; set; }
        public long SanctionNo { get; set; }
        [Column(TypeName = "date")]
        public DateTime SanctionDate { get; set; }
        public long MemberID { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal SanctionAmount { get; set; }
        public bool IsDeleted { get; set; }
        public int? CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        public int? ModifiedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDate { get; set; }

        [ForeignKey(nameof(FYearId))]
        [InverseProperty(nameof(FinancialYear.LoanSanctionHeaders))]
        public virtual FinancialYear FYear { get; set; }
        [ForeignKey(nameof(LoanRequestId))]
        [InverseProperty(nameof(LoanRequestHeader.LoanSanctionHeaders))]
        public virtual LoanRequestHeader LoanRequest { get; set; }
        [ForeignKey(nameof(MemberID))]
        [InverseProperty(nameof(MemberMaster.LoanSanctionHeaders))]
        public virtual MemberMaster Member { get; set; }
        [ForeignKey(nameof(PacsId))]
        [InverseProperty(nameof(PacsMaster.LoanSanctionHeaders))]
        public virtual PacsMaster Pacs { get; set; }
        [InverseProperty(nameof(LoanIssueDetail.Sanction))]
        public virtual ICollection<LoanIssueDetail> LoanIssueDetails { get; set; }
        [InverseProperty(nameof(LoanIssueHeader.Sanction))]
        public virtual ICollection<LoanIssueHeader> LoanIssueHeaders { get; set; }
    }
}
