﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Table("LoanReceiptHeader")]
    public partial class LoanReceiptHeader
    {
        public LoanReceiptHeader()
        {
            LoanReceiptDetails = new HashSet<LoanReceiptDetail>();
        }

        [Key]
        public long Id { get; set; }
        public long PacsId { get; set; }
        public long FYearId { get; set; }
        public long MemberID { get; set; }
        public long IssueId { get; set; }
        public long LoanTypeID { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal IssueAmount { get; set; }
        public bool IsDeleted { get; set; }
        public int? CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        public int? ModifiedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDate { get; set; }

        [ForeignKey(nameof(FYearId))]
        [InverseProperty(nameof(FinancialYear.LoanReceiptHeaders))]
        public virtual FinancialYear FYear { get; set; }
        [ForeignKey(nameof(IssueId))]
        [InverseProperty(nameof(LoanIssueHeader.LoanReceiptHeaders))]
        public virtual LoanIssueHeader Issue { get; set; }
        [ForeignKey(nameof(LoanTypeID))]
        [InverseProperty(nameof(LoanTypeMaster.LoanReceiptHeaders))]
        public virtual LoanTypeMaster LoanType { get; set; }
        [ForeignKey(nameof(MemberID))]
        [InverseProperty(nameof(MemberMaster.LoanReceiptHeaders))]
        public virtual MemberMaster Member { get; set; }
        [ForeignKey(nameof(PacsId))]
        [InverseProperty(nameof(PacsMaster.LoanReceiptHeaders))]
        public virtual PacsMaster Pacs { get; set; }
        [InverseProperty(nameof(LoanReceiptDetail.Receipt))]
        public virtual ICollection<LoanReceiptDetail> LoanReceiptDetails { get; set; }
    }
}
