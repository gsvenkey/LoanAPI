﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Keyless]
    public partial class VW_GetLoanRequestHeader
    {
        public long Id { get; set; }
        public long RequestNo { get; set; }
        public long PacsId { get; set; }
        public long FYearId { get; set; }
        [Column(TypeName = "date")]
        public DateTime RequestDate { get; set; }
        public long LoanTypeID { get; set; }
        [Required]
        [StringLength(50)]
        public string LoanTypeName { get; set; }
        [Required]
        [StringLength(50)]
        public string LoanTypeNameInTamil { get; set; }
        public long VaoCertificateHeaderId { get; set; }
        public long MemberID { get; set; }
        [Required]
        [StringLength(100)]
        public string MemberName { get; set; }
    }
}
