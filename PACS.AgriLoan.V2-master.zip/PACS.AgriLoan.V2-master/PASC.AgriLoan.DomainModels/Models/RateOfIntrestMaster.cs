﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Table("RateOfIntrestMaster")]
    public partial class RateOfIntrestMaster
    {
        public RateOfIntrestMaster()
        {
            LoanIssueHeaders = new HashSet<LoanIssueHeader>();
        }

        [Key]
        public long Id { get; set; }
        public long LoanTypeId { get; set; }
        [Column(TypeName = "date")]
        public DateTime EffectFrom { get; set; }
        [Column(TypeName = "numeric(5, 2)")]
        public decimal Normal { get; set; }
        [Column(TypeName = "numeric(5, 2)")]
        public decimal Penal { get; set; }
        public bool IsDeleted { get; set; }
        public int? CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        public int? ModifiedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDate { get; set; }

        [ForeignKey(nameof(LoanTypeId))]
        [InverseProperty(nameof(LoanTypeMaster.RateOfIntrestMasters))]
        public virtual LoanTypeMaster LoanType { get; set; }
        [InverseProperty(nameof(LoanIssueHeader.RateOfInterest))]
        public virtual ICollection<LoanIssueHeader> LoanIssueHeaders { get; set; }
    }
}
