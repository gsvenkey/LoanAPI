﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Keyless]
    [Table("temp_CropCategory")]
    public partial class temp_CropCategory
    {
        public long? Id { get; set; }
        [StringLength(100)]
        public string Category { get; set; }
        public string CategoryInTamil { get; set; }
        public string Result { get; set; }
        public bool? outputstatus { get; set; }
    }
}
