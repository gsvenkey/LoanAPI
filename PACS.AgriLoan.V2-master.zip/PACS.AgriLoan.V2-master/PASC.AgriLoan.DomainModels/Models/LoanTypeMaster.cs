﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Table("LoanTypeMaster")]
    public partial class LoanTypeMaster
    {
        public LoanTypeMaster()
        {
            DccbSanctionOrders = new HashSet<DccbSanctionOrder>();
            LoanIssueHeaders = new HashSet<LoanIssueHeader>();
            LoanReceiptHeaders = new HashSet<LoanReceiptHeader>();
            LoanRequestHeaders = new HashSet<LoanRequestHeader>();
            LoanSanctionHeaders = new HashSet<LoanSanctionHeader>();
            RateOfIntrestMasters = new HashSet<RateOfIntrestMaster>();
        }

        [Key]
        public long Id { get; set; }
        [Required]
        [StringLength(50)]
        public string Name { get; set; }
        [Required]
        [StringLength(2)]
        public string Code { get; set; }
        [Required]
        [StringLength(10)]
        public string ShortName { get; set; }
        [Required]
        [StringLength(50)]
        public string NameInTamil { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal MaximumLimit { get; set; }
        public bool IsDeleted { get; set; }
        public int? CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        public int? ModifiedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDate { get; set; }

        [InverseProperty(nameof(DccbSanctionOrder.LoanType))]
        public virtual ICollection<DccbSanctionOrder> DccbSanctionOrders { get; set; }
        [InverseProperty(nameof(LoanIssueHeader.LoanType))]
        public virtual ICollection<LoanIssueHeader> LoanIssueHeaders { get; set; }
        [InverseProperty(nameof(LoanReceiptHeader.LoanType))]
        public virtual ICollection<LoanReceiptHeader> LoanReceiptHeaders { get; set; }
        [InverseProperty(nameof(LoanRequestHeader.LoanType))]
        public virtual ICollection<LoanRequestHeader> LoanRequestHeaders { get; set; }
        [InverseProperty(nameof(LoanSanctionHeader.LoanType))]
        public virtual ICollection<LoanSanctionHeader> LoanSanctionHeaders { get; set; }
        [InverseProperty(nameof(RateOfIntrestMaster.LoanType))]
        public virtual ICollection<RateOfIntrestMaster> RateOfIntrestMasters { get; set; }
    }
}
