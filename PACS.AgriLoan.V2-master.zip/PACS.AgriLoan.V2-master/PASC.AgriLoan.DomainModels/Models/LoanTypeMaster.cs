﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Table("LoanTypeMaster")]
    public partial class LoanTypeMaster
    {
        public LoanTypeMaster()
        {
            DccbSanctionOrders = new HashSet<DccbSanctionOrder>();
            LoanRequestHeaders = new HashSet<LoanRequestHeader>();
            LoanTypeLimtationMasters = new HashSet<LoanTypeLimtationMaster>();
        }

        [Key]
        public long Id { get; set; }
        [Required]
        [StringLength(50)]
        public string Name { get; set; }
        [Required]
        [StringLength(10)]
        public string ShortName { get; set; }
        [Required]
        [StringLength(50)]
        public string NameInTamil { get; set; }
        public bool IsDeleted { get; set; }
        public int? CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        public int? ModifiedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDate { get; set; }

        [InverseProperty(nameof(DccbSanctionOrder.LoanType))]
        public virtual ICollection<DccbSanctionOrder> DccbSanctionOrders { get; set; }
        [InverseProperty(nameof(LoanRequestHeader.LoanType))]
        public virtual ICollection<LoanRequestHeader> LoanRequestHeaders { get; set; }
        [InverseProperty(nameof(LoanTypeLimtationMaster.LoanType))]
        public virtual ICollection<LoanTypeLimtationMaster> LoanTypeLimtationMasters { get; set; }
    }
}
