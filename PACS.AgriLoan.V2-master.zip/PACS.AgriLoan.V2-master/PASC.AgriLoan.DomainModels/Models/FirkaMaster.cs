﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Table("FirkaMaster")]
    public partial class FirkaMaster
    {
        public FirkaMaster()
        {
            RevenueVillageMasters = new HashSet<RevenueVillageMaster>();
            VaoCertificateHeaders = new HashSet<VaoCertificateHeader>();
        }

        [Key]
        public long Id { get; set; }
        public long TalukId { get; set; }
        [Required]
        [StringLength(100)]
        public string Name { get; set; }
        [Required]
        [StringLength(100)]
        public string NameInTamil { get; set; }
        public bool IsDeleted { get; set; }
        public int? CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        public int? ModifiedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDate { get; set; }

        [ForeignKey(nameof(TalukId))]
        [InverseProperty(nameof(TalukMaster.FirkaMasters))]
        public virtual TalukMaster Taluk { get; set; }
        [InverseProperty(nameof(RevenueVillageMaster.Firka))]
        public virtual ICollection<RevenueVillageMaster> RevenueVillageMasters { get; set; }
        [InverseProperty(nameof(VaoCertificateHeader.Firka))]
        public virtual ICollection<VaoCertificateHeader> VaoCertificateHeaders { get; set; }
    }
}
