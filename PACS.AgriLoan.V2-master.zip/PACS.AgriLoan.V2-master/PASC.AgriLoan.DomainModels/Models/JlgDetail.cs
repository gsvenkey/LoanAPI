﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Table("JlgDetail")]
    public partial class JlgDetail
    {
        [Key]
        public long Id { get; set; }
        public long JlgId { get; set; }
        public long MemberId { get; set; }
        public long JlgMemberTypeId { get; set; }
        [Column(TypeName = "date")]
        public DateTime JoiningDate { get; set; }
        public bool IsDeleted { get; set; }
        public int? CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        public int? ModifiedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDate { get; set; }

        [ForeignKey(nameof(JlgId))]
        [InverseProperty(nameof(JlgHeader.JlgDetails))]
        public virtual JlgHeader Jlg { get; set; }
        [ForeignKey(nameof(JlgMemberTypeId))]
        [InverseProperty(nameof(LookupCodeMaster.JlgDetails))]
        public virtual LookupCodeMaster JlgMemberType { get; set; }
        [ForeignKey(nameof(MemberId))]
        [InverseProperty(nameof(MemberMaster.JlgDetails))]
        public virtual MemberMaster Member { get; set; }
    }
}
