﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Table("VaoCertificateHeader")]
    public partial class VaoCertificateHeader
    {
        public VaoCertificateHeader()
        {
            LoanRequestHeaders = new HashSet<LoanRequestHeader>();
            VaoCertificateDetails = new HashSet<VaoCertificateDetail>();
        }

        [Key]
        public long Id { get; set; }
        public long MemberId { get; set; }
        [Column(TypeName = "date")]
        public DateTime DateOfEntry { get; set; }
        [Column(TypeName = "date")]
        public DateTime CertificateDate { get; set; }
        public long FirkaId { get; set; }
        public long RevenueVillageId { get; set; }
        [StringLength(100)]
        public string LandInVillage { get; set; }
        public long OwnerShipTypeId { get; set; }
        public long IrrigationTypeId { get; set; }
        [Column(TypeName = "numeric(5, 2)")]
        public decimal Acre { get; set; }
        public bool IsDeleted { get; set; }
        public int? CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        public int? ModifiedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDate { get; set; }

        [ForeignKey(nameof(FirkaId))]
        [InverseProperty(nameof(FirkaMaster.VaoCertificateHeaders))]
        public virtual FirkaMaster Firka { get; set; }
        [ForeignKey(nameof(IrrigationTypeId))]
        [InverseProperty(nameof(LookupCodeMaster.VaoCertificateHeaderIrrigationTypes))]
        public virtual LookupCodeMaster IrrigationType { get; set; }
        [ForeignKey(nameof(MemberId))]
        [InverseProperty(nameof(MemberMaster.VaoCertificateHeaders))]
        public virtual MemberMaster Member { get; set; }
        [ForeignKey(nameof(OwnerShipTypeId))]
        [InverseProperty(nameof(LookupCodeMaster.VaoCertificateHeaderOwnerShipTypes))]
        public virtual LookupCodeMaster OwnerShipType { get; set; }
        [ForeignKey(nameof(RevenueVillageId))]
        [InverseProperty(nameof(RevenueVillageMaster.VaoCertificateHeaders))]
        public virtual RevenueVillageMaster RevenueVillage { get; set; }
        [InverseProperty(nameof(LoanRequestHeader.VaoCertificateHeader))]
        public virtual ICollection<LoanRequestHeader> LoanRequestHeaders { get; set; }
        [InverseProperty(nameof(VaoCertificateDetail.VaoCertificate))]
        public virtual ICollection<VaoCertificateDetail> VaoCertificateDetails { get; set; }
    }
}
