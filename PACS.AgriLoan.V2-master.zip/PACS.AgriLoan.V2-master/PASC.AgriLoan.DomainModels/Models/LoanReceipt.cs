﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Table("LoanReceipt")]
    public partial class LoanReceipt
    {
        [Key]
        public long Id { get; set; }
        public long PacsId { get; set; }
        public long FYearId { get; set; }
        public long MemberID { get; set; }
        public long IssueId { get; set; }
        [StringLength(20)]
        public string LoanNo { get; set; }
        [Column(TypeName = "date")]
        public DateTime ReceiptDate { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal Principal { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? Interest { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? PenalInterest { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? Noticecharge { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? ARCFees { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? EPFees { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? OtherFees { get; set; }
        public bool IsDeleted { get; set; }
        public int? CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        public int? ModifiedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDate { get; set; }

        [ForeignKey(nameof(FYearId))]
        [InverseProperty(nameof(FinancialYear.LoanReceipts))]
        public virtual FinancialYear FYear { get; set; }
        [ForeignKey(nameof(IssueId))]
        [InverseProperty(nameof(LoanIssueHeader.LoanReceipts))]
        public virtual LoanIssueHeader Issue { get; set; }
        [ForeignKey(nameof(MemberID))]
        [InverseProperty(nameof(MemberMaster.LoanReceipts))]
        public virtual MemberMaster Member { get; set; }
        [ForeignKey(nameof(PacsId))]
        [InverseProperty(nameof(PacsMaster.LoanReceipts))]
        public virtual PacsMaster Pacs { get; set; }
    }
}
