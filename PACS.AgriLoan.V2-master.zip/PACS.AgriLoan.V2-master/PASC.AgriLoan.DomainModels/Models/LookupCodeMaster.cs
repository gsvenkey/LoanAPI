﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Table("LookupCodeMaster")]
    public partial class LookupCodeMaster
    {
        public LookupCodeMaster()
        {
            EmployeeMasterDesignations = new HashSet<EmployeeMaster>();
            EmployeeMasterRoles = new HashSet<EmployeeMaster>();
            InverseParent = new HashSet<LookupCodeMaster>();
            JlgDetails = new HashSet<JlgDetail>();
            MemberMasterCommunities = new HashSet<MemberMaster>();
            MemberMasterGenders = new HashSet<MemberMaster>();
            MemberMasterMembershipTypes = new HashSet<MemberMaster>();
            MemberMasterRelationShips = new HashSet<MemberMaster>();
            MemberMasterReligions = new HashSet<MemberMaster>();
            MemberMasterShareTypes = new HashSet<MemberMaster>();
            MenuMasters = new HashSet<MenuMaster>();
            RoleMenuMasters = new HashSet<RoleMenuMaster>();
            VaoCertificateHeaderIrrigationTypes = new HashSet<VaoCertificateHeader>();
            VaoCertificateHeaderOwnerShipTypes = new HashSet<VaoCertificateHeader>();
        }

        [Key]
        public long Id { get; set; }
        public long LoolkUpTypeId { get; set; }
        [Required]
        [StringLength(50)]
        public string Name { get; set; }
        public long? ParentId { get; set; }
        [StringLength(20)]
        public string ShortName { get; set; }
        [StringLength(25)]
        public string NameInTamil { get; set; }
        [StringLength(50)]
        public string PrintName { get; set; }
        [StringLength(20)]
        public string PrintNameInTamil { get; set; }
        public int? CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        public int? ModifiedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDate { get; set; }
        public bool IsDeleted { get; set; }

        [ForeignKey(nameof(LoolkUpTypeId))]
        [InverseProperty(nameof(LookupTypeMaster.LookupCodeMasters))]
        public virtual LookupTypeMaster LoolkUpType { get; set; }
        [ForeignKey(nameof(ParentId))]
        [InverseProperty(nameof(LookupCodeMaster.InverseParent))]
        public virtual LookupCodeMaster Parent { get; set; }
        [InverseProperty(nameof(EmployeeMaster.Designation))]
        public virtual ICollection<EmployeeMaster> EmployeeMasterDesignations { get; set; }
        [InverseProperty(nameof(EmployeeMaster.Role))]
        public virtual ICollection<EmployeeMaster> EmployeeMasterRoles { get; set; }
        [InverseProperty(nameof(LookupCodeMaster.Parent))]
        public virtual ICollection<LookupCodeMaster> InverseParent { get; set; }
        [InverseProperty(nameof(JlgDetail.JlgMemberType))]
        public virtual ICollection<JlgDetail> JlgDetails { get; set; }
        [InverseProperty(nameof(MemberMaster.Community))]
        public virtual ICollection<MemberMaster> MemberMasterCommunities { get; set; }
        [InverseProperty(nameof(MemberMaster.Gender))]
        public virtual ICollection<MemberMaster> MemberMasterGenders { get; set; }
        [InverseProperty(nameof(MemberMaster.MembershipType))]
        public virtual ICollection<MemberMaster> MemberMasterMembershipTypes { get; set; }
        [InverseProperty(nameof(MemberMaster.RelationShip))]
        public virtual ICollection<MemberMaster> MemberMasterRelationShips { get; set; }
        [InverseProperty(nameof(MemberMaster.Religion))]
        public virtual ICollection<MemberMaster> MemberMasterReligions { get; set; }
        [InverseProperty(nameof(MemberMaster.ShareType))]
        public virtual ICollection<MemberMaster> MemberMasterShareTypes { get; set; }
        [InverseProperty(nameof(MenuMaster.MenuType))]
        public virtual ICollection<MenuMaster> MenuMasters { get; set; }
        [InverseProperty(nameof(RoleMenuMaster.Role))]
        public virtual ICollection<RoleMenuMaster> RoleMenuMasters { get; set; }
        [InverseProperty(nameof(VaoCertificateHeader.IrrigationType))]
        public virtual ICollection<VaoCertificateHeader> VaoCertificateHeaderIrrigationTypes { get; set; }
        [InverseProperty(nameof(VaoCertificateHeader.OwnerShipType))]
        public virtual ICollection<VaoCertificateHeader> VaoCertificateHeaderOwnerShipTypes { get; set; }
    }
}
