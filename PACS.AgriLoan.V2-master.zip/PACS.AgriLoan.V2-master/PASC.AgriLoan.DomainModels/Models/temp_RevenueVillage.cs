﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Keyless]
    [Table("temp_RevenueVillage")]
    public partial class temp_RevenueVillage
    {
        public long? ID { get; set; }
        [StringLength(100)]
        public string FirkaName { get; set; }
        [StringLength(100)]
        public string Name { get; set; }
        public string NameInTamil { get; set; }
        public string Result { get; set; }
        public bool? outputstatus { get; set; }
    }
}
