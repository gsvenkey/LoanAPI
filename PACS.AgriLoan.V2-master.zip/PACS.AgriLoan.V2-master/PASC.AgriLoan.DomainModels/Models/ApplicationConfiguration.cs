﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Table("ApplicationConfiguration")]
    public partial class ApplicationConfiguration
    {
        [Key]
        public long Id { get; set; }
        [Required]
        [StringLength(50)]
        public string Name { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal MaxLimitForMember { get; set; }
        [Column(TypeName = "numeric(5, 2)")]
        public decimal CashForFertilizer { get; set; }
        [Column(TypeName = "numeric(5, 2)")]
        public decimal CashForSeed { get; set; }
        [Column(TypeName = "numeric(5, 2)")]
        public decimal CashForPesticide { get; set; }
        [Column(TypeName = "numeric(5, 2)")]
        public decimal KindForFertilizer { get; set; }
        [Column(TypeName = "numeric(5, 2)")]
        public decimal KindForPesticide { get; set; }
        [Column(TypeName = "numeric(5, 2)")]
        public decimal KindForSeed { get; set; }
        public bool IsDeleted { get; set; }
        public int? CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        public int? ModifiedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDate { get; set; }
    }
}
