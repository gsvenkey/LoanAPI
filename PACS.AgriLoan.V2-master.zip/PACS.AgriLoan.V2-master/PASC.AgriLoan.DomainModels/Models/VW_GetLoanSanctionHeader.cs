﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Keyless]
    public partial class VW_GetLoanSanctionHeader
    {
        public long Id { get; set; }
        public long SanctionNo { get; set; }
        public long PacsId { get; set; }
        public long FYearId { get; set; }
        [Column(TypeName = "date")]
        public DateTime SanctionDate { get; set; }
        public long LoanTypeID { get; set; }
        [Required]
        [StringLength(50)]
        public string LoanTypeName { get; set; }
        [Required]
        [StringLength(50)]
        public string LoanTypeNameInTamil { get; set; }
        public long MemberID { get; set; }
        [Required]
        [StringLength(100)]
        public string MemberName { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal SanctionAmount { get; set; }
    }
}
