﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Table("LoanIssueHeader")]
    public partial class LoanIssueHeader
    {
        public LoanIssueHeader()
        {
            LoanReceipts = new HashSet<LoanReceipt>();
        }

        [Key]
        public long Id { get; set; }
        public long SanctionId { get; set; }
        public long PacsId { get; set; }
        public long FYearId { get; set; }
        public long IssueNo { get; set; }
        [StringLength(20)]
        public string LoanNo { get; set; }
        [Column(TypeName = "date")]
        public DateTime IssueDate { get; set; }
        public long MemberID { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal IssueAmount { get; set; }
        public bool IsDeleted { get; set; }
        public int? CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        public int? ModifiedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDate { get; set; }

        [ForeignKey(nameof(FYearId))]
        [InverseProperty(nameof(FinancialYear.LoanIssueHeaders))]
        public virtual FinancialYear FYear { get; set; }
        [ForeignKey(nameof(MemberID))]
        [InverseProperty(nameof(MemberMaster.LoanIssueHeaders))]
        public virtual MemberMaster Member { get; set; }
        [ForeignKey(nameof(PacsId))]
        [InverseProperty(nameof(PacsMaster.LoanIssueHeaders))]
        public virtual PacsMaster Pacs { get; set; }
        [ForeignKey(nameof(SanctionId))]
        [InverseProperty(nameof(LoanSanctionHeader.LoanIssueHeaders))]
        public virtual LoanSanctionHeader Sanction { get; set; }
        [InverseProperty(nameof(LoanReceipt.Issue))]
        public virtual ICollection<LoanReceipt> LoanReceipts { get; set; }
    }
}
