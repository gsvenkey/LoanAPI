﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Table("JlgHeader")]
    public partial class JlgHeader
    {
        public JlgHeader()
        {
            JlgDetails = new HashSet<JlgDetail>();
            JlgLoanTypeDetails = new HashSet<JlgLoanTypeDetail>();
        }

        [Key]
        public long Id { get; set; }
        public long PacsId { get; set; }
        public long JlgMemberId { get; set; }
        [Column(TypeName = "date")]
        public DateTime JoiningDate { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal AccountBalance { get; set; }
        [Column(TypeName = "numeric(14, 0)")]
        public decimal ResolutionNo { get; set; }
        [Column(TypeName = "date")]
        public DateTime ResolutionDate { get; set; }
        public bool IsDeleted { get; set; }
        public int? CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        public int? ModifiedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDate { get; set; }

        [ForeignKey(nameof(JlgMemberId))]
        [InverseProperty(nameof(MemberMaster.JlgHeaders))]
        public virtual MemberMaster JlgMember { get; set; }
        [ForeignKey(nameof(PacsId))]
        [InverseProperty(nameof(PacsMaster.JlgHeaders))]
        public virtual PacsMaster Pacs { get; set; }
        [InverseProperty(nameof(JlgDetail.Jlg))]
        public virtual ICollection<JlgDetail> JlgDetails { get; set; }
        [InverseProperty(nameof(JlgLoanTypeDetail.JlgHeader))]
        public virtual ICollection<JlgLoanTypeDetail> JlgLoanTypeDetails { get; set; }
    }
}
