﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Keyless]
    public partial class VW_ListLoanRequest
    {
        public long Id { get; set; }
        public long RequestNo { get; set; }
        [Column(TypeName = "date")]
        public DateTime RequestDate { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal RequestAmount { get; set; }
        [Required]
        [StringLength(100)]
        public string MemberName { get; set; }
        [Required]
        [StringLength(50)]
        public string LoanType { get; set; }
        public long PacsId { get; set; }
        public long FYearId { get; set; }
        public long AdhaarNumber { get; set; }
    }
}
