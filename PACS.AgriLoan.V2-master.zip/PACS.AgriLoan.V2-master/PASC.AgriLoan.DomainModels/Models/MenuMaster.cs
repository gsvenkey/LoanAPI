﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Table("MenuMaster")]
    public partial class MenuMaster
    {
        public MenuMaster()
        {
            RoleMenuMasters = new HashSet<RoleMenuMaster>();
        }

        [Key]
        public long Id { get; set; }
        [Required]
        [StringLength(50)]
        public string Name { get; set; }
        [StringLength(50)]
        public string ControllerName { get; set; }
        [StringLength(50)]
        public string ActionMethod { get; set; }
        [Required]
        [StringLength(100)]
        public string Displayname { get; set; }
        public long? MenuTypeId { get; set; }
        public long? ParentId { get; set; }
        [StringLength(100)]
        public string Url { get; set; }
        public bool? Active { get; set; }
        public int? Displayorder { get; set; }
        [StringLength(100)]
        public string Icon { get; set; }

        [ForeignKey(nameof(MenuTypeId))]
        [InverseProperty(nameof(LookupCodeMaster.MenuMasters))]
        public virtual LookupCodeMaster MenuType { get; set; }
        [InverseProperty(nameof(RoleMenuMaster.Menu))]
        public virtual ICollection<RoleMenuMaster> RoleMenuMasters { get; set; }
    }
}
