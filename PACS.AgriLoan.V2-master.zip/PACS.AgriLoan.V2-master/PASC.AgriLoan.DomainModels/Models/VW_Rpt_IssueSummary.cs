﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Keyless]
    public partial class VW_Rpt_IssueSummary
    {
        public long PacsId { get; set; }
        public long Id { get; set; }
        public long LoanTypeID { get; set; }
        [Required]
        [StringLength(50)]
        public string LoanTypeName { get; set; }
        [Required]
        [StringLength(50)]
        public string LoanTypeNameInTamil { get; set; }
        public long RateOfInterestId { get; set; }
        [Column(TypeName = "numeric(5, 2)")]
        public decimal Normal { get; set; }
        [Column(TypeName = "numeric(5, 2)")]
        public decimal Penal { get; set; }
        public long IssueNo { get; set; }
        [StringLength(20)]
        public string LoanNo { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal SanctionAmount { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal IssueAmount { get; set; }
        [Column(TypeName = "date")]
        public DateTime IssueDate { get; set; }
        [Column(TypeName = "date")]
        public DateTime DueDate { get; set; }
        public long MemberId { get; set; }
        public long MemberNumber { get; set; }
        [Required]
        [StringLength(100)]
        public string MemberName { get; set; }
        [Required]
        [StringLength(100)]
        public string GardianName { get; set; }
        [StringLength(25)]
        public string Relationship { get; set; }
        [Required]
        [StringLength(50)]
        public string Address1 { get; set; }
        [Required]
        [StringLength(100)]
        public string Address2 { get; set; }
        [Required]
        [StringLength(100)]
        public string Address3 { get; set; }
        [Required]
        [StringLength(100)]
        public string Address4 { get; set; }
        [StringLength(100)]
        public string VillageName { get; set; }
        public int Pincode { get; set; }
        [Required]
        [StringLength(150)]
        public string PacsNameInTamil { get; set; }
        [Required]
        [StringLength(203)]
        public string PacsAddress { get; set; }
    }
}
