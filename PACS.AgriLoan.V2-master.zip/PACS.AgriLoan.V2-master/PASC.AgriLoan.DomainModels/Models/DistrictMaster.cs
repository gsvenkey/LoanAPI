﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Table("DistrictMaster")]
    public partial class DistrictMaster
    {
        public DistrictMaster()
        {
            DccbBankMasters = new HashSet<DccbBankMaster>();
            EmployeeMasters = new HashSet<EmployeeMaster>();
            LoanRatioMasters = new HashSet<LoanRatioMaster>();
            PacsMasters = new HashSet<PacsMaster>();
            ReportingAreaOffices = new HashSet<ReportingAreaOffice>();
            TalukMasters = new HashSet<TalukMaster>();
            TieUpCompanyMasters = new HashSet<TieUpCompanyMaster>();
        }

        [Key]
        public long Id { get; set; }
        [Required]
        [StringLength(50)]
        public string Name { get; set; }
        [StringLength(15)]
        public string ShortName { get; set; }
        [Required]
        [StringLength(50)]
        public string NameInTamil { get; set; }
        public bool IsDeleted { get; set; }
        public int? CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        public int? ModifiedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDate { get; set; }

        [InverseProperty(nameof(DccbBankMaster.District))]
        public virtual ICollection<DccbBankMaster> DccbBankMasters { get; set; }
        [InverseProperty(nameof(EmployeeMaster.District))]
        public virtual ICollection<EmployeeMaster> EmployeeMasters { get; set; }
        [InverseProperty(nameof(LoanRatioMaster.District))]
        public virtual ICollection<LoanRatioMaster> LoanRatioMasters { get; set; }
        [InverseProperty(nameof(PacsMaster.District))]
        public virtual ICollection<PacsMaster> PacsMasters { get; set; }
        [InverseProperty(nameof(ReportingAreaOffice.District))]
        public virtual ICollection<ReportingAreaOffice> ReportingAreaOffices { get; set; }
        [InverseProperty(nameof(TalukMaster.District))]
        public virtual ICollection<TalukMaster> TalukMasters { get; set; }
        [InverseProperty(nameof(TieUpCompanyMaster.District))]
        public virtual ICollection<TieUpCompanyMaster> TieUpCompanyMasters { get; set; }
    }
}
