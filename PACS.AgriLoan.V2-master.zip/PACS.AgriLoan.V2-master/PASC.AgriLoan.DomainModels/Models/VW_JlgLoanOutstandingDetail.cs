﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Keyless]
    public partial class VW_JlgLoanOutstandingDetail
    {
        public long pacsId { get; set; }
        public long MemberId { get; set; }
        [Required]
        [StringLength(100)]
        public string MemberName { get; set; }
        public long MobileNumber { get; set; }
        public string PhotoUrl { get; set; }
        public long LoanTypeId { get; set; }
        [Required]
        [StringLength(50)]
        public string LoanType { get; set; }
        public long IssueId { get; set; }
        public long IssueNo { get; set; }
        [Column(TypeName = "date")]
        public DateTime IssueDate { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal IssueAmount { get; set; }
    }
}
