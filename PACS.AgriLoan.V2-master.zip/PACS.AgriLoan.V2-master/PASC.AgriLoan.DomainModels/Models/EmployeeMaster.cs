﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Table("EmployeeMaster")]
    public partial class EmployeeMaster
    {
        [Key]
        public long Id { get; set; }
        [Required]
        [StringLength(100)]
        public string Name { get; set; }
        [Required]
        [StringLength(100)]
        public string NameInTamil { get; set; }
        [Required]
        [StringLength(50)]
        public string Address1 { get; set; }
        [Required]
        [StringLength(50)]
        public string Address2 { get; set; }
        [Required]
        [StringLength(50)]
        public string Address3 { get; set; }
        [Required]
        [StringLength(50)]
        public string Address4 { get; set; }
        public long DistrictId { get; set; }
        public long PacsId { get; set; }
        public long RoleId { get; set; }
        public long DesignationId { get; set; }
        [StringLength(20)]
        public string UserName { get; set; }
        [StringLength(20)]
        public string Password { get; set; }
        public bool IsDeleted { get; set; }
        public int? CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        public int? ModifiedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDate { get; set; }

        [ForeignKey(nameof(DesignationId))]
        [InverseProperty(nameof(LookupCodeMaster.EmployeeMasterDesignations))]
        public virtual LookupCodeMaster Designation { get; set; }
        [ForeignKey(nameof(DistrictId))]
        [InverseProperty(nameof(DistrictMaster.EmployeeMasters))]
        public virtual DistrictMaster District { get; set; }
        [ForeignKey(nameof(PacsId))]
        [InverseProperty(nameof(PacsMaster.EmployeeMasters))]
        public virtual PacsMaster Pacs { get; set; }
        [ForeignKey(nameof(RoleId))]
        [InverseProperty(nameof(LookupCodeMaster.EmployeeMasterRoles))]
        public virtual LookupCodeMaster Role { get; set; }
    }
}
