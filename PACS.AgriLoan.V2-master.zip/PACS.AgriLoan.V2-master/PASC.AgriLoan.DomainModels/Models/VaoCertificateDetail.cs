﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Table("VaoCertificateDetail")]
    public partial class VaoCertificateDetail
    {
        public VaoCertificateDetail()
        {
            LoanIssueDetails = new HashSet<LoanIssueDetail>();
            LoanRequestDetails = new HashSet<LoanRequestDetail>();
            LoanSanctionDetails = new HashSet<LoanSanctionDetail>();
        }

        [Key]
        public long Id { get; set; }
        public long VaoCertificateId { get; set; }
        public int ServeyNo { get; set; }
        [StringLength(50)]
        public string SubDivisionNo { get; set; }
        [Column(TypeName = "numeric(5, 2)")]
        public decimal TotalArea { get; set; }
        [Column(TypeName = "numeric(5, 2)")]
        public decimal Bounded { get; set; }
        public bool IsDeleted { get; set; }
        public int? CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        public int? ModifiedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDate { get; set; }

        [ForeignKey(nameof(VaoCertificateId))]
        [InverseProperty(nameof(VaoCertificateHeader.VaoCertificateDetails))]
        public virtual VaoCertificateHeader VaoCertificate { get; set; }
        [InverseProperty(nameof(LoanIssueDetail.VaoDetail))]
        public virtual ICollection<LoanIssueDetail> LoanIssueDetails { get; set; }
        [InverseProperty(nameof(LoanRequestDetail.VaoDetail))]
        public virtual ICollection<LoanRequestDetail> LoanRequestDetails { get; set; }
        [InverseProperty(nameof(LoanSanctionDetail.VaoDetail))]
        public virtual ICollection<LoanSanctionDetail> LoanSanctionDetails { get; set; }
    }
}
