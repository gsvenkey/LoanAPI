﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Keyless]
    public partial class VW_GetLoanReceiptPendingDetail
    {
        public long PacsId { get; set; }
        public long MemberId { get; set; }
        public long? ReceiptId { get; set; }
        public long? FYearId { get; set; }
        public long LoanTypeId { get; set; }
        public long IssueId { get; set; }
        public long IssueNo { get; set; }
        [StringLength(20)]
        public string LoanNo { get; set; }
        [Column(TypeName = "date")]
        public DateTime IssueDate { get; set; }
        [Column(TypeName = "date")]
        public DateTime DueDate { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal IssueAmount { get; set; }
        public long RateId { get; set; }
        [Column(TypeName = "numeric(5, 2)")]
        public decimal NormalROI { get; set; }
        [Column(TypeName = "numeric(5, 2)")]
        public decimal PenalROI { get; set; }
        public int? NormalNoOfDays { get; set; }
        public int? PenalNoOfDays { get; set; }
        [Column(TypeName = "numeric(38, 2)")]
        public decimal? PrinicipalPaid { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? Intrest { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? PenalIntrest { get; set; }
    }
}
