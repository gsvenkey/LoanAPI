﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Table("CropMaster")]
    public partial class CropMaster
    {
        public CropMaster()
        {
            LoanIssueDetails = new HashSet<LoanIssueDetail>();
            LoanRatioMasters = new HashSet<LoanRatioMaster>();
            LoanRequestDetails = new HashSet<LoanRequestDetail>();
            LoanSanctionDetails = new HashSet<LoanSanctionDetail>();
        }

        [Key]
        public long Id { get; set; }
        public long CategoryId { get; set; }
        [Required]
        [StringLength(100)]
        public string Name { get; set; }
        [Required]
        [StringLength(200)]
        public string NameInTamil { get; set; }
        [Column(TypeName = "date")]
        public DateTime PeriodFrom { get; set; }
        [Column(TypeName = "date")]
        public DateTime? PeriodTo { get; set; }
        public int LoanDuePeriod { get; set; }
        public bool IsDeleted { get; set; }
        public int? CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        public int? ModifiedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDate { get; set; }

        [ForeignKey(nameof(CategoryId))]
        [InverseProperty(nameof(CropCategory.CropMasters))]
        public virtual CropCategory Category { get; set; }
        [InverseProperty(nameof(LoanIssueDetail.Crop))]
        public virtual ICollection<LoanIssueDetail> LoanIssueDetails { get; set; }
        [InverseProperty(nameof(LoanRatioMaster.Crop))]
        public virtual ICollection<LoanRatioMaster> LoanRatioMasters { get; set; }
        [InverseProperty(nameof(LoanRequestDetail.Crop))]
        public virtual ICollection<LoanRequestDetail> LoanRequestDetails { get; set; }
        [InverseProperty(nameof(LoanSanctionDetail.Crop))]
        public virtual ICollection<LoanSanctionDetail> LoanSanctionDetails { get; set; }
    }
}
