﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Table("SubRegisterDistrictMaster")]
    public partial class SubRegisterDistrictMaster
    {
        public SubRegisterDistrictMaster()
        {
            SubRegisterMasters = new HashSet<SubRegisterMaster>();
        }

        [Key]
        public long Id { get; set; }
        public long ZoneMasterId { get; set; }
        [Required]
        [StringLength(50)]
        public string Name { get; set; }
        [Required]
        [StringLength(100)]
        public string NameInTamil { get; set; }
        public bool IsDeleted { get; set; }
        public int? CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        public int? ModifiedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDate { get; set; }

        [ForeignKey(nameof(ZoneMasterId))]
        [InverseProperty("SubRegisterDistrictMasters")]
        public virtual ZoneMaster ZoneMaster { get; set; }
        [InverseProperty(nameof(SubRegisterMaster.SubRegisterDistrict))]
        public virtual ICollection<SubRegisterMaster> SubRegisterMasters { get; set; }
    }
}
