﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Keyless]
    public partial class VW_Rpt_RequestHeader_TieUp
    {
        public long pacsId { get; set; }
        public long MemberId { get; set; }
        public long LoanTypeId { get; set; }
        [Required]
        [StringLength(50)]
        public string LoanType { get; set; }
        public long RequestId { get; set; }
        public long FYearId { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal RequestAmount { get; set; }
        [Required]
        [StringLength(100)]
        public string MemberName { get; set; }
        [Required]
        [StringLength(50)]
        public string Address1 { get; set; }
        [Required]
        [StringLength(100)]
        public string Address2 { get; set; }
        [StringLength(100)]
        public string Address3 { get; set; }
        [StringLength(100)]
        public string Address4 { get; set; }
        [StringLength(100)]
        public string VillageName { get; set; }
        public int Pincode { get; set; }
        public long MobileNumber { get; set; }
        [StringLength(10)]
        public string PANNumber { get; set; }
        [StringLength(20)]
        public string SmartCardNumber { get; set; }
        public long AdhaarNumber { get; set; }
        public string PhotoUrl { get; set; }
        public long? SocietySBNumber { get; set; }
        public long? DCCBSBNumber { get; set; }
        public long TieUpCompanyId { get; set; }
        [Required]
        [StringLength(100)]
        public string TieUpCompanyName { get; set; }
        [Required]
        [StringLength(100)]
        public string TieupLetterDate { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? MaximumLoanAmount { get; set; }
    }
}
