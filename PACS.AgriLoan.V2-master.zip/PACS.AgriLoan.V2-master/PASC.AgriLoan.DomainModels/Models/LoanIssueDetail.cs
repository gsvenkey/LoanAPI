﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Table("LoanIssueDetail")]
    public partial class LoanIssueDetail
    {
        [Key]
        public long Id { get; set; }
        public long SanctionId { get; set; }
        public long CropId { get; set; }
        [Required]
        [StringLength(50)]
        public string SurveyNo { get; set; }
        [Column(TypeName = "numeric(5, 2)")]
        public decimal SanctionAcre { get; set; }
        [Column(TypeName = "numeric(5, 2)")]
        public decimal IssueAcre { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal Cash { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? Seed { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? Manure { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? Pesticide { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? KindFertilizer { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? KindSeed { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? KindPesticide { get; set; }
        public bool IsDeleted { get; set; }
        public int? CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        public int? ModifiedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDate { get; set; }

        [ForeignKey(nameof(CropId))]
        [InverseProperty(nameof(CropMaster.LoanIssueDetails))]
        public virtual CropMaster Crop { get; set; }
        [ForeignKey(nameof(SanctionId))]
        [InverseProperty(nameof(LoanSanctionHeader.LoanIssueDetails))]
        public virtual LoanSanctionHeader Sanction { get; set; }
    }
}
