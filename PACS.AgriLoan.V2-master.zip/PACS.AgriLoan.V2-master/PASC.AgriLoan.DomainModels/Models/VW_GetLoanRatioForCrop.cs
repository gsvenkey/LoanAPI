﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Keyless]
    public partial class VW_GetLoanRatioForCrop
    {
        public long Id { get; set; }
        [Column(TypeName = "date")]
        public DateTime? EffectFrom { get; set; }
        public long DistrictId { get; set; }
        public long CropId { get; set; }
        [Required]
        [StringLength(100)]
        public string Name { get; set; }
        [Required]
        [StringLength(200)]
        public string NameInTamil { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal Cash { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal fertilizer { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal Manure { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal Seed { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal Pesticide { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal Maintanance { get; set; }
        [StringLength(50)]
        public string IssueMonth { get; set; }
    }
}
