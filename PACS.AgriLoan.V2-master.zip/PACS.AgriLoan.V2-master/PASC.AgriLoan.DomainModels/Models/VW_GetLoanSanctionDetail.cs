﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Keyless]
    public partial class VW_GetLoanSanctionDetail
    {
        public long Id { get; set; }
        public long SanctionId { get; set; }
        [StringLength(50)]
        public string SubDivisionNo { get; set; }
        public int SurveyNo { get; set; }
        [Column(TypeName = "numeric(5, 2)")]
        public decimal CultivationAcre { get; set; }
        [Column(TypeName = "numeric(5, 2)")]
        public decimal SanctionAcre { get; set; }
        public long LoanRatioId { get; set; }
        public int LoanDuePeriod { get; set; }
        public long CropId { get; set; }
        [Required]
        [StringLength(100)]
        public string CropName { get; set; }
        [Required]
        [StringLength(200)]
        public string CropNameInTamil { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal Cash { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? Fertilizer { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? Seed { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? Pesticide { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? KindFertilizer { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? KindSeed { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? KindPesticide { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? Maintanance { get; set; }
    }
}
