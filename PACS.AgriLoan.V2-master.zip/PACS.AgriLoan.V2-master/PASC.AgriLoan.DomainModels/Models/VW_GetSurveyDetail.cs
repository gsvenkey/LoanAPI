﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Keyless]
    public partial class VW_GetSurveyDetail
    {
        public long PacsId { get; set; }
        public long MemberId { get; set; }
        public long Id { get; set; }
        public long? VaoCertificateId { get; set; }
        [Column(TypeName = "date")]
        public DateTime CertificateDate { get; set; }
        [Required]
        [StringLength(50)]
        public string ServeyNo { get; set; }
        [StringLength(50)]
        public string SubDivisionNo { get; set; }
        [Column(TypeName = "numeric(5, 2)")]
        public decimal TotalArea { get; set; }
        [Column(TypeName = "numeric(5, 2)")]
        public decimal Bounded { get; set; }
    }
}
