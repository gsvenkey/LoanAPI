﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    public partial class LandPledgedDetail
    {
        [Key]
        public long Id { get; set; }
        public long LoanRequestId { get; set; }
        public long SubRegisterId { get; set; }
        [Required]
        [StringLength(100)]
        public string MortgageRegNo { get; set; }
        [Column(TypeName = "date")]
        public DateTime? DateOfMortgage { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? MortgageAmount { get; set; }
        public bool IsDeleted { get; set; }
        public int? CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        public int? ModifiedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDate { get; set; }

        [ForeignKey(nameof(LoanRequestId))]
        [InverseProperty(nameof(LoanRequestHeader.LandPledgedDetails))]
        public virtual LoanRequestHeader LoanRequest { get; set; }
        [ForeignKey(nameof(SubRegisterId))]
        [InverseProperty(nameof(SubRegisterMaster.LandPledgedDetails))]
        public virtual SubRegisterMaster SubRegister { get; set; }
    }
}
