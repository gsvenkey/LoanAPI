﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Table("RevenueVillageMaster")]
    public partial class RevenueVillageMaster
    {
        public RevenueVillageMaster()
        {
            VaoCertificateHeaders = new HashSet<VaoCertificateHeader>();
        }

        [Key]
        public long Id { get; set; }
        public long FirkaId { get; set; }
        [Required]
        [StringLength(100)]
        public string Name { get; set; }
        [Required]
        [StringLength(100)]
        public string NameInTamil { get; set; }
        public bool IsDeleted { get; set; }
        public int? CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        public int? ModifiedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDate { get; set; }

        [ForeignKey(nameof(FirkaId))]
        [InverseProperty(nameof(FirkaMaster.RevenueVillageMasters))]
        public virtual FirkaMaster Firka { get; set; }
        [InverseProperty(nameof(VaoCertificateHeader.RevenueVillage))]
        public virtual ICollection<VaoCertificateHeader> VaoCertificateHeaders { get; set; }
    }
}
