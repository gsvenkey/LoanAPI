﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Keyless]
    [Table("temp_VaoHeader")]
    public partial class temp_VaoHeader
    {
        public long ID { get; set; }
        public long? MemberNo { get; set; }
        [StringLength(100)]
        public string Firka { get; set; }
        [StringLength(100)]
        public string RevenueVillage { get; set; }
        [StringLength(100)]
        public string LandInVillage { get; set; }
        [Column(TypeName = "date")]
        public DateTime? DateOfEntry { get; set; }
        [Column(TypeName = "date")]
        public DateTime? CertificateDate { get; set; }
        public string OwnerShipType { get; set; }
        public string IrrigationType { get; set; }
        public string Result { get; set; }
        public bool? outputstatus { get; set; }
    }
}
