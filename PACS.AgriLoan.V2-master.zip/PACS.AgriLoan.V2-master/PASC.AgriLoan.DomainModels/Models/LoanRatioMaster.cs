﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Table("LoanRatioMaster")]
    public partial class LoanRatioMaster
    {
        [Key]
        public long Id { get; set; }
        [Column(TypeName = "date")]
        public DateTime EffectFrom { get; set; }
        [Column(TypeName = "date")]
        public DateTime? EndDate { get; set; }
        public long DistrictId { get; set; }
        public long CropId { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal Cash { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal Fertilizer { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal Manure { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal Seed { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal Pesticide { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal Maintanance { get; set; }
        [StringLength(50)]
        public string IssueMonth { get; set; }
        public bool IsDeleted { get; set; }
        public int? CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        public int? ModifiedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDate { get; set; }

        [ForeignKey(nameof(CropId))]
        [InverseProperty(nameof(CropMaster.LoanRatioMasters))]
        public virtual CropMaster Crop { get; set; }
        [ForeignKey(nameof(DistrictId))]
        [InverseProperty(nameof(DistrictMaster.LoanRatioMasters))]
        public virtual DistrictMaster District { get; set; }
    }
}
