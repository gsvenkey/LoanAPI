﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Keyless]
    [Table("temp_Block")]
    public partial class temp_Block
    {
        public long? ID { get; set; }
        [StringLength(100)]
        public string TalukName { get; set; }
        [StringLength(100)]
        public string Name { get; set; }
        [StringLength(100)]
        public string Code { get; set; }
        [StringLength(100)]
        public string ShortName { get; set; }
        public string NameInTamil { get; set; }
        public string Result { get; set; }
        public bool? outputstatus { get; set; }
    }
}
