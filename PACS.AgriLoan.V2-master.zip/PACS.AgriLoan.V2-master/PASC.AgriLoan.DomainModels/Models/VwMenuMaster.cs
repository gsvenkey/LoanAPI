﻿using System;
using System.Collections.Generic;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    public partial class VwMenuMaster
    {
        public long Id { get; set; }
        public string Name { get; set; }
        public long MenuTypeId { get; set; }
        public long RoleId { get; set; }
        public string RoleName { get; set; }
        public string MenuType { get; set; }
        public long? ParentId { get; set; }
        public string ParentMenu { get; set; }
        public string ControllerName { get; set; }
        public string ActionMethod { get; set; }
        public string Displayname { get; set; }
        public string Url { get; set; }
        public int? Displayorder { get; set; }
        public string Icon { get; set; }
    }
}
