﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using PACS.AgriLoan.Business.Interface;
using PACS.AgriLoan.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PACS.AgriLoan.API.Controllers.Transactions
{
    [Route("api/[controller]")]
    [ApiController]
    public class MemberMasterController : ControllerBase
    {
        private readonly IMemberMasterBL _memberMasterBL;
        private readonly ILogger<MemberMasterController> _logger;


        public MemberMasterController(ILogger<MemberMasterController> logger, IMemberMasterBL MemberMasterBL)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _memberMasterBL = MemberMasterBL ?? throw new ArgumentNullException(nameof(MemberMasterBL));
        }

        [HttpGet("SelectMember/{pacsId}")]
        public async Task<ActionResult<SelectListItem>> SelectMember(long pacsId)
        {
            _logger.LogInformation("SelectMember Method Invoked in MemberMasterController ");
            return Ok(await _memberMasterBL.SelectMember(pacsId));
        }

        //GET api/<MemberMasterController>/5
        [HttpGet("GetMemberInfo/{id}")]
        public async Task<ActionResult<MemberInfoVM>> GetMemberInfo(long id)
        {
            _logger.LogInformation("Invoked GetMemberInfo in MemberMasterController & Id is : " + id);
            var memberInfo = await _memberMasterBL.GetMemberInfo(id);
            return Ok(memberInfo) != null ? memberInfo : NotFound();
        }

    }
}