﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using PACS.AgriLoan.Business.Interface;
using PACS.AgriLoan.ViewModel;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PACS.AgriLoan.API.Controllers.Transactions
{
    [Route("api/[controller]")]
    [ApiController]
    public class JLGController : ControllerBase
    {
        private readonly IJlgBL _jlgBL;
        private readonly ILogger<JLGController> _logger;


        public JLGController(ILogger<JLGController> logger, IJlgBL jlgBL)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _jlgBL = jlgBL ?? throw new ArgumentNullException(nameof(jlgBL));
        }

        //GET api/<MemberMasterController>/5
        [HttpGet("GetJlgMembersInfo/{JlgMemberId}")]
        public async Task<IEnumerable<JlgMembersInfoVM>> GetJlgMembersInfo(long JlgMemberId)
        {
            _logger.LogInformation("Invoked GetMemberInfo in JLGController & Id is : " + JlgMemberId);
            var memberInfo = await _jlgBL.GetJlgMembersInfo(JlgMemberId);
            return memberInfo;
        }

        [HttpGet("SelectJlg/{pacsId}")]
        public async Task<ActionResult<SelectListItem>> SelectJlg(long pacsId)
        {
            _logger.LogInformation("SelectJlg Method Invoked in JLGController ");
            return Ok(await _jlgBL.SelectJlg(pacsId));
        }

    }
}
