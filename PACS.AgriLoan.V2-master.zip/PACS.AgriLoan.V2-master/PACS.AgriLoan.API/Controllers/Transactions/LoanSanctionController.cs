﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using PACS.AgriLoan.Business.Interface;
using PACS.AgriLoan.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PACS.AgriLoan.API.Controllers.Transactions
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoanSanctionController : ControllerBase
    {
        private readonly ILoanSanctionBL _loanSanctionBL;
        private readonly ILogger<LoanSanctionController> _logger;


        public LoanSanctionController(ILogger<LoanSanctionController> logger, ILoanSanctionBL loanSanctionBL)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _loanSanctionBL = loanSanctionBL ?? throw new ArgumentNullException(nameof(loanSanctionBL));
        }

        // GET api/<LoanRequestController>/5
        [HttpGet("GetLoanRequestDetail/{requestId}")]
        public async Task<ActionResult<LoanSanctionHeaderVM>> GetLoanRequestDetail(long requestId)
        {
            var obj = await _loanSanctionBL.GetLoanRequestDetails(requestId);
            return Ok(obj) != null ? obj : NotFound();
        }

        // POST api/<LoanSanctionController>
        [HttpPost]
        public async Task<IActionResult> Post([FromBody] LoanSanctionHeaderVM loanSanctionHeader)
        {
            _logger.LogInformation("Invoked Post in LoanSanctionController  : " + loanSanctionHeader);
            return Ok(await _loanSanctionBL.Add(loanSanctionHeader));
        }


        [HttpGet("GetList/{pacsId}/{fYearId}")]
        public async Task<IEnumerable<ListLoanSanctionVM>> GetList(long pacsId, long fYearId)
        {
            return await _loanSanctionBL.GetList(pacsId, fYearId);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Put(long id, [FromBody] LoanSanctionHeaderVM loanSanctionHeader)
        {
            _logger.LogInformation("Invoked Put in LoanSanctionController  : " + loanSanctionHeader);
            return Ok(await _loanSanctionBL.Update(loanSanctionHeader));
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(long id)
        {
            _logger.LogInformation("Invoked Delete in LoanRequestController  : " + id);
            return Ok(await _loanSanctionBL.SoftDelete(id));
        }

        // GET api/<LoanRequestController>/5
        [HttpGet("GetById/{id}")]
        public async Task<ActionResult<LoanSanctionHeaderVM>> GetById(long id)
        {
            var GetById = await _loanSanctionBL.GetById(id);
            return Ok(GetById) != null ? GetById : NotFound();
        }


        [HttpGet("SelectSanctionNo/{pacsId}/{memberId}")]
        public async Task<ActionResult<SelectListItem>> SelectSanctionNo(long pacsId, long memberId)
        {
            _logger.LogInformation("SelectMember Method Invoked in LoanSanctionController ");
            return Ok(await _loanSanctionBL.SelectSanctionNo(pacsId, memberId));
        }
    }
}
