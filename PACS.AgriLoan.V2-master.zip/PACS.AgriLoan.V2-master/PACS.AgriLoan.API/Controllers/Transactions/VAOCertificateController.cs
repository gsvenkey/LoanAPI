﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using PACS.AgriLoan.Business.Interface;
using PACS.AgriLoan.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PACS.AgriLoan.API.Controllers.Transactions
{
    [Route("api/[controller]")]
    [ApiController]
    public class VAOCertificateController : ControllerBase
    {
        private readonly IVAOCertificateBL _vAOCertificateBL;
        private readonly ILogger<VAOCertificateController> _logger;


        public VAOCertificateController(ILogger<VAOCertificateController> logger, IVAOCertificateBL vAOCertificateBL)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _vAOCertificateBL = vAOCertificateBL ?? throw new ArgumentNullException(nameof(vAOCertificateBL));
        }

        [HttpGet("GetServeyDetails/{memberId}")]
        public async Task<ActionResult<ServeyDetailsVM>> GetServeyDetails(long memberId)
        {
            _logger.LogInformation("Invoked GetServeyDetails in VAOCertificateController & Id is : " + memberId);
            return Ok(await _vAOCertificateBL.GetServeyDetails(memberId));
        }

        [HttpGet("GetJlgMemberServeyDetails/{JlgMemberId}")]
        public async Task<ActionResult<ServeyDetailsVM>> GetJlgMemberServeyDetails(long JlgMemberId)
        {
            _logger.LogInformation("Invoked GetServeyDetails in VAOCertificateController & Id is : " + JlgMemberId);
            return Ok(await _vAOCertificateBL.GetJlgMemberServeyDetails(JlgMemberId));
        }


        // POST api/<VAOCertificateController>
        [HttpPost]
        public async Task<IActionResult> Post([FromBody] VaoCertificateHeaderVM vaoCertificateHeaderVM)
        {
            _logger.LogInformation("Invoked Post in VAOCertificateController  : " + vaoCertificateHeaderVM);
            return Ok(await _vAOCertificateBL.Add(vaoCertificateHeaderVM));
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Put(long id, [FromBody] VaoCertificateHeaderVM vaoCertificateHeaderVM)
        {
            _logger.LogInformation("Invoked Put in VAOCertificateController  : " + vaoCertificateHeaderVM);
            return Ok(await _vAOCertificateBL.Update(vaoCertificateHeaderVM));
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(long id)
        {
            _logger.LogInformation("Invoked Delete in LoanRequestController  : " + id);
            return Ok(await _vAOCertificateBL.SoftDelete(id));
        }



        // GET api/<VAOCertificateController>/5
        [HttpGet("GetById/{id}")]
        public async Task<ActionResult<VaoCertificateHeaderVM>> GetById(long id)
        {
            var GetById = await _vAOCertificateBL.GetById(id);
            return Ok(GetById) != null ? GetById : NotFound();
        }


        [HttpGet("GetList/{pacsId}/")]
        public async Task<IEnumerable<ListVaoCertificateVM>> GetList(long pacsId)
        {
            return await _vAOCertificateBL.GetList(pacsId);
        }



    }
}
