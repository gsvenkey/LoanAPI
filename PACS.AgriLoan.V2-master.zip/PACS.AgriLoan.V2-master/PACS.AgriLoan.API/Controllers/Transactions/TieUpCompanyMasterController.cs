﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using PACS.AgriLoan.Business.Interface;
using PACS.AgriLoan.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PACS.AgriLoan.API.Controllers.Transactions
{
    [Route("api/[controller]")]
    [ApiController]
    public class TieUpCompanyMasterController : ControllerBase
    {
        private readonly ITieUpCompanyMasterBL _tieUpCompanyMasterBL;
        private readonly ILogger<TieUpCompanyMasterController> _logger;


        public TieUpCompanyMasterController(ILogger<TieUpCompanyMasterController> logger, ITieUpCompanyMasterBL tieUpCompanyMasterBL)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _tieUpCompanyMasterBL = tieUpCompanyMasterBL ?? throw new ArgumentNullException(nameof(tieUpCompanyMasterBL));
        }

        [HttpGet("SelectCompany/{pacsId}")]
        public async Task<ActionResult<SelectListItem>> SelectCompany(long pacsId)
        {
            _logger.LogInformation("SelectMember Method Invoked in TieUpCompanyMasterController");
            return Ok(await _tieUpCompanyMasterBL.SelectCompany(pacsId));
        }

        [HttpGet("GetCompanyDetails/{id}")]
        public async Task<ActionResult<TieUpCompanyMasterVM>> GetCompanyDetails(long id)
        {
            _logger.LogInformation("GetCompanyDetails Method Invoked in TieUpCompanyMasterController");
            return Ok(await _tieUpCompanyMasterBL.GetCompanyDetails(id));
        }

    }
}
