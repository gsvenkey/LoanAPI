﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using PACS.AgriLoan.Business.Interface;
using PACS.AgriLoan.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PACS.AgriLoan.API.Controllers.Transactions
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValidationController : ControllerBase
    {
        private readonly IValidationBL _validationBL;
        private readonly ILogger<ValidationController> _logger;


        public ValidationController(ILogger<ValidationController> logger, IValidationBL validationBL)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _validationBL = validationBL ?? throw new ArgumentNullException(nameof(validationBL));
        }

        [HttpGet("LoanRequest")]
        public async Task<ActionResult<ValidationVM>> LoanRequest(LoanRequestHeaderVM loanRequestHeader)
        {
            _logger.LogInformation("Invoked Post in LoanRequestController  : " + loanRequestHeader);
            var Result = await _validationBL.ValidateLoanRequest(loanRequestHeader);
            return Ok(Result) != null ? Result : NotFound();
        }

        [HttpGet("LoanSanction")]
        public async Task<ActionResult<ValidationVM>> LoanSanction(LoanSanctionHeaderVM loanSanction)
        {
            _logger.LogInformation("Invoked Post in LoanRequestController  : " + loanSanction);
            var Result = await _validationBL.ValidateLoanSanction(loanSanction);
            return Ok(Result) != null ? Result : NotFound();
        }

        [HttpGet("LoanIssue")]
        public async Task<ActionResult<ValidationVM>> LoanIssue(LoanIssueHeaderVM loanIssue)
        {
            _logger.LogInformation("Invoked Post in LoanRequestController  : " + loanIssue);
            var Result = await _validationBL.ValidateLoanIssue(loanIssue);
            return Ok(Result) != null ? Result : NotFound();
        }
    }
}
