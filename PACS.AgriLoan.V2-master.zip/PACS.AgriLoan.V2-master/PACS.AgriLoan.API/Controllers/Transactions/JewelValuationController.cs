﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using PACS.AgriLoan.Business.Interface;
using PACS.AgriLoan.ViewModel;
using System;
using System.Threading.Tasks;

namespace PACS.AgriLoan.API.Controllers.Transactions
{
    [Route("api/[controller]")]
    [ApiController]
    public class JewelValuationController : ControllerBase
    {
        private readonly IJewelValuationBL _jewelValuationBL;
        private readonly ILogger<JewelValuationController> _logger;


        public JewelValuationController(ILogger<JewelValuationController> logger, IJewelValuationBL jewelValuationBL)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _jewelValuationBL = jewelValuationBL ?? throw new ArgumentNullException(nameof(jewelValuationBL));
        }

        [HttpPost]
        public async Task<IActionResult> Post([FromBody] JewelValuationVM valuationVM)
        {
            _logger.LogInformation("Invoked Post in JewelValuationController  : " + valuationVM);
            return Ok(await _jewelValuationBL.Add(valuationVM));

        }

        [HttpGet("GetCurrentValue/{pacsId}")]
        public async Task<ActionResult<decimal>> GetCurrentValue(long pacsId)
        {
            _logger.LogInformation("GetTalukById Invoked & Id is : " + pacsId);
            var JewelValue = await _jewelValuationBL.GetPacsJewelValue(pacsId);
            return Ok(JewelValue) != null ? JewelValue : NotFound();
        }


        [HttpGet("GetJewelValueByPacs/{pacsId}")]
        public async Task<ActionResult<JewelValuationVM>> GetJewelValueByPacs(long pacsId)
        {
            _logger.LogInformation("GetDistrictById Invoked & Id is : " + pacsId);
            var JewelValuation = await _jewelValuationBL.GetJewelValuation(pacsId);
            return Ok(JewelValuation) != null ? JewelValuation : NotFound();
        }


    }
}
