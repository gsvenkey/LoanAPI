﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using PACS.AgriLoan.Business.Interface;
using PACS.AgriLoan.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PACS.AgriLoan.API.Controllers.Transactions
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoanIssueController : ControllerBase
    {
        private readonly ILoanIssueBL _loanIssueBL;
        private readonly ILogger<LoanIssueController> _logger;


        public LoanIssueController(ILogger<LoanIssueController> logger, ILoanIssueBL loanIssueBL)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _loanIssueBL = loanIssueBL ?? throw new ArgumentNullException(nameof(loanIssueBL));
        }

        // GET api/<LoanRequestController>/5
        [HttpGet("GetLoanSanctionDetail/{sanctionId}")]
        public async Task<ActionResult<LoanIssueHeaderVM>> GetLoanSanctionDetail(long sanctionId)
        {
            var obj = await _loanIssueBL.GetLoanSanctionDetails(sanctionId);
            return Ok(obj) != null ? obj : NotFound();
        }

        // POST api/<LoanIssueController>
        [HttpPost]
        public async Task<IActionResult> Post([FromBody] LoanIssueHeaderVM loanIssueHeaderVM)
        {
            _logger.LogInformation("Invoked Post in LoanIssueController  : " + loanIssueHeaderVM);
            return Ok(await _loanIssueBL.Add(loanIssueHeaderVM));
        }


        [HttpGet("GetList/{pacsId}/{fYearId}")]
        public async Task<IEnumerable<ListLoanIssueVM>> GetList(long pacsId, long fYearId)
        {
            return await _loanIssueBL.GetList(pacsId, fYearId);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Put(long id, [FromBody] LoanIssueHeaderVM loanIssueHeaderVM)
        {
            _logger.LogInformation("Invoked Put in LoanSanctionController  : " + loanIssueHeaderVM);
            return Ok(await _loanIssueBL.Update(loanIssueHeaderVM));
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(long id)
        {
            _logger.LogInformation("Invoked Delete in LoanRequestController  : " + id);
            return Ok(await _loanIssueBL.SoftDelete(id));
        }

        // GET api/<LoanRequestController>/5
        [HttpGet("GetById/{id}")]
        public async Task<ActionResult<LoanIssueHeaderVM>> GetById(long id)
        {
            var GetById = await _loanIssueBL.GetById(id);
            return Ok(GetById) != null ? GetById : NotFound();
        }




    }
}
