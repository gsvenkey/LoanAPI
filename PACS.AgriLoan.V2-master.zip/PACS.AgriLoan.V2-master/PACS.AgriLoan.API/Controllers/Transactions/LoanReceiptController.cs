﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using PACS.AgriLoan.Business.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PACS.AgriLoan.API.Controllers.Transactions
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoanReceiptController : ControllerBase
    {
        private readonly ILoanReceiptBL _loanReceiptBL;
        private readonly ILogger<LoanReceiptController> _logger;


        public LoanReceiptController(ILogger<LoanReceiptController> logger, ILoanReceiptBL loanReceiptBL)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _loanReceiptBL = loanReceiptBL ?? throw new ArgumentNullException(nameof(loanReceiptBL));
        }

    }
}
