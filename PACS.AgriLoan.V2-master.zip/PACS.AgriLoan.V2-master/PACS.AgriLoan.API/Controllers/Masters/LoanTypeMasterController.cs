﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using PACS.AgriLoan.Business.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PACS.AgriLoan.API.Controllers.Masters
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoanTypeMasterController : ControllerBase
    {
        private readonly ILoanTypeMasterBL _loanTypeMasterBL;
        private readonly ILogger<LoanTypeMasterController> _logger;


        public LoanTypeMasterController(ILogger<LoanTypeMasterController> logger, ILoanTypeMasterBL loanTypeMasterBL)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _loanTypeMasterBL = loanTypeMasterBL ?? throw new ArgumentNullException(nameof(loanTypeMasterBL));
        }

        [HttpGet("SelectLoanType")]
        public async Task<ActionResult<SelectListItem>> SelectLoanType()
        {
            _logger.LogInformation("SelectlookUp Method Invoked in LoanTypeMasterController ");
            return Ok(await _loanTypeMasterBL.SelectLoanType());
        }

        [HttpGet("SelectLoanTypeInTamil")]
        public async Task<ActionResult<SelectListItem>> SelectLoanTypeInTamil()
        {
            _logger.LogInformation("SelectlookUpInTamil Method Invoked in LoanTypeMasterController ");
            return Ok(await _loanTypeMasterBL.SelectLoanTypeInTamil());
        }
    }
}
