﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using PACS.AgriLoan.Business.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PACS.AgriLoan.API.Controllers.Masters
{
    [Route("api/[controller]")]
    [ApiController]
    public class CropCategoryController : ControllerBase
    {
        private readonly ICropCategoryBL _cropCategoryBL;
        private readonly ILogger<CropCategoryController> _logger;


        public CropCategoryController(ILogger<CropCategoryController> logger, ICropCategoryBL cropCategoryBL)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _cropCategoryBL = cropCategoryBL ?? throw new ArgumentNullException(nameof(cropCategoryBL));
        }

        [HttpGet("SelectCropCategory")]
        public async Task<ActionResult<SelectListItem>> SelectCropCategory()
        {
            _logger.LogInformation("SelectCropCategory Method Invoked in CropCategoryController ");
            return Ok(await _cropCategoryBL.SelectCropCategory());
        }

        [HttpGet("SelectCropCategory/{pacsId}")]
        public async Task<ActionResult<SelectListItem>> SelectCropCategory(long pacsId)
        {
            _logger.LogInformation("SelectCropCategory Method Invoked in CropCategoryController ");
            return Ok(await _cropCategoryBL.SelectCropCategory(pacsId));
        }
    }
}
