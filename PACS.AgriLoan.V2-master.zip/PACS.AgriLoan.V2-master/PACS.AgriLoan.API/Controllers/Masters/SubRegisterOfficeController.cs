﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using PACS.AgriLoan.Business.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PACS.AgriLoan.API.Controllers.Masters
{
    [Route("api/[controller]")]
    [ApiController]
    public class SubRegisterOfficeController : ControllerBase
    {
        private readonly ISubRegisterOfficeBL _subRegisterOfficeBL;
        private readonly ILogger<SubRegisterOfficeController> _logger;


        public SubRegisterOfficeController(ILogger<SubRegisterOfficeController> logger, ISubRegisterOfficeBL subRegisterOfficeBL)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _subRegisterOfficeBL = subRegisterOfficeBL ?? throw new ArgumentNullException(nameof(subRegisterOfficeBL));
        }

        [HttpGet("SelectSubRegsterDistrict/{pacsId}")]
        public async Task<ActionResult<SelectListItem>> SelectSubRegsterDistrict(long pacsId)
        {
            _logger.LogInformation("SelectSubRegsterDistrict Method Invoked in SubRegisterOfficeController ");
            return Ok(await _subRegisterOfficeBL.SelectSubRegsterDistrict(pacsId));
        }

        [HttpGet("SelectSubRegsterOffice/{subRegsterDistrictId}")]
        public async Task<ActionResult<SelectListItem>> SelectSubRegsterOffice(long subRegsterDistrictId)
        {
            _logger.LogInformation("SelectSubRegsterOffice Method Invoked in SubRegisterOfficeController ");
            return Ok(await _subRegisterOfficeBL.SelectSubRegsterOffice(subRegsterDistrictId));
        }
    }
}
