﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using PACS.AgriLoan.Business.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PACS.AgriLoan.API.Controllers.Masters
{
    [Route("api/[controller]")]
    [ApiController]
    public class JewelMasterController : ControllerBase
    {
        private readonly IJewelMasterBL _jewelMasterBL;
        private readonly ILogger<JewelMasterController> _logger;


        public JewelMasterController(ILogger<JewelMasterController> logger, IJewelMasterBL jewelMasterBL)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _jewelMasterBL = jewelMasterBL ?? throw new ArgumentNullException(nameof(jewelMasterBL));
        }


        [HttpGet("SelectJewel")]
        public async Task<ActionResult<SelectListItem>> SelectJewel()
        {
            _logger.LogInformation("SelectJewel Method Invoked in JewelMasterController ");
            return Ok(await _jewelMasterBL.SelectJewel());
        }
    }
}
