﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using PACS.AgriLoan.Business.Interface;
using PACS.AgriLoan.ViewModel;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PACS.AgriLoan.API.Controllers.Masters
{
    [Route("api/[controller]")]
    [ApiController]
    public class TalukMasterController : ControllerBase
    {
        private readonly ITalukMasterBL _TalukMasterBL;
        private readonly ILogger<TalukMasterController> _logger;


        public TalukMasterController(ILogger<TalukMasterController> logger, ITalukMasterBL TalukMasterBL)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _TalukMasterBL = TalukMasterBL ?? throw new ArgumentNullException(nameof(TalukMasterBL));
        }
        // GET: api/<TalukController>
        [HttpGet]
        public async Task<ActionResult<TalukVM>> GetAll()
        {
            _logger.LogInformation("GetAll Method Invoked in TalukMasterController ");
            return Ok(await _TalukMasterBL.GetAll());
        }

     
        [HttpGet("SelectTaluk/{districtId}")]
        public async Task<ActionResult<SelectListItem>> SelectTaluk(long districtId)
        {
            _logger.LogInformation("SelectTaluk Method Invoked in TalukMasterController ");
            return Ok(await _TalukMasterBL.SelectTaluk(districtId));
        }

        //GET api/<TalukController>/5
        [HttpGet("{id}")]
        public async Task<ActionResult<TalukVM>> GetTalukById(long id)
        {
            _logger.LogInformation("GetTalukById Invoked & Id is : " + id);
            var TalukMaster = await _TalukMasterBL.GetById(id);
            return Ok(TalukMaster) != null ? TalukMaster : NotFound();
        }

        // POST: api/TalukMasters
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public async Task<ActionResult<TalukVM>> AddTaluk(TalukVM talukVM)
        {
            _logger.LogInformation("AddTaluk Invoked   : " + talukVM);


            if (await TalukMasterExists(talukVM.Name))
            {
                talukVM.Message = talukVM.Name + " already Exist";
                return BadRequest(talukVM.Message);
            }
            else
            {

                var Taluk = await _TalukMasterBL.Add(talukVM);
                _logger.LogInformation("AddTaluk Responded : " + Taluk);
                return Ok(Taluk != null ? Taluk : NotFound());
            }
        }

        // PUT: api/TalukMasters/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateTaluk(long id, TalukVM talukVM)
        {
            _logger.LogInformation("UpdateTaluk Invoked  : " + talukVM);

            if (id != talukVM.Id)
            {
                _logger.LogWarning("Bad Request  : " + talukVM);
                return BadRequest();
            }
            Task<bool> task = TalukMasterExists(id);
            if (await task)
            {
                var Taluk = await _TalukMasterBL.Update(talukVM);
                _logger.LogInformation("AddTaluk Responded : " + talukVM);
                return Ok(Taluk != null ? Taluk : NotFound());
            }
            else
            {
                return NotFound();
            }
        }

        // DELETE api/<TalukController>/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<TalukVM>> DeleteTaluk(long id, TalukVM talukVM)
        {
            _logger.LogInformation("DeleteTaluk Invoked  : " + talukVM);

            if (id == talukVM.Id)
            {
                Task<bool> task = TalukMasterExists(id);
                return await task ? await _TalukMasterBL.SoftDelete(talukVM) : NotFound();
            }
            return BadRequest();
        }
        #region Private Methods
        private async Task<bool> TalukMasterExists(long id)
        {

            return await _TalukMasterBL.IsTalukExist(id);
        }

        private async Task<bool> TalukMasterExists(string Name)
        {
            return await _TalukMasterBL.IsTalukExist(Name);
        }
        #endregion

    }
}
