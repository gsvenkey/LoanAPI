﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using PACS.AgriLoan.Business.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PACS.AgriLoan.API.Controllers.Masters
{
    [Route("api/[controller]")]
    [ApiController]
    public class LookUpCodeController : ControllerBase
    {
        private readonly ILookUpCodeMasterBL _lookUpCodeMasterBL;
        private readonly ILogger<LookUpCodeController> _logger;


        public LookUpCodeController(ILogger<LookUpCodeController> logger, ILookUpCodeMasterBL lookUpCodeMasterBL)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _lookUpCodeMasterBL = lookUpCodeMasterBL ?? throw new ArgumentNullException(nameof(lookUpCodeMasterBL));
        }

        [HttpGet("SelectlookUp/{lookUpCode}")]
        public async Task<ActionResult<SelectListItem>> SelectlookUp(string lookUpCode)
        {
            _logger.LogInformation("SelectlookUp Method Invoked in LookUpCodeController ");
            return Ok(await _lookUpCodeMasterBL.SelectLookUp(lookUpCode));
        }

        [HttpGet("SelectlookUpInTamil/{lookUpCode}")]
        public async Task<ActionResult<SelectListItem>> SelectlookUpInTamil(string lookUpCode)
        {
            _logger.LogInformation("SelectlookUpInTamil Method Invoked in LookUpCodeController ");
            return Ok(await _lookUpCodeMasterBL.SelectLookUpInTamil(lookUpCode));
        }
    }
}
