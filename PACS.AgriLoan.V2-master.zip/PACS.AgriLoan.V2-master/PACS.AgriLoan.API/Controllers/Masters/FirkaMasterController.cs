﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using PACS.AgriLoan.Business.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PACS.AgriLoan.API.Controllers.Masters
{
    [Route("api/[controller]")]
    [ApiController]
    public class FirkaMasterController : ControllerBase
    {
        private readonly IFirkaMasterBL _firkaMasterBL;
        private readonly ILogger<FirkaMasterController> _logger;


        public FirkaMasterController(ILogger<FirkaMasterController> logger, IFirkaMasterBL firkaMasterBL)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _firkaMasterBL = firkaMasterBL ?? throw new ArgumentNullException(nameof(firkaMasterBL));
        }

        [HttpGet("SelectFirka/{talukId}")]
        public async Task<ActionResult<SelectListItem>> SelectFirka(long talukId)
        {
            _logger.LogInformation("SelectFirka Method Invoked in FirkaMasterController ");
            return Ok(await _firkaMasterBL.SelectFirka(talukId));
        }
    }
}
