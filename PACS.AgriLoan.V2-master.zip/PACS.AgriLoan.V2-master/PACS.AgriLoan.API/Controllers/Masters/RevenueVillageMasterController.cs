﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using PACS.AgriLoan.Business.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PACS.AgriLoan.API.Controllers.Masters
{
    [Route("api/[controller]")]
    [ApiController]
    public class RevenueVillageMasterController : ControllerBase
    {
        private readonly IRevenueVillageMasterBL _revenueVillageBL;
        private readonly ILogger<RevenueVillageMasterController> _logger;


        public RevenueVillageMasterController(ILogger<RevenueVillageMasterController> logger, IRevenueVillageMasterBL revenueVillageBL)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _revenueVillageBL = revenueVillageBL ?? throw new ArgumentNullException(nameof(revenueVillageBL));
        }

        [HttpGet("SelectRevenueVillage/{firkaId}")]
        public async Task<ActionResult<SelectListItem>> SelectRevenueVillage(long firkaId)
        {
            _logger.LogInformation("RevenueVillage Method Invoked in RevenueVillageMasterController ");
            return Ok(await _revenueVillageBL.SelectRevenueVillage(firkaId));
        }
    }
}
