﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using PACS.AgriLoan.Business.Interface;
using PACS.AgriLoan.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PACS.AgriLoan.API.Controllers.Reports
{
    [Route("api/[controller]")]
    [ApiController]
    public class PacsReportController : ControllerBase
    {
        private readonly IPacsReportBL _pacsReportBL;
        private readonly ILogger<PacsReportController> _logger;
        
        public PacsReportController(ILogger<PacsReportController> logger, IPacsReportBL pacsReportBL)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _pacsReportBL = pacsReportBL ?? throw new ArgumentNullException(nameof(pacsReportBL));
        }

        // GET api/<LoanRequestController>/5
        [HttpGet("BondReport/{issueId}")]
        public async Task<ActionResult<BondReportVM>> BondReport(long issueId)
        {
            var BondRpt = await _pacsReportBL.RptIssueSummary(issueId);
            return Ok(BondRpt) != null ? BondRpt : NotFound();
        }


    }
}
