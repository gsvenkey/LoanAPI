﻿using Microsoft.AspNetCore.Mvc.Rendering;
using PACS.AgriLoan.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Business.Interface
{
   public interface ILoanSanctionBL
    {
        Task<LoanSanctionHeaderVM> GetLoanRequestDetails(long requestId);
        Task<bool> Add(LoanSanctionHeaderVM loanSanctionHeader);
        Task<bool> Update(LoanSanctionHeaderVM loanSanctionHeader);
        Task<LoanSanctionHeaderVM> GetById(long Id);
        Task<bool> SoftDelete(long id);
        Task<IEnumerable<ListLoanSanctionVM>> GetList(long pacsId, long fYearId);
        Task<IEnumerable<SelectListItem>> SelectSanctionNo(long pacsId, long memberId);
    }
}
