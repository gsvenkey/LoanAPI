﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Business.Interface
{
    public interface ICropMasterBL
    {
        Task<IEnumerable<SelectListItem>> SelectCrop(long cropCategoryId);
        Task<IEnumerable<SelectListItem>> SelectCrop(long pacsId, long categoryId);
       
    }
}
