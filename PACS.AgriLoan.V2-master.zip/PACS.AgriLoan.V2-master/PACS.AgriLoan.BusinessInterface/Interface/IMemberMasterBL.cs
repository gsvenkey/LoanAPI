﻿using Microsoft.AspNetCore.Mvc.Rendering;
using PACS.AgriLoan.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Business.Interface
{
   public interface IMemberMasterBL
    {
        Task<IEnumerable<SelectListItem>> SelectMember(long pacsId);
        Task<MemberMasterVM> GetById(long Id);
        Task<MemberInfoVM> GetMemberInfo(long Id);


    }
}
