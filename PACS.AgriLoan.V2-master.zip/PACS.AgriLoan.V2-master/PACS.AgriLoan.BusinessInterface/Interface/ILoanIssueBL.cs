﻿using PACS.AgriLoan.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Business.Interface
{
   public interface ILoanIssueBL
    {
        Task<LoanIssueHeaderVM> GetLoanSanctionDetails(long sanctionId);
        Task<bool> Add(LoanIssueHeaderVM loanIssueHeaderVM);
        Task<bool> Update(LoanIssueHeaderVM loanIssueHeaderVM);
        Task<LoanIssueHeaderVM> GetById(long Id);
        Task<bool> SoftDelete(long id);
        Task<IEnumerable<ListLoanIssueVM>> GetList(long pacsId, long fYearId);

    }
}
