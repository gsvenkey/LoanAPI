﻿using PACS.AgriLoan.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Business.Interface
{
    public interface ILoanRequestBL
    {
        Task<bool> Add(LoanRequestHeaderVM loanRequestHeaderVM);
        Task<bool> Update(LoanRequestHeaderVM loanRequestHeaderVM);
        Task<bool> SoftDelete(long Id);
        Task<LoanRequestHeaderVM> GetById(long Id);
        Task<IEnumerable<ListLoanRequestVM>> GetList(long pacsId, long fYearId);

    }
}
