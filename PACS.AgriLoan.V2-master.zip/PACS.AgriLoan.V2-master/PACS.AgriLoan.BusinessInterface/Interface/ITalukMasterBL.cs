﻿using Microsoft.AspNetCore.Mvc.Rendering;
using PACS.AgriLoan.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Business.Interface
{
   public interface ITalukMasterBL
    {
        Task<IEnumerable<TalukVM>> GetAll();
        Task<TalukVM> GetById(long Id);
        Task<IEnumerable<SelectListItem>> SelectTaluk(long districtId);
        Task<TalukVM> Add(TalukVM TalukVM);
        Task<TalukVM> Update(TalukVM TalukVM);
        Task<TalukVM> SoftDelete(TalukVM TalukVM);
        Task<bool> IsTalukExist(long Id);
        Task<bool> IsTalukExist(string Name);
    }
}
