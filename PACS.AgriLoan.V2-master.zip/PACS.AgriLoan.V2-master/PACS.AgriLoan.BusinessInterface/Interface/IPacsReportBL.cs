﻿using PACS.AgriLoan.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Business.Interface
{
   public interface IPacsReportBL
    {
        Task<BondReportVM> RptIssueSummary(long issueId);

        Task<bool> GenerateSuritySanction(long sanctionId, int sdsCode);
    }
}
