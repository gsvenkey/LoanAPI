﻿using Microsoft.AspNetCore.Mvc.Rendering;
using PACS.AgriLoan.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Business.Interface
{
    public interface ILoanReceiptBL
    {
        Task<IEnumerable<SelectListItem>> SelectIssueNo(long pacsId, long memberId);
        Task<LoanReceiptHeaderVM> getReceiptDetails(long IssueId);
        Task<bool> Add(LoanReceiptHeaderVM loanReceiptHeaderVM);
        Task<bool> Update(LoanReceiptHeaderVM loanReceiptHeaderVM);
        Task<bool> SoftDelete(long id);


    }
}
