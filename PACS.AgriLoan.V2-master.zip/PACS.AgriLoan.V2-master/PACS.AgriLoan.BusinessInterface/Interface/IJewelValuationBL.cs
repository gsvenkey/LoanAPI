﻿using PACS.AgriLoan.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Business.Interface
{
    public interface IJewelValuationBL
    {
        Task<bool> Add(JewelValuationVM jewelValuationVM);
        Task<JewelValuationVM> GetJewelValuation(long pacsId);
        Task<decimal> GetPacsJewelValue(long pacsId);

    }
}
