﻿using PACS.AgriLoan.Interface.Common;
using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Interface
{
    public interface IApplicationConfigurationRepository : IGenericRepository<ApplicationConfiguration>
    {
        public Task<decimal> GetMaxLimitPerMember();
        public Task<decimal> GetJlgMaxLimitPerMember();
    }
}
