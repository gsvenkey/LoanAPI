﻿using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Interface
{
   public interface IPacsReportRepository
    {
        Task<VW_Rpt_IssueSummary> RptIssueSummary(long issueId);
        Task<VW_Rpt_RequestHeader_Surity> GetRequestHeader(long sanctionId);
    }
}
