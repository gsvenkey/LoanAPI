﻿using Microsoft.AspNetCore.Mvc.Rendering;
using PACS.AgriLoan.Interface.Common;
using PASC.AgriLoan.DomainModels.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Interface
{
    public interface ILookUpCodeMasterRepository :  IGenericRepository<LookupCodeMaster>
    {
        Task<IEnumerable<SelectListItem>> SelectLookUp(string lookUpCode);
        Task<IEnumerable<SelectListItem>> SelectLookUpInTamil(string lookUpCode);
    }
}
