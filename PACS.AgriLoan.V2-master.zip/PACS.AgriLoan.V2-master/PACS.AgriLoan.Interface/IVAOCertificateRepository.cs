﻿using PACS.AgriLoan.Interface.Common;
using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Interface
{
    public interface IVAOCertificateRepository : IGenericRepository<VaoCertificateHeader>
    {
        Task<IEnumerable<VW_GetSurveyDetail>> GetSurveyDetails(long memberId);
        Task<IEnumerable<VW_GetSurveyDetailsForJlg>> GetJlgMemberServeyDetails(long jlgMemberId);
        void Update(VaoCertificateHeader entity);
        Task<VaoCertificateDetail> GetVaoCertificateDetailById(long Id);
        Task<IEnumerable<VW_VaoCertificateDetail>> GetList(long pacsId);

    }
}
