﻿using Microsoft.AspNetCore.Mvc.Rendering;
using PACS.AgriLoan.Interface.Common;
using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Interface
{
    public interface ILoanRequestRepository : IGenericRepository<LoanRequestHeader>
    {
       void Update(LoanRequestHeader entity);

        Task<IEnumerable<VW_ListLoanRequest>> GetList(long pacsId, long fYearId);

        Task<IEnumerable<SelectListItem>> SelectRequestNo(long pacsId, long memberId);

        Task<long> GetNextNo(long pacsId, long loanTypeId);

       // IQueryable<long> GetRequestNextNo(string query, params object[] parameters);


    }
}
