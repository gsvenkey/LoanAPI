﻿using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Interface
{
   public interface IValidationRepository
    {
        Task<decimal> GetMemberOutstanding(long memberId);
        Task<decimal> GetMemberOutstandingByAadhar(long aadharNo);
        Task<long> GetAadharNo(long memberId);
        Task<int> CheckSurityCount(long pacsId, long surityMemberId);
        Task<decimal> GetJewelValue(long requestId);
        Task<decimal> GetLandValue(long requestId);
        Task<decimal> GetTieupValue(long requestId);
        Task<VW_GetSurveyDetailsForJlg> GetSurveyDetail(long vaoDetailId);
    }
}
