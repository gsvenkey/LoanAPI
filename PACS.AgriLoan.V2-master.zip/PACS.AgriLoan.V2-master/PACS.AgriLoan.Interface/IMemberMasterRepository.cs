﻿using Microsoft.AspNetCore.Mvc.Rendering;
using PACS.AgriLoan.Interface.Common;
using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Interface
{
    public interface IMemberMasterRepository : IGenericRepository<MemberMaster>
    {
        Task<IEnumerable<SelectListItem>> SelectMember(long pacsId);

        Task<VW_GetMemberInfo> GetMemberInfo(long Id);

        Task<string> UploadFileToBlobAsync(long Id,string strFileName, byte[] fileData, string fileMimeType);

    }
}
