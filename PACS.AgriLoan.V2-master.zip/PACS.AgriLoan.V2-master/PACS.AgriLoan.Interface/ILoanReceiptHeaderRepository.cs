﻿using Microsoft.AspNetCore.Mvc.Rendering;
using PACS.AgriLoan.Interface.Common;
using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Interface
{
    public interface ILoanReceiptHeaderRepository : IGenericRepository<LoanReceiptHeader>
    {
        Task<IEnumerable<SelectListItem>> SelectIssueNo(long pacsId, long memberId);
        Task<VW_GetLoanReceiptPendingDetail> getReceiptDetails(long IssueId);
        Task<long> GetNextNo(long pacsId);

    }
}
