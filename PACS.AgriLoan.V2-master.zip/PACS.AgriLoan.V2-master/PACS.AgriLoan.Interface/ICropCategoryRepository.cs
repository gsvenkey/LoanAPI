﻿using Microsoft.AspNetCore.Mvc.Rendering;
using PACS.AgriLoan.Interface.Common;
using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Interface
{
    public interface ICropCategoryRepository : IGenericRepository<CropCategory>
    {
        Task<IEnumerable<SelectListItem>> SelectCropCategory();
        Task<IEnumerable<SelectListItem>> SelectCropCategory(long pacsId);

        Task<long> getCropCategoryId(long cropId);

        Task<string> getCropCategoryByCropId(long cropId);

    }
}
