﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Interface.Common
{
    public interface IUnitOfWork : IDisposable
    {
        Task<bool> Commit();

        #region Masters


        IApplicationConfigurationRepository ApplicationConfiguration { get; }
        IDistrictMasterRepository DistrictMaster { get; }
        ITalukMasterRepository TalukMaster { get; }
        IFirkaMasterRepository FirkaMaster { get; }
        IRevenueVillageMasterRepository RevenueVillageMaster { get; }
        ICropCategoryRepository CropCategory { get; }
        ICropMasterRepository CropMaster { get; }
        ILookUpCodeMasterRepository LookUpCodeMaster { get; }
        ILoanTypeMasterRepository LoanTypeMaster { get; }
        ISubRegisterOfficeRepository SubRegisterOffice { get; }
        IJewelMasterRepository JewelMaster { get; }
        ILoanRatioMasterRepository LoanRatioMaster { get; }
        IRateOfIntrestMasterRepository RateOfIntrestMaster { get; }

        #endregion


        #region Transactions

        IMemberMasterRepository MemberMaster { get; }
        IVAOCertificateRepository VAOCertificate { get; }
        ILoanRequestRepository LoanRequest { get; }
        ILoanSanctionRepository LoanSanction { get; }
        ILoanIssueRepository LoanIssue { get; }

        ITieUpCompanyMasterRepository TieUpCompanyMaster { get; }
        IJlgRepository Jlg { get; }
        ILoanReceiptHeaderRepository loanReceipt { get; }
        ILoanReceiptDetailRepository loanReceiptDetail { get; }

        #endregion


        #region Transactions
        IPacsReportRepository pacsReport { get; }

        #endregion

    }
}
