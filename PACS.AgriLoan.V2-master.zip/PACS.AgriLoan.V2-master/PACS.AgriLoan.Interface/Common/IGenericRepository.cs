﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Interface.Common
{
   public partial interface  IGenericRepository<TEntity>
    {
		#region Methods
		/// <summary>
		/// Get entity by identifier
		/// </summary>
		/// <param name="id">Identifier</param>
		/// <returns>Entity</returns>

		Task<TEntity> GetByIdsync(object id);

		
		Task<TEntity> GetFirstOrDefault(Expression<Func<TEntity, bool>> filter = null, string includeProperties = null);

		Task<IEnumerable<TEntity>> GetAllsync(Expression<Func<TEntity, bool>> filter = null,
			Func<IQueryable<TEntity>,
			IOrderedQueryable<TEntity>> orderBy = null,
		   string includeProperties = null);

		IEnumerable<TEntity> GetAll(Expression<Func<TEntity, bool>> filter = null,
			Func<IQueryable<TEntity>,
			IOrderedQueryable<TEntity>> orderBy = null,
			string includeProperties = null);

		/// <summary>
		/// Insert entity
		/// </summary>
		/// <param name="entity">Entity</param>
		Task AddAsync(TEntity entity);


		/// <summary>
		/// Insert entities
		/// </summary>
		/// <param name="entities">Entities</param>
		Task AddAsync(IEnumerable<TEntity> entities);



		/// <summary>
		/// Update entity
		/// </summary>
		/// <param name="entity">Entity</param>
		void Attach(TEntity entity);

		/// <summary>
		/// Update entities
		/// </summary>
		/// <param name="entities">Entities</param>
		void AttachRange(IEnumerable<TEntity> entities);

		void Remove(long id);

		void Remove(TEntity entities);

		void RemoveRange(IEnumerable<TEntity> entities);


		IQueryable<TEntity> Get(Expression<Func<TEntity, bool>> filter = null, Func<IQueryable<TEntity>, IOrderedQueryable<TEntity>> orderBy = null, string includeProperties = "");

		IQueryable<TEntity> GetWithRawSql(string query, params object[] parameters);

		#endregion

		#region Properties

		/// <summary>
		/// Gets a table
		/// </summary>
		IQueryable<TEntity> Table { get; }

		/// <summary>
		/// Gets a table with "no tracking" enabled (EF feature) Use it only when you load record(s) only for read-only operations
		/// </summary>
		IQueryable<TEntity> TableNoTracking { get; }

		#endregion
	}
}
