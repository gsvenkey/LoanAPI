﻿using Microsoft.AspNetCore.Mvc.Rendering;
using PACS.AgriLoan.Interface.Common;
using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Interface
{
    public interface ILoanIssueRepository : IGenericRepository<LoanIssueHeader>
    {
        void Update(LoanIssueHeader entity);
        Task<VW_GetLoanSanctionHeader> GetLoanSanctionHeader(long sanctionId);
        Task<IEnumerable<VW_GetLoanSanctionDetail>> GetLoanSanctionDetail(long sanctionId);
        //Task<IEnumerable<SelectListItem>> SelectIssueNo(long pacsId, long fYearId);
        Task<IEnumerable<VW_ListLoanIssue>> GetList(long pacsId, long fYearId);
        Task<long> GetNextNo(long pacsId, long loanTypeId);
    }
}
