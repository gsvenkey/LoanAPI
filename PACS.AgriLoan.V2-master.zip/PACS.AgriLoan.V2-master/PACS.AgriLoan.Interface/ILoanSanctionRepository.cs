﻿using Microsoft.AspNetCore.Mvc.Rendering;
using PACS.AgriLoan.Interface.Common;
using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Interface
{
    public interface ILoanSanctionRepository : IGenericRepository<LoanSanctionHeader>
    {
       void Update(LoanSanctionHeader entity);

        Task<VW_GetLoanRequestHeader> GetLoanRequestHeader(long requestId);
        Task<IEnumerable<VW_GetLoanRequestDetail>> GetLoanRequestDetail(long requestId);
        Task<IEnumerable<SelectListItem>> SelectSanctionNo(long pacsId, long memberId);
        Task<IEnumerable<VW_ListLoanSanction>> GetList(long pacsId, long fYearId);
        Task<long> GetNextNo(long pacsId, long loanTypeId);
    }
}
