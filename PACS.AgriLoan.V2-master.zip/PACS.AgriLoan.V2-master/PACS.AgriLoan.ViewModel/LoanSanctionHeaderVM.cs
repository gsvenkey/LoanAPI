﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.ViewModel
{
    public class LoanSanctionHeaderVM : BaseVM
    {
        public LoanSanctionHeaderVM()
        {
           // LoanIssueHeaders = new HashSet<LoanIssueHeader>();
            LoanSanctionDetails = new HashSet<LoanSanctionDetailVM>();
        }

        public long LoanRequestId { get; set; }
        public long LoanTypeID { get; set; }
        public long PacsId { get; set; }
        public long FYearId { get; set; }
        public long SanctionNo { get; set; }
        [Column(TypeName = "date")]
        public DateTime SanctionDate { get; set; }
        public long MemberID { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal SanctionAmount { get; set; }

       // public virtual ICollection<LoanIssueHeader> LoanIssueHeaders { get; set; }
        public virtual ICollection<LoanSanctionDetailVM> LoanSanctionDetails { get; set; }
    }
}
