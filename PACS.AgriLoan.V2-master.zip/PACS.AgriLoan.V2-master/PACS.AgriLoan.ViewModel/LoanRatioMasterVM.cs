﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.ViewModel
{
    public class LoanRatioMasterVM : BaseVM
    {
        [Column(TypeName = "date")]
        public DateTime EffectFrom { get; set; }
        [Column(TypeName = "date")]
        public DateTime? EndDate { get; set; }
        public long DistrictId { get; set; }
        public long CropId { get; set; }
        public long CategoryId { get; set; }
        [Required]
        [StringLength(100)]
        public string CategoryName { get; set; }
        [Required]
        [StringLength(200)]
        public string CategoryNameInTamil { get; set; }
        [Required]
        [StringLength(100)]
        public string Name { get; set; }
        [Required]
        [StringLength(200)]
        public string NameInTamil { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal Cash { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal Fertilizer { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal Seed { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal Pesticide { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal Maintanance { get; set; }
        [StringLength(50)]
        public string IssueMonth { get; set; }

        public int LoanDuePeriod { get; set; }

        /// <summary>
        /// Calculated Acre Cash 
        /// </summary>
        [Column(TypeName = "numeric(14, 2)")]
        public decimal AcreCash { get; set; }

        /// <summary>
        /// Fields for Cash Portion
        /// </summary>
        [Column(TypeName = "numeric(14, 2)")]
        public decimal CashFertilizer { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal CashSeed { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal CashPesticide { get; set; }

        /// <summary>
        /// Fields for Kind Portion
        /// </summary>
        [Column(TypeName = "numeric(14, 2)")]
        public decimal KindFertilizer { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal KindSeed { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal KindPesticide { get; set; }

    }
}
