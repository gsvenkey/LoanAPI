﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.ViewModel
{
   public class SuretyDetailVM : BaseVM
    {
        public long LoanRequestId { get; set; }
        public long MemberId { get; set; }
    }
}
