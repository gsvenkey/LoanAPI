﻿using System.ComponentModel.DataAnnotations;

namespace PACS.AgriLoan.ViewModel
{
    public class LoanRequestDetailVM : BaseVM
    {
        public long LoanRequestId { get; set; }
        public long CropId { get; set; }
        [Required]
        [StringLength(50)]
        public string SurveyNo { get; set; }
        public decimal Acre { get; set; }
        public decimal CultivationAcre { get; set; }
    }
}
