﻿using System.ComponentModel.DataAnnotations;

namespace PACS.AgriLoan.ViewModel
{
    public class LoanRequestDetailVM : BaseVM
    {
        public long LoanRequestId { get; set; }
        public long CropId { get; set; }
        public decimal Acre { get; set; }
        public decimal CultivationAcre { get; set; }
        public long VaoDetailId { get; set; }
        public decimal RequestAmount { get; set; }
        public virtual VaoCertificateDetailVM VaoDetail { get; set; }
        public long CropCategoryId { get; set; }
        public int LoanDuePeriod { get; set; }

    }
}
