﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.ViewModel
{
    public class ListLoanSanctionVM
    {
        public long Id { get; set; }
        public long RequestNo { get; set; }
        public long SanctionNo { get; set; }
        [Column(TypeName = "date")]
        public DateTime SanctionDate { get; set; }
        public string MemberName { get; set; }
        public string LoanType { get; set; }
        public long PacsId { get; set; }
        public long FYearId { get; set; }
        public long AdhaarNumber { get; set; }
    }
}
