﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.ViewModel
{
   public  class JewelPledgedDetailVM : BaseVM
    {
        public long LoanRequestId { get; set; }
        public long JewelMasterId { get; set; }
        public decimal NoOfItem { get; set; }
        public decimal TotalWeight { get; set; }
        public decimal DisallowedWt { get; set; }
        public decimal EstimateWeight { get; set; }
        public decimal PacsValue { get; set; }
        public decimal EstimationValue { get; set; }
        
    }
}
