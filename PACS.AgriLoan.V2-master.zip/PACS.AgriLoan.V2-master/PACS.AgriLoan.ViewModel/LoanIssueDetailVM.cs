﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.ViewModel
{
    public class LoanIssueDetailVM : BaseVM
    {
        public long IssueId { get; set; }
        public long SanctionDetailId { get; set; }
        public long CropId { get; set; }
        public int LoanDuePeriod { get; set; }
        public long VaoDetailId { get; set; }
        [Column(TypeName = "numeric(5, 2)")]
        public decimal SanctionAcre { get; set; }
        [Column(TypeName = "numeric(5, 2)")]
        public decimal IssueAcre { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal Cash { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? Seed { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? Manure { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? Pesticide { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? KindFertilizer { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? KindSeed { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? KindPesticide { get; set; }

        public string CropName { get; set; }
        public string CropNameInTamil { get; set; }

        public virtual LoanSanctionDetailVM SanctionDetail { get; set; }

        /// <summary>
        /// Adition fields for claculation
        /// </summary>
        //[Column(TypeName = "numeric(14, 2)")]
        //public decimal? FertilizerPerAcre { get; set; }
        //[Column(TypeName = "numeric(14, 2)")]
        //public decimal? SeedPerAcre { get; set; }
        //[Column(TypeName = "numeric(14, 2)")]
        //public decimal? PesticidePerAcre { get; set; }
        //[Column(TypeName = "numeric(14, 2)")]
        //public decimal? KindFertilizerPerAcre { get; set; }
        //[Column(TypeName = "numeric(14, 2)")]
        //public decimal? KindSeedPerAcre { get; set; }
        //[Column(TypeName = "numeric(14, 2)")]
        //public decimal? KindPesticidePerAcre { get; set; }
    }
}
