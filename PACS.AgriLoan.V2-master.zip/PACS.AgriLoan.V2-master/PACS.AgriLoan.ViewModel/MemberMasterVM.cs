﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.ViewModel
{
    public class MemberMasterVM : BaseVM
    {
        public long PacsId { get; set; }
        public IEnumerable<SelectListItem> SelectShareType { get; set; }
        [Required(ErrorMessage = "Please Choose Share Type"), Display(Name = "Share Type")]
        public long ShareTypeId { get; set; }
        public IEnumerable<SelectListItem> SelectMembershipType { get; set; }
        [Required(ErrorMessage = "Please Choose Membership Type"), Display(Name = "Membership Type")]
        public long MembershipTypeId { get; set; }
        [Required(ErrorMessage = "Please Enter Date"), Display(Name = "Date of Membership")]
        [DataType(DataType.Date)]
        public DateTime DateofMembership { get; set; }
        [Required(ErrorMessage = "Please Enter Member Number"), Display(Name = "Member Number")]
        public long MemberNumber { get; set; }
        [Required(ErrorMessage = "Please Enter Member Number"), Display(Name = "Name"), StringLength(50)]
        public string Name { get; set; }
        [Required(ErrorMessage = "Please Enter Name"), Display(Name = "Father/Husband"), StringLength(50)]
        public string NameFatherOrHusband { get; set; }
        [Required(ErrorMessage = "Please Enter Address1"), Display(Name = "Address1"), StringLength(50)]
        public string Address1 { get; set; }
        [Required(ErrorMessage = "Please Enter Address1"), Display(Name = "Address2"), StringLength(50)]
        public string Address2 { get; set; }
        [Display(Name = "Address3"), StringLength(50)]
        public string Address3 { get; set; }
        [Display(Name = "Address4"), StringLength(50)]
        public string Address4 { get; set; }
        [Required(ErrorMessage = "Please Enter Village Name"), Display(Name = "Village Name"), StringLength(50)]
        public string VillageName { get; set; }
        public IEnumerable<SelectListItem> SelectGender { get; set; }
        [Required(ErrorMessage = "Please Choose Gender"), Display(Name = "Gender")]
        public long GenderId { get; set; }
        public IEnumerable<SelectListItem> SelectReligion { get; set; }
        [Required(ErrorMessage = "Please Choose Share Type"), Display(Name = "Religion")]
        public long ReligionId { get; set; }
        public IEnumerable<SelectListItem> SelectCommunity { get; set; }
        [Required(ErrorMessage = "Please Choose Share Type"), Display(Name = "Community")]
        public long CommunityId { get; set; }
        [Required(ErrorMessage = "Please Enter Adhaar Number"), Display(Name = "Adhaar Number")]
        public long AdhaarNumber { get; set; }
        [Required(ErrorMessage = "Please Enter Share Amount"), Display(Name = "Share Amount")]
        public decimal ShareAmount { get; set; }
        [Required(ErrorMessage = "Please Enter Mobile Number"), Display(Name = "Mobile Number")]
        public long MobileNumber { get; set; }
        [Required(ErrorMessage = "Please Enter Society SB Number"), Display(Name = "Society SB Number")]
        public long SocietySBNumber { get; set; }
        [Required(ErrorMessage = "Please Enter DCCB SB Number"), Display(Name = "DCCB SB Number")]
        public long DCCBSBNumber { get; set; }
        [Required(ErrorMessage = "Please Enter DCCB SB CIF Number"), Display(Name = "DCCB SB CIF Number")]
        public long DCCBSBCIFNumber { get; set; }
        [Required(ErrorMessage = "Please Enter DCCB SB A/C Number"), Display(Name = "DCCB A/C CIF Number")]
        public long DCCBLSBACNumber { get; set; }
        [Display(Name = "Is Board Member")]
        public bool IsBoardMember { get; set; }
        [Display(Name = "Is Agri Waiver Availed")]
        public bool IsAgriWaiverAvailed { get; set; }
        [Display(Name = "Is Group Member")]
        public bool IsJointLiabilityGroupMember { get; set; }
        [Display(Name = "JLG Member No")]


        public string MembershipTypeName { get; set; }
        public string GenderName { get; set; }

        [Required(ErrorMessage = "Please Enter Pincode"), Display(Name = "Pincode")]
        public int PinCode { get; set; }

        public string Pannumber { get; set; }
        public string SmartCardNumber { get; set; }
        public string PhotoUrl { get; set; }

    }
}
