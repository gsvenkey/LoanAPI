﻿using System;

namespace PACS.AgriLoan.ViewModel
{
    public class ListLoanRequestVM
    {
        public long Id { get; set; }
        public long RequestNo { get; set; }
        public DateTime RequestDate { get; set; }
        public string MemberName { get; set; }
        public string LoanType { get; set; }
        public long PacsId { get; set; }
        public long FYearId { get; set; }
        public long AdhaarNumber { get; set; }
    }
}
