﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace PACS.AgriLoan.ViewModel
{
    public  class LoanRequestHeaderVM : BaseVM
    {

        public LoanRequestHeaderVM()
        {
            JewelPledgedDetails = new HashSet<JewelPledgedDetailVM>();
            JlgLoanTypeDetails = new HashSet<JlgLoanTypeDetailVM>();
            LandPledgedDetails = new HashSet<LandPledgedDetailVM>();
            LoanRequestDetails = new HashSet<LoanRequestDetailVM>();
            SuretyDetails = new HashSet<SuretyDetailVM>();
            TieUpCompanyDetails = new HashSet<TieUpCompanyDetailVM>();
            JlgLoanMemberDetails = new HashSet<JlgLoanMemberDetailVM>();
        }

        public long RequestNo { get; set; }
        public long PacsId { get; set; }
        public long FYearId { get; set; }
        [Column(TypeName = "date")]
        public DateTime RequestDate { get; set; }
        public long LoanTypeID { get; set; }
        public long VaoCertificateHeaderId { get; set; }
        public long MemberID { get; set; }


        public virtual ICollection<JewelPledgedDetailVM> JewelPledgedDetails { get; set; }
        public virtual ICollection<JlgLoanTypeDetailVM> JlgLoanTypeDetails { get; set; }
        public virtual ICollection<LandPledgedDetailVM> LandPledgedDetails { get; set; }
        public virtual ICollection<LoanRequestDetailVM> LoanRequestDetails { get; set; }
        public virtual ICollection<SuretyDetailVM> SuretyDetails { get; set; }
        public virtual ICollection<TieUpCompanyDetailVM> TieUpCompanyDetails { get; set; }
        public virtual ICollection<JlgLoanMemberDetailVM> JlgLoanMemberDetails { get; set; }


    }
}
