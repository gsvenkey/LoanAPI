﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.ViewModel
{
    public class JlgLoanTypeDetailVM : BaseVM
    {
        public long LoanRequestId { get; set; }
        public long JlgHeaderId { get; set; }
        public long ResolutionNumber { get; set; }
        [Column(TypeName = "date")]
        public DateTime ResolutionDate { get; set; }
        public decimal? MemberSavingsAmount { get; set; }
        public decimal? GovtRFSubsidyAmount { get; set; }
        public decimal? LoanOutstanding { get; set; }
        public decimal? MembersODLoanAmount { get; set; }
        public decimal? InterestIncome { get; set; }
        public decimal? JLGCashBalance { get; set; }
        public decimal? BalanceAmount { get; set; }
    }
}
