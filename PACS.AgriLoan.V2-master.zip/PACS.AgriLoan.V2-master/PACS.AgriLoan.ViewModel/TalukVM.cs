﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace PACS.AgriLoan.ViewModel
{
   public class TalukVM : BaseVM
    {
        
        public string DistrictName { get; set; }

        public IEnumerable<SelectListItem> DistrictList { get; set; }
        [Required(ErrorMessage = "Please Choose District"), Display(Name = "District")]
        public long DistrictId { get; set; }

        [StringLength(50)]
        [Required(ErrorMessage = "Please enter Name"), Display(Name = "Name"), MaxLength(15), MinLength(5)]
        public string Name { get; set; }
        [StringLength(15)]
        [Required(ErrorMessage = "Please enter Short Name"), Display(Name = "Short Name"), MaxLength(15), MinLength(5)]
        public string ShortName { get; set; }
        [StringLength(50)]
        [Required(ErrorMessage = "Please enter Name in Tamil"), Display(Name = "Name in Tamil"), MaxLength(15), MinLength(5)]
        public string NameInTamil { get; set; }
    }
}
