﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.ViewModel
{
   public class JlgValidationVM
    {
        public long VaoDetailId { get; set; }
        public decimal LoanAmount { get; set; }

        public long MemberId { get; set; }
        public string MemberName { get; set; }
        public string SubDivisionNo { get; set; }
        public int  SurveyNo { get; set; }
        public long AdhaarNumber { get; set; }

    }
}
