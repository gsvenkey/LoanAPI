﻿namespace PACS.AgriLoan.ViewModel
{
    public class BondReportVM
    {
        public long PacsId { get; set; }
        public long Id { get; set; }
        public long LoanTypeID { get; set; }
        public string LoanTypeName { get; set; }
        public string LoanTypeNameInTamil { get; set; }
        public long RateOfInterestId { get; set; }
        public decimal Normal { get; set; }
        public decimal Penal { get; set; }
        public decimal SanctionAmount { get; set; }
        public decimal IssueAmount { get; set; }
        public long MemberId { get; set; }
        public string MemberName { get; set; }
        public string GardianName { get; set; }
        public string Relationship { get; set; }
        public string Address1 { get; set; }
        public string Address2 { get; set; }
        public string Address3 { get; set; }
        public string Address4 { get; set; }
        public string VillageName { get; set; }
        public int Pincode { get; set; }
        public string PacsNameInTamil { get; set; }
    }
}
