﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.ViewModel
{
    public class ValidationVM
    {
        public ValidationVM()
        {
            this.IsValid = true;
            this.ValidationMessage = string.Empty;
            this.WarningMessage = string.Empty;
        }
        public bool IsValid { get; set; }
        public string WarningMessage { get; set; }
        public string ValidationMessage { get; set; }
    }
}
