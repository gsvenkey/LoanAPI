﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.ViewModel
{
    public class LoanReceiptDetailVM : BaseVM
    {
        public long ReceiptId { get; set; }
        [Column(TypeName = "date")]
        public DateTime ReceiptDate { get; set; }
        public long ReceiptNo { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal Principal { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? Interest { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? PenalInterest { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? Noticecharge { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? ARCFees { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? EPFees { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? OtherFees { get; set; }
    }
}
