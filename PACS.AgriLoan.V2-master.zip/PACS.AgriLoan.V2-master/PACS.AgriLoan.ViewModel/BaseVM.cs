﻿using System;
using System.ComponentModel.DataAnnotations;

namespace PACS.AgriLoan.ViewModel
{
    public class BaseVM
    {
		public BaseVM()
		{
			//this.CreatedDate = DateTime.Now;
			//this.ModifiedDate = DateTime.Now;
			this.IsDeleted = false;
		}

		//[Key]
		//[ScaffoldColumn(false)]
		public long Id { get; set; }

		public DateTime? CreatedDate { get; set; }
		public DateTime? ModifiedDate { get; set; }

		[Display(Name = "Status")]
		public bool IsDeleted { get; set; } = false;
		public int? CreatedBy { get; set; }
		public int? ModifiedBy { get; set; }
        public string Message { get; set; }
	}
}
