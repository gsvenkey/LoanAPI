﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.ViewModel
{
   public class TieUpCompanyDetailVM : BaseVM
    {
        public long LoanRequestId { get; set; }
        public long TieUpCompanyId { get; set; }
        [Column(TypeName = "date")]
        public DateTime TieupLetterDate { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? MaximumLoanAmount { get; set; }
    }
}
