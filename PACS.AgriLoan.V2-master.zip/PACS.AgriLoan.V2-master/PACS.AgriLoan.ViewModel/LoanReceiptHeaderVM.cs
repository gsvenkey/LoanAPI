﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.ViewModel
{
    public class LoanReceiptHeaderVM : BaseVM
    {
        public LoanReceiptHeaderVM()
        {
            LoanReceiptDetails = new HashSet<LoanReceiptDetailVM>();
        }

        public long PacsId { get; set; }
        public long FYearId { get; set; }
        public long MemberId { get; set; }
        public long LoanTypeId { get; set; }
        public long IssueId { get; set; }
        public long IssueNo { get; set; }
        [StringLength(20)]
        public string LoanNo { get; set; }
        [Column(TypeName = "date")]
        public DateTime IssueDate { get; set; }
        [Column(TypeName = "date")]
        public DateTime DueDate { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal IssueAmount { get; set; }
        public long RateId { get; set; }
        [Column(TypeName = "numeric(5, 2)")]
        public decimal NormalROI { get; set; }
        [Column(TypeName = "numeric(5, 2)")]
        public decimal PenalROI { get; set; }
        public int? NormalNoOfDays { get; set; }
        public int? PenalNoOfDays { get; set; }
        [Column(TypeName = "numeric(38, 2)")]
        public decimal? PrinicipalPaid { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? Intrest { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? PenalIntrest { get; set; }
        
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? PrinicipalTaken { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? BalancePrinicipal { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? ReceiptAmount { get; set; }


        public virtual ICollection<LoanReceiptDetailVM> LoanReceiptDetails { get; set; }
    }
}
