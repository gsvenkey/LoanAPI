﻿using System;

namespace PACS.AgriLoan.ViewModel
{
    public class ServeyDetailsVM
    {
        public long JlgMemberId { get; set; }
        public string Name { get; set; }
        public long MemberNumber { get; set; }
        public long VaoDetailId { get; set; }
        public long PacsId { get; set; }
        public long MemberId { get; set; }
        public long? VaoCertificateId { get; set; }
        public DateTime CertificateDate { get; set; }
        public string ServeyNo { get; set; }
        public string SubDivisionNo { get; set; }
        public decimal TotalArea { get; set; }
        public decimal Bounded { get; set; }
        public long AdhaarNumber { get; set; }
        
    }
}
