﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.ViewModel
{
    public class JewelValuationVM : BaseVM
    {
        public long PacsId { get; set; }
        [Column(TypeName = "date")]
        public DateTime PriceDate { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal MarketPrice { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal PacsValue { get; set; }
    }
}
