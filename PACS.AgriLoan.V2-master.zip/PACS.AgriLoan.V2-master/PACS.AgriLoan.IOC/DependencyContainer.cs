﻿using Microsoft.Extensions.DependencyInjection;
using PACS.AgriLoan.Business.Interface;
using PACS.AgriLoan.Services.Implementation;
using PACS.AgriLoan.Interface.Common;
using PACS.AgriLoan.Repositories.Common;
using AutoMapper;
using PACS.AgriLoan.Services.AutoMapper;
using AutoMapper.EquivalencyExpression;

namespace PACS.AgriLoan.IOC
{
    public static class DependencyContainer
    {
        public static MapperConfiguration CreateConfiguration()
        {
            var config = new MapperConfiguration(cfg =>
                {
                    cfg.AddCollectionMappers();
                    // Add all profiles in current assembly
                    cfg.AddProfile(new DistrictMasterMapping());
                    cfg.AddProfile(new TalukMasterMapping());
                    cfg.AddProfile(new MemberMasterMapping());
                    cfg.AddProfile(new VAOCertificateMapping());
                    cfg.AddProfile(new LoanRequestMapping());
                    cfg.AddProfile(new TieUpCompanyMasterMapping());
                    cfg.AddProfile(new JlgMapping());
                    cfg.AddProfile(new LoanScanctionMapping());
                    cfg.AddProfile(new LoanIssueMapping());
                    cfg.AddProfile(new LoanRatioMasterMapping());
                    cfg.AddProfile(new PacsReportMappings());
                    


                });
            config.AssertConfigurationIsValid();
            return config;

        }

        public static void RegisterServices(IServiceCollection services)
        {
            //CleanArchitecture.Core
            services.AddScoped<IDistrictMasterBL, DistrictMasterBL>();

            //CleanArchitecture.Domain.Interfaces | CleanArchitecture.Infrastructure.Repositories
            services.AddScoped(typeof(IGenericRepository<>), typeof(GenericRepository<>));
            services.AddScoped<IUnitOfWork, UnitOfWork>();
            services.AddScoped<IDistrictMasterBL, DistrictMasterBL>();
            services.AddScoped<ITalukMasterBL, TalukMasterBL>();
            services.AddScoped<IFirkaMasterBL, FirkaMasterBL>();
            services.AddScoped<IRevenueVillageMasterBL, RevenueVillageMasterBL>();
            services.AddScoped<ICropCategoryBL, CropCategoryBL>();
            services.AddScoped<ICropMasterBL, CropMasterBL>();
            services.AddScoped<ILookUpCodeMasterBL, LookUpCodeMasterBL>();
            services.AddScoped<ILoanTypeMasterBL, LoanTypeMasterBL>();
            services.AddScoped<ISubRegisterOfficeBL, SubRegisterOfficeBL>();
            services.AddScoped<IJewelMasterBL, JewelMasterBL>();
            services.AddScoped<ILoanRatioMasterBL, LoanRatioMasterBL>();

            


            services.AddScoped<IMemberMasterBL, MemberMasterBL>();
            services.AddScoped<IVAOCertificateBL, VAOCertificateBL>();
            services.AddScoped<ILoanRequestBL, LoanRequestBL>();
            services.AddScoped<ILoanSanctionBL, LoanSanctionBL>();
            services.AddScoped<ILoanIssueBL, LoanIssueBL>();
            services.AddScoped<ITieUpCompanyMasterBL, TieUpCompanyMasterBL>();
            services.AddScoped<IJlgBL, JlgBL>();

            
            services.AddScoped<IPacsReportBL, PacsReportBL>();


        }


    }
}
