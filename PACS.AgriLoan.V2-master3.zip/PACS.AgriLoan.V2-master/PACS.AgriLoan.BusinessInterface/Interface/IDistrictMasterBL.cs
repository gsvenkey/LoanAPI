﻿using Microsoft.AspNetCore.Mvc.Rendering;
using PACS.AgriLoan.ViewModel;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Business.Interface
{
    public interface IDistrictMasterBL
    {
        
        Task<IEnumerable<DistrictVM>> GetAll();
        Task<DistrictVM> GetById(long Id);
        Task<IEnumerable<SelectListItem>> SelectDistrict();
        Task<DistrictVM> Add(DistrictVM districtVM);
        Task<DistrictVM> Update(DistrictVM districtVM);
        Task<DistrictVM> SoftDelete(DistrictVM districtVM);
        Task<bool> IsDistrictExist(long Id);
        Task<bool> IsDistrictExist(string Name);
    }
}
