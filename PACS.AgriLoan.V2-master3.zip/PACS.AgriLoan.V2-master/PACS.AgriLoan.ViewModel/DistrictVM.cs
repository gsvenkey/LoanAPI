﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace PACS.AgriLoan.ViewModel
{
    public class DistrictVM : BaseVM
    {


        [RegularExpression(@"^[a-zA-Z]+$", ErrorMessage = "Use English letters only please")]
        [Required(ErrorMessage = "Please enter Name in English"), Display(Name = "Name"), MaxLength(15), MinLength(5)]
        public string Name { get; set; }

        [RegularExpression(@"^[a-zA-Z]+$", ErrorMessage = "Use English letters only please")]
        [Required(ErrorMessage = "Please enter Short Name in English"), Display(Name = "Short Name"), MaxLength(15), MinLength(5)]
        public string ShortName { get; set; }

        [Required(ErrorMessage = "Please enter Name In Tamil"), Display(Name = "Name In Tamil"), MaxLength(50), MinLength(5)]
        public string NameInTamil { get; set; }

        //public List<DistrictVM> districtVMs;


    }

    //public class DistrictListVM : List<DistrictVM>
    //{
    //    public List<DistrictVM> Districts;

    //    public DistrictListVM()
    //    {
    //        Districts = new List<DistrictVM>();
    //    }
    //}
}
