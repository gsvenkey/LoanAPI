﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.ViewModel
{
    public class VaoCertificateDetailVM : BaseVM
    {
        public long VaoCertificateId { get; set; }
        [Required(ErrorMessage = "Please Enter Servey No"), Display(Name = "Servey No"), StringLength(50)]
        public string ServeyNo { get; set; }
        [StringLength(50)]
        public string SubDivisionNo { get; set; }
        [Required(ErrorMessage = "Please Enter Total Area"), Display(Name = "Total Area"), Column(TypeName = "numeric(5, 2)")]
        public decimal TotalArea { get; set; }
        [Required(ErrorMessage = "Please Enter Bounded Area"), Display(Name = "Bounded Area"), Column(TypeName = "numeric(5, 2)")]
        public decimal Bounded { get; set; }

        
    }
}
