﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.ViewModel
{
   public class JlgMembersInfoVM
    {
        public long PacsId { get; set; }
        public long JlgHeaderId { get; set; }

        public long JlgMemberId { get; set; }
        public long JlgMemberTypeId { get; set; }
        public long MemberNumber { get; set; }
        [Required]
        [StringLength(100)]
        public string Name { get; set; }
        [Required]
        [StringLength(100)]
        public string NameFatherOrHusband { get; set; }
        [Required]
        [StringLength(50)]
        public string Address1 { get; set; }
        [Required]
        [StringLength(100)]
        public string Address2 { get; set; }
        [StringLength(100)]
        public string Address3 { get; set; }
        [StringLength(100)]
        public string Address4 { get; set; }
        public int Pincode { get; set; }
        public long MobileNumber { get; set; }
        public long AdhaarNumber { get; set; }
        public string PhotoUrl { get; set; }
    }

}
