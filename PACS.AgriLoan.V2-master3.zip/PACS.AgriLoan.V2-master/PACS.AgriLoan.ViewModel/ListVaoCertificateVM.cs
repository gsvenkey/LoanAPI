﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.ViewModel
{
   public class ListVaoCertificateVM
    {
        public long PacsId { get; set; }
        public long Id { get; set; }
        [Column(TypeName = "date")]
        public DateTime CertificateDate { get; set; }
        public long MemberId { get; set; }
        [Required]
        [StringLength(100)]
        public string MemberName { get; set; }
        public long AdhaarNumber { get; set; }
        public long MobileNumber { get; set; }
        [Column(TypeName = "numeric(5, 2)")]
        public decimal TotalAcre { get; set; }
        [Column(TypeName = "numeric(5, 2)")]
        public decimal TotalBoundedAcre { get; set; }
    }
}
