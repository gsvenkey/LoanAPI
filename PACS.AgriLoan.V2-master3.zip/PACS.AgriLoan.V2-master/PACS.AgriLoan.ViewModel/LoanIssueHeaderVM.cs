﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.ViewModel
{
   public class LoanIssueHeaderVM : BaseVM
    {
        public LoanIssueHeaderVM()
        {
            LoanIssueDetails = new HashSet<LoanIssueDetailVM>();
        }

        public long SanctionId { get; set; }
        public long PacsId { get; set; }
        public long FYearId { get; set; }
        public long LoanTypeID { get; set; }
        public long IssueNo { get; set; }
        [StringLength(20)]
        public string LoanNo { get; set; }
        [Column(TypeName = "date")]
        public DateTime IssueDate { get; set; }
        public long MemberID { get; set; }
        public DateTime DueDate { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal IssueAmount { get; set; }
        public virtual ICollection<LoanIssueDetailVM> LoanIssueDetails { get; set; }

    }
}
