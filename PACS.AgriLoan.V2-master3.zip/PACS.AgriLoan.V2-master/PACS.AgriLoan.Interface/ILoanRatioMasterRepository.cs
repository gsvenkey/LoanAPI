﻿using PACS.AgriLoan.Interface.Common;
using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Interface
{
    public interface ILoanRatioMasterRepository : IGenericRepository<LoanRatioMaster>
    {
        Task<VW_GetLoanRatioForCrop> GetLoanRatioForCrop(long pacsId, long cropId);
        Task<decimal> GetEstimationAmount(long pacsId, long cropId);
    }
}
