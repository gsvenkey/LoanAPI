﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using PACS.AgriLoan.Business.Interface;
using PACS.AgriLoan.ViewModel;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PACS.AgriLoan.API.Controllers.Masters
{
    [Route("api/[controller]")]
    [ApiController]
    public class DistrictMasterController : ControllerBase
    {

        private readonly IDistrictMasterBL _districtMasterBL;
        private readonly ILogger<DistrictMasterController> _logger;


        public DistrictMasterController(ILogger<DistrictMasterController> logger, IDistrictMasterBL districtMasterBL)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _districtMasterBL = districtMasterBL ?? throw new ArgumentNullException(nameof(districtMasterBL));
        }
        // GET: api/<DistrictController>
        [HttpGet]
        public async Task<ActionResult<DistrictVM>> GetAll()
        {
            _logger.LogInformation("GetAll Method Invoked in DistrictMasterController ");
            return Ok(await _districtMasterBL.GetAll());
        }

        [HttpGet("SelectDistrict")]
        public async Task<ActionResult<SelectListItem>> SelectDistrict()
        {
            _logger.LogInformation("SelectDistrict Method Invoked in DistrictMasterController ");
            return Ok(await _districtMasterBL.SelectDistrict());
        }

        //GET api/<DistrictController>/5
        [HttpGet("{id}")]

        public async Task<ActionResult<DistrictVM>> GetDistrictById(long id)
        {
            _logger.LogInformation("GetDistrictById Invoked & Id is : " + id);
            var districtMaster = await _districtMasterBL.GetById(id);
            return Ok(districtMaster) != null ? districtMaster : NotFound();
        }

        // POST: api/DistrictMasters
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPost]
        public async Task<ActionResult<DistrictVM>> AddDistrict(DistrictVM districtVM)
        {
            _logger.LogInformation("AddDistrict Invoked   : " + districtVM);


            if (await DistrictMasterExists(districtVM.Name))
            {
                districtVM.Message = districtVM.Name + " already Exist";
                return BadRequest(districtVM.Message);
            }
            else
            {

                var district = await _districtMasterBL.Add(districtVM);
                _logger.LogInformation("AddDistrict Responded : " + district);
                return Ok(district != null ? district : NotFound());
            }
        }

        // PUT: api/DistrictMasters/5
        // To protect from overposting attacks, enable the specific properties you want to bind to, for
        // more details, see https://go.microsoft.com/fwlink/?linkid=2123754.
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateDistrict(long id, DistrictVM districtVM)
        {
            _logger.LogInformation("UpdateDistrict Invoked  : " + districtVM);

            if (id != districtVM.Id)
            {
                _logger.LogWarning("Bad Request  : " + districtVM);
                return BadRequest();
            }
            Task<bool> task = DistrictMasterExists(id);
            if (await task)
            {
                var district = await _districtMasterBL.Update(districtVM);
                _logger.LogInformation("AddDistrict Responded : " + district);
                return Ok(district != null ? district : NotFound());
            }
            else
            {
                return NotFound();
            }
        }

        // DELETE api/<DistrictController>/5
        [HttpDelete("{id}")]
        public async Task<ActionResult<DistrictVM>> DeleteDistrict(long id, DistrictVM districtVM)
        {
            _logger.LogInformation("DeleteDistrict Invoked  : " + districtVM);

            if (id == districtVM.Id)
            {
                Task<bool> task = DistrictMasterExists(id);
                return await task ? await _districtMasterBL.SoftDelete(districtVM) : NotFound();
            }
            return BadRequest();
        }
        #region Private Methods
        private async Task<bool> DistrictMasterExists(long id)
        {

            return await _districtMasterBL.IsDistrictExist(id);
        }

        private async Task<bool> DistrictMasterExists(string Name)
        {
            return await _districtMasterBL.IsDistrictExist(Name);
        }
        #endregion

    }
}
