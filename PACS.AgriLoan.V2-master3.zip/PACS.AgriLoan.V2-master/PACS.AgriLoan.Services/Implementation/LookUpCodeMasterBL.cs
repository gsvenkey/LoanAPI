﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using PACS.AgriLoan.Business.Interface;
using PACS.AgriLoan.Interface.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Services.Implementation
{
    public class LookUpCodeMasterBL : ILookUpCodeMasterBL
    {
        #region Properties

        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;
        private readonly ILogger<LookUpCodeMasterBL> _logger;

        #endregion

        #region Constructor

        public LookUpCodeMasterBL(IUnitOfWork unitOfWork, IMapper mapper, ILogger<LookUpCodeMasterBL> logger)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
            _logger = logger;
        }

        #endregion

        public async Task<IEnumerable<SelectListItem>> SelectLookUp(string lookUpCode)
        {
            return await _unitOfWork.LookUpCodeMaster.SelectLookUp(lookUpCode);
        }

        public async Task<IEnumerable<SelectListItem>> SelectLookUpInTamil(string lookUpCode)
        {
            return await _unitOfWork.LookUpCodeMaster.SelectLookUpInTamil(lookUpCode);
        }
    }
}
