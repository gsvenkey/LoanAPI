﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc.Rendering;
using PACS.AgriLoan.Business.Interface;
using PACS.AgriLoan.Interface.Common;
using PACS.AgriLoan.ViewModel;
using PASC.AgriLoan.DomainModels.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Services.Implementation
{
    public class TalukMasterBL : ITalukMasterBL
    {
        #region Properties

        private readonly IUnitOfWork _unitOfWork;
        private readonly IMapper _mapper;

        #endregion

        #region Constructor

        public TalukMasterBL(IUnitOfWork unitOfWork, IMapper mapper)
        {
            _unitOfWork = unitOfWork;
            _mapper = mapper;
        }

        #endregion

       

        public async Task<IEnumerable<SelectListItem>> SelectTaluk(long districtId)
        {
            return await _unitOfWork.TalukMaster.SelectTaluk(districtId);
        }
        public async Task<IEnumerable<TalukVM>> GetAll()
        {
            var obj = await _unitOfWork.TalukMaster.GetAllsync();
            return obj != null ? _mapper.Map<IEnumerable<TalukVM>>(obj) : null;
        }

        #region CURD Operation
        public async Task<TalukVM> Add(TalukVM districtVM)
        {
            var obj = _mapper.Map<TalukMaster>(districtVM);
            await _unitOfWork.TalukMaster.AddAsync(obj);
            await _unitOfWork.Commit();
            return districtVM;
        }

        public async Task<TalukVM> Update(TalukVM districtVM)
        {
            _unitOfWork.TalukMaster.Update(_mapper.Map<TalukMaster>(districtVM));
            await _unitOfWork.Commit();
            return districtVM;
        }

        public async Task<TalukVM> GetById(long Id)
        {
            var obj = await _unitOfWork.TalukMaster.GetByIdsync(Id);
            return obj != null ? _mapper.Map<TalukVM>(obj) : null;
        }

        public async Task<TalukVM> SoftDelete(TalukVM districtVM)
        {
            _unitOfWork.TalukMaster.Remove(_mapper.Map<TalukMaster>(districtVM));
            await _unitOfWork.Commit();
            return districtVM;
        }


        #endregion

        #region Valiation
        /// <summary>
        /// Check by ID
        /// </summary>
        /// <param name="Id"></param>
        /// <returns></returns>
        public async Task<bool> IsTalukExist(long Id)
        {
            return await _unitOfWork.TalukMaster.IsExist(Id);

        }
        /// <summary>
        /// Check by Name
        /// </summary>
        /// <param name="Name"></param>
        /// <returns></returns>
        public async Task<bool> IsTalukExist(string Name)
        {
            return await _unitOfWork.TalukMaster.IsExist(Name);

        }

        
        #endregion
    }
}
