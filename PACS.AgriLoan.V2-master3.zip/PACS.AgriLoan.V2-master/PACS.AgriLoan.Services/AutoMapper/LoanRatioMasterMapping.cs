﻿using AutoMapper;
using PACS.AgriLoan.ViewModel;
using PASC.AgriLoan.DomainModels.Models;

namespace PACS.AgriLoan.Services.AutoMapper
{
    public class LoanRatioMasterMapping : Profile
    {
        public LoanRatioMasterMapping()
        {
            CreateMap<VW_GetLoanRatioForCrop, LoanRatioMasterVM>()
                .ForMember(dest => dest.Message, src => src.Ignore())
                .ForMember(dest => dest.CreatedBy, src => src.Ignore())
                .ForMember(dest => dest.CreatedDate, src => src.Ignore())
                .ForMember(dest => dest.ModifiedBy, src => src.Ignore())
                .ForMember(dest => dest.ModifiedDate, src => src.Ignore())
                .ForMember(dest => dest.EndDate, src => src.Ignore())
                .ForMember(dest => dest.AcreCash, src => src.Ignore())
                .ForMember(dest => dest.CashFertilizer, src => src.Ignore())
                .ForMember(dest => dest.CashSeed, src => src.Ignore())
                .ForMember(dest => dest.CashPesticide, src => src.Ignore())
                .ForMember(dest => dest.KindFertilizer, src => src.Ignore())
                .ForMember(dest => dest.KindSeed, src => src.Ignore())
                .ForMember(dest => dest.KindPesticide, src => src.Ignore())
                .ForMember(dest => dest.IsDeleted, src => src.Ignore())
            ;
        }
    }
}
