﻿using AutoMapper;
using PACS.AgriLoan.ViewModel;
using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Services.AutoMapper
{
    public class TieUpCompanyMasterMapping : Profile
    {
        public TieUpCompanyMasterMapping()
        {
            CreateMap<TieUpCompanyMaster, TieUpCompanyMasterVM>()
                .ForMember(dest => dest.Message, src => src.Ignore()) 
            //.ForAllOtherMembers(opt => opt.Ignore())
            ;
            CreateMap<TieUpCompanyMasterVM, TieUpCompanyMaster>()
                .ForMember(dest => dest.TieUpCompanyDetails, src => src.Ignore())
                .ForMember(dest => dest.District, src => src.Ignore())

            //.ForAllOtherMembers(opt => opt.Ignore())
            ;
        }
    }
}
