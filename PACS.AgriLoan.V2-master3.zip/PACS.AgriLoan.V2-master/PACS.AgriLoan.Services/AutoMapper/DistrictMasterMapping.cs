﻿using AutoMapper;
using PACS.AgriLoan.ViewModel;
using PASC.AgriLoan.DomainModels.Models;

namespace PACS.AgriLoan.Services.AutoMapper
{
    public class DistrictMasterMapping : Profile
    {
        public DistrictMasterMapping()
        {
            CreateMap<DistrictVM, DistrictMaster>()
                .ForMember(dest => dest.Id, src => src.MapFrom(src => src.Id))
                .ForMember(dest => dest.Name, src => src.MapFrom(src => src.Name))
                .ForMember(dest => dest.ShortName, src => src.MapFrom(src => src.ShortName))
                .ForMember(dest => dest.NameInTamil, src => src.MapFrom(src => src.NameInTamil))
                .ForMember(dest => dest.IsDeleted, src => src.MapFrom(src => src.IsDeleted))
                .ForMember(dest => dest.CreatedBy, src => src.MapFrom(src => src.CreatedBy))
                .ForMember(dest => dest.CreatedDate, src => src.MapFrom(src => src.CreatedDate))
                .ForMember(dest => dest.ModifiedBy, src => src.MapFrom(src => src.ModifiedBy))
                .ForMember(dest => dest.ModifiedDate, src => src.MapFrom(src => src.ModifiedDate))
                .ForAllOtherMembers(opt => opt.Ignore());


            CreateMap<DistrictMaster, DistrictVM>()
                .ForMember(dest => dest.Message, src => src.Ignore());
        }
    }
}
