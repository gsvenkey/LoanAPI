import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-district-create',
  templateUrl: './district-create.component.html',
  styleUrls: ['./district-create.component.css']
})
export class DistrictCreateComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
