﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Table("ShareValueMaster")]
    public partial class ShareValueMaster
    {
        [Key]
        public long Id { get; set; }
        [Column(TypeName = "date")]
        public DateTime EffectFrom { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? ShareValue { get; set; }
        [Column(TypeName = "numeric(3, 2)")]
        public decimal? SF { get; set; }
        [Column(TypeName = "numeric(3, 2)")]
        public decimal? MF { get; set; }
        [Column(TypeName = "numeric(3, 2)")]
        public decimal? PF { get; set; }
        public bool IsDeleted { get; set; }
        public int? CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        public int? ModifiedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDate { get; set; }
    }
}
