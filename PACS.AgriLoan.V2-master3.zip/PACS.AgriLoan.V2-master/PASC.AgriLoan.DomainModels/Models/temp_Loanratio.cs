﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Keyless]
    [Table("temp_Loanratio")]
    public partial class temp_Loanratio
    {
        public long? Id { get; set; }
        [Column(TypeName = "date")]
        public DateTime? RatioEffectFrom { get; set; }
        [Column(TypeName = "date")]
        public DateTime? RatioEnd { get; set; }
        [StringLength(100)]
        public string DistrictName { get; set; }
        public string Category { get; set; }
        [StringLength(100)]
        public string CropName { get; set; }
        public string CropNameIntamil { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? Cash { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? Fertiliser { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? Manure { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? Seed { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? Pesticide { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? Maintanance { get; set; }
        [StringLength(100)]
        public string MonthNumber { get; set; }
        public string Result { get; set; }
        public bool? outputstatus { get; set; }
    }
}
