﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Table("DccbSanctionOrder")]
    [Index(nameof(FYearId), nameof(PacsId), nameof(LoanTypeId), Name = "UC_DccbSanctionOrder", IsUnique = true)]
    public partial class DccbSanctionOrder
    {
        [Key]
        public long Id { get; set; }
        public long FYearId { get; set; }
        public long PacsId { get; set; }
        public long LoanTypeId { get; set; }
        [Column(TypeName = "numeric(14, 0)")]
        public decimal SanctionOrderNumber { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal SanctionAmount { get; set; }
        public bool IsDeleted { get; set; }
        public int? CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        public int? ModifiedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDate { get; set; }

        [ForeignKey(nameof(FYearId))]
        [InverseProperty(nameof(FinancialYear.DccbSanctionOrders))]
        public virtual FinancialYear FYear { get; set; }
        [ForeignKey(nameof(LoanTypeId))]
        [InverseProperty(nameof(LoanTypeMaster.DccbSanctionOrders))]
        public virtual LoanTypeMaster LoanType { get; set; }
        [ForeignKey(nameof(PacsId))]
        [InverseProperty(nameof(PacsMaster.DccbSanctionOrders))]
        public virtual PacsMaster Pacs { get; set; }
    }
}
