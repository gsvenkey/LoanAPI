﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Keyless]
    [Table("temp_Member")]
    public partial class temp_Member
    {
        public long? Id { get; set; }
        [StringLength(150)]
        public string Pacs { get; set; }
        [StringLength(150)]
        public string ShareType { get; set; }
        [StringLength(150)]
        public string MembershipType { get; set; }
        [Column(TypeName = "date")]
        public DateTime? DateofMembership { get; set; }
        public int? MemberNumber { get; set; }
        [StringLength(150)]
        public string Name { get; set; }
        [StringLength(150)]
        public string NameFatherOrHusband { get; set; }
        [StringLength(150)]
        public string Address1 { get; set; }
        [StringLength(150)]
        public string Address2 { get; set; }
        [StringLength(150)]
        public string Address3 { get; set; }
        [StringLength(150)]
        public string Address4 { get; set; }
        [StringLength(150)]
        public string VillageName { get; set; }
        public int? Pincode { get; set; }
        [StringLength(50)]
        public string Gender { get; set; }
        [StringLength(50)]
        public string Religion { get; set; }
        [StringLength(50)]
        public string Community { get; set; }
        public long? AdhaarNumber { get; set; }
        [StringLength(15)]
        public string PANnumber { get; set; }
        [StringLength(20)]
        public string SmartCardNumber { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? ShareAmount { get; set; }
        public long? MobileNumber { get; set; }
        public long? SocietySBNumber { get; set; }
        public long? DCCBSBNumber { get; set; }
        public long? DCCBSBCIFNumber { get; set; }
        public long? DCCBLSBACNumber { get; set; }
        public bool? IsBoardMember { get; set; }
        public bool? IsAgriWaiverAvailed { get; set; }
        public bool? IsJointLiabilityGroupMember { get; set; }
        public string Result { get; set; }
        public bool? outputstatus { get; set; }
    }
}
