﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    public partial class TieUpCompanyDetail
    {
        [Key]
        public long Id { get; set; }
        public long LoanRequestId { get; set; }
        public long TieUpCompanyId { get; set; }
        [Column(TypeName = "date")]
        public DateTime TieupLetterDate { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? MaximumLoanAmount { get; set; }
        public bool IsDeleted { get; set; }
        public int? CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        public int? ModifiedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDate { get; set; }

        [ForeignKey(nameof(LoanRequestId))]
        [InverseProperty(nameof(LoanRequestHeader.TieUpCompanyDetails))]
        public virtual LoanRequestHeader LoanRequest { get; set; }
        [ForeignKey(nameof(TieUpCompanyId))]
        [InverseProperty(nameof(TieUpCompanyMaster.TieUpCompanyDetails))]
        public virtual TieUpCompanyMaster TieUpCompany { get; set; }
    }
}
