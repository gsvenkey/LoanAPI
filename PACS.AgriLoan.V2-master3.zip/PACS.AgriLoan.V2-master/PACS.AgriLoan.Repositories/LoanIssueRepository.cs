﻿using Microsoft.EntityFrameworkCore;
using PACS.AgriLoan.Interface;
using PACS.AgriLoan.Repositories.Common;
using PACS.AgriLoan.Repositories.DbContext;
using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Repositories
{
    public class LoanIssueRepository : GenericRepository<LoanIssueHeader>, ILoanIssueRepository
    {

        private readonly AppDbContext _db;

        public LoanIssueRepository(AppDbContext db) : base(db)
        {
            _db = db;
        }

        public async Task<IEnumerable<VW_ListLoanIssue>> GetList(long pacsId, long fYearId)
        {
            return await _db.VW_ListLoanIssues.AsNoTracking().Where(c => c.PacsId == pacsId && c.FYearId == fYearId).ToListAsync();

        }

        public async Task<IEnumerable<VW_GetLoanSanctionDetail>> GetLoanSanctionDetail(long SanctionId)
        {
            return await _db.VW_GetLoanSanctionDetails.Where(p => p.SanctionId == SanctionId).ToListAsync();
        }

        public async Task<VW_GetLoanSanctionHeader> GetLoanSanctionHeader(long SanctionId)
        {
            return await _db.VW_GetLoanSanctionHeaders.AsNoTracking().Where(c => c.Id == SanctionId).FirstOrDefaultAsync();
        }

        public void Update(LoanIssueHeader entity)
        {
            if (entity == null)
            {
                throw new ArgumentNullException(nameof(entity));
            }
            try
            {
                GetEntities().Update(entity);
            }
            catch (Exception ex)
            {
                ex.ToString();
            }
        }
    }
}
