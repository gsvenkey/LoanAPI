﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace PACS.AgriLoan.ViewModel
{
    public class LandPledgedDetailVM : BaseVM
    {
        public long LoanRequestId { get; set; }
        public long SubRegisterId { get; set; }
        [Required]
        [StringLength(100)]
        public string MortgageRegNo { get; set; }
        [Column(TypeName = "date")]
        public DateTime? DateOfMortgage { get; set; }
        public decimal? MortgageAmount { get; set; }
    }
}
