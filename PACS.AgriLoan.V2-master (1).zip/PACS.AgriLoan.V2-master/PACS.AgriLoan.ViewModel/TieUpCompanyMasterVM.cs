﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.ViewModel
{
  public  class TieUpCompanyMasterVM : BaseVM
    {
        public long DistrictId { get; set; }
        [Required]
        [StringLength(100)]
        public string CompanyName { get; set; }
        [Required]
        [StringLength(100)]
        public string CompanyAddress { get; set; }
        public long? ContactNo { get; set; }
        [Column(TypeName = "date")]
        public DateTime? LetterFromDate { get; set; }
        [Column(TypeName = "date")]
        public DateTime? LetterEndDate { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? MaxLoanAmount { get; set; }
    }
}
