﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.ViewModel
{
    public class VaoCertificateHeaderVM : BaseVM
    {
        public VaoCertificateHeaderVM()
        {
            VaoCertificateDetails = new HashSet<VaoCertificateDetailVM>();
        }

        public long MemberId { get; set; }
        [Column(TypeName = "date")]
        public DateTime DateOfEntry { get; set; }
        [Column(TypeName = "date")]
        public DateTime CertificateDate { get; set; }
        public long FirkaId { get; set; }
        public long RevenueVillageId { get; set; }
        [StringLength(100)]
        public string LandInVillage { get; set; }
        public long OwnerShipTypeId { get; set; }
        public long IrrigationTypeId { get; set; }
        [Column(TypeName = "numeric(5, 2)")]
        public decimal Acre { get; set; }

       
        public virtual ICollection<VaoCertificateDetailVM> VaoCertificateDetails { get; set; }
    }
}
