﻿using PACS.AgriLoan.Interface;
using PACS.AgriLoan.Repositories.Common;
using PACS.AgriLoan.Repositories.DbContext;
using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Repositories
{
    public class LoanRatioMasterRepository : GenericRepository<LoanRatioMaster>, ILoanRatioMasterRepository
    {
        private readonly AppDbContext _db;

        public LoanRatioMasterRepository(AppDbContext db) : base(db)
        {
            _db = db;
        }

        public async Task<decimal> GetEstimationAmount(long pacsId, long cropId)
        {
            return await (
                from Ratio in _db.VW_GetLoanRatioForCrops
                join district in _db.DistrictMasters on Ratio.DistrictId equals district.Id
                join pacs in _db.PacsMasters on district.Id equals pacs.DistrictId
                where pacs.Id == pacsId && Ratio.CropId == cropId

                select
                 (
                Ratio.Cash + Ratio.fertilizer + Ratio.Seed + Ratio.Pesticide + Ratio.Maintanance
                 )
               ).FirstOrDefaultAsync();
        }



        public async Task<VW_GetLoanRatioForCrop> GetLoanRatioForCrop(long pacsId, long cropId)
        {
            return await (
                from Ratio in _db.VW_GetLoanRatioForCrops
                join district in _db.DistrictMasters on Ratio.DistrictId equals district.Id
                join pacs in _db.PacsMasters on district.Id equals pacs.DistrictId
                where pacs.Id == pacsId && Ratio.CropId == cropId

                select new VW_GetLoanRatioForCrop
                {
                    Id = Ratio.Id,
                    EffectFrom = Ratio.EffectFrom,
                    DistrictId = Ratio.DistrictId,
                    CropId = Ratio.CropId,
                    Name = Ratio.Name,
                    NameInTamil = Ratio.NameInTamil,
                    Cash = Ratio.Cash,
                    fertilizer = Ratio.fertilizer,
                    Seed = Ratio.Seed,
                    Pesticide = Ratio.Pesticide,
                    Maintanance = Ratio.Maintanance,
                    IssueMonth = Ratio.IssueMonth,
                }
               ).FirstOrDefaultAsync();
        }


    }
}
