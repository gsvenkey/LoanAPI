﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using PACS.AgriLoan.Interface;
using PACS.AgriLoan.Repositories.Common;
using PACS.AgriLoan.Repositories.DbContext;
using PASC.AgriLoan.DomainModels.Models;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Repositories
{
    public  class RevenueVillageMasterRepository : GenericRepository<RevenueVillageMaster>, IRevenueVillageMasterRepository
    {
         

        private readonly AppDbContext _db;

        public RevenueVillageMasterRepository(AppDbContext db) : base(db)
        {
            _db = db;
        }

        public async Task<IEnumerable<SelectListItem>> SelectRevenueVillage(long firkaId)
        {
            return await _db.RevenueVillageMasters.AsNoTracking().Where(c => c.FirkaId == firkaId && c.IsDeleted == false).OrderBy(n => n.Name)
                .Select(n => new SelectListItem
                {
                    Value = n.Id.ToString(),
                    Text = n.Name
                }).ToListAsync();

        }
    }
}
