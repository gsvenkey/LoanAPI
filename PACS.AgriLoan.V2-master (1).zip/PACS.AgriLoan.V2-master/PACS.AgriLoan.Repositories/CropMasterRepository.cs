﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using PACS.AgriLoan.Interface;
using PACS.AgriLoan.Interface.Common;
using PACS.AgriLoan.Repositories.Common;
using PACS.AgriLoan.Repositories.DbContext;
using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Repositories
{
    public class CropMasterRepository : GenericRepository<CropMaster>, ICropMasterRepository
    {
        private readonly AppDbContext _db;

        public CropMasterRepository(AppDbContext db) : base(db)
        {
            _db = db;
        }

        public async Task<int> getCropPeriod(long pacsId, long cropId)
        {
            return await (
               from Ratio in _db.VW_GetLoanRatioForCrops
               join district in _db.DistrictMasters on Ratio.DistrictId equals district.Id
               join pacs in _db.PacsMasters on district.Id equals pacs.DistrictId
               where pacs.Id == pacsId && Ratio.CropId == cropId

               select
                (
                Ratio.LoanDuePeriod
                )
              ).FirstOrDefaultAsync();
        }

        public async Task<IEnumerable<SelectListItem>> SelectCrop(long categoryId)
        {

            return await _db.CropMasters.AsNoTracking().Where(c => c.IsDeleted == false && c.CategoryId == categoryId).OrderBy(n => n.Name)
                .Select(n => new SelectListItem
                {
                    Value = n.Id.ToString(),
                    Text = n.Name
                }).ToListAsync();

        }

        public async Task<IEnumerable<SelectListItem>> SelectCrop(long pacsId, long categoryId)
        {

            return await (
                from Ratio in _db.LoanRatioMasters
                join crop in _db.CropMasters on Ratio.CropId equals crop.Id
                where crop.CategoryId == categoryId
                join category in _db.CropCategories on crop.CategoryId equals category.Id
                where category.IsDeleted == false
                join district in _db.DistrictMasters on Ratio.DistrictId equals district.Id
                join pacs in _db.PacsMasters on district.Id equals pacs.DistrictId
                where pacs.Id == pacsId

                select new SelectListItem
                {
                    Value = crop.Id.ToString(),
                    Text = crop.Name
                }


               ).ToListAsync();



        }

    }
}
