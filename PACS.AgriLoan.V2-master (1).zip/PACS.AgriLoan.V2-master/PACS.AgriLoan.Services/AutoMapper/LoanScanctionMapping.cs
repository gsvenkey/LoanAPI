﻿using AutoMapper;
using PACS.AgriLoan.ViewModel;
using PASC.AgriLoan.DomainModels.Models;

namespace PACS.AgriLoan.Services.AutoMapper
{
    public class LoanScanctionMapping : Profile
    {
        public LoanScanctionMapping()
        {
            #region View Modals to Domain Modals

            CreateMap<LoanSanctionHeaderVM, LoanSanctionHeader>()
                .ForMember(dest => dest.LoanIssueHeaders, src => src.Ignore())
                .ForMember(dest => dest.FYear, src => src.Ignore())
                .ForMember(dest => dest.LoanRequest, src => src.Ignore())
                .ForMember(dest => dest.Member, src => src.Ignore())
                .ForMember(dest => dest.Pacs, src => src.Ignore())
                .ForMember(dest => dest.LoanType, src => src.Ignore())
                
                ;

            CreateMap<LoanSanctionDetailVM, LoanSanctionDetail>()
                .ForMember(dest => dest.Crop, src => src.Ignore())
                .ForMember(dest => dest.VaoDetail, src => src.Ignore())
                .ForMember(dest => dest.LoanIssueDetails, src => src.Ignore())
                .ForMember(dest => dest.Sanction, src => src.Ignore());


            #endregion

            #region Domain Modals to View Modals  

            CreateMap<LoanSanctionHeader, LoanSanctionHeaderVM>()
                .ForMember(dest => dest.Message, src => src.Ignore());

            CreateMap<LoanSanctionDetail, LoanSanctionDetailVM>()
                .ForMember(dest => dest.Message, src => src.Ignore());
            //.ForMember(dest => dest.FertilizerPerAcre, src => src.Ignore())
            //.ForMember(dest => dest.SeedPerAcre, src => src.Ignore())
            //.ForMember(dest => dest.PesticidePerAcre, src => src.Ignore())
            //.ForMember(dest => dest.KindFertilizerPerAcre, src => src.Ignore())
            //.ForMember(dest => dest.KindSeedPerAcre, src => src.Ignore())
            //.ForMember(dest => dest.KindPesticidePerAcre, src => src.Ignore());

            CreateMap<VW_GetLoanRequestHeader, LoanSanctionHeaderVM>()
                .ForMember(dest => dest.Message, src => src.Ignore())
                .ForMember(dest => dest.LoanRequestId, src => src.Ignore())
                .ForMember(dest => dest.SanctionNo, src => src.Ignore())
                .ForMember(dest => dest.SanctionDate, src => src.Ignore())
                .ForMember(dest => dest.SanctionAmount, src => src.Ignore())
                .ForMember(dest => dest.LoanSanctionDetails, src => src.Ignore())
                .ForMember(dest => dest.CreatedDate, src => src.Ignore())
                .ForMember(dest => dest.ModifiedDate, src => src.Ignore())
                .ForMember(dest => dest.IsDeleted, src => src.Ignore())
                .ForMember(dest => dest.CreatedBy, src => src.Ignore())
                .ForMember(dest => dest.ModifiedBy, src => src.Ignore());



                 CreateMap<VW_GetLoanRequestDetail, LoanSanctionDetailVM>()
                .ForMember(dest => dest.Message, src => src.Ignore())
                .ForMember(dest => dest.Message, src => src.Ignore())
                .ForMember(dest => dest.CreatedDate, src => src.Ignore())
                .ForMember(dest => dest.ModifiedDate, src => src.Ignore())
                .ForMember(dest => dest.IsDeleted, src => src.Ignore())
                .ForMember(dest => dest.CreatedBy, src => src.Ignore())
                .ForMember(dest => dest.ModifiedBy, src => src.Ignore())
                .ForMember(dest => dest.SanctionId, src => src.Ignore())
                .ForMember(dest => dest.VaoDetail, src => src.Ignore())
                ;


            //CreateMap<VW_ListLoanIssue, ListLoanIssueVM>();

            #endregion
        }

    }
}
