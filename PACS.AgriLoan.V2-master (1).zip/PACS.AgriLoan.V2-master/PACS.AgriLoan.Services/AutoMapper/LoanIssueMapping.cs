﻿using AutoMapper;
using PACS.AgriLoan.ViewModel;
using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Services.AutoMapper
{
    public class LoanIssueMapping : Profile
    {
        public LoanIssueMapping()
        {
            #region View Modals to Domain Modals
            CreateMap<LoanIssueHeaderVM, LoanIssueHeader>()
                    .ForMember(dest => dest.LoanReceipts, src => src.Ignore())
                    .ForMember(dest => dest.FYear, src => src.Ignore())
                    .ForMember(dest => dest.Sanction, src => src.Ignore())
                    .ForMember(dest => dest.Member, src => src.Ignore())
                    .ForMember(dest => dest.LoanType, src => src.Ignore())
                    .ForMember(dest => dest.Pacs, src => src.Ignore())
                    ;

            CreateMap<LoanIssueDetailVM, LoanIssueDetail>()
                .ForMember(dest => dest.Crop, src => src.Ignore())
                .ForMember(dest => dest.VaoDetail, src => src.Ignore())
                .ForMember(dest => dest.Issue, src => src.Ignore())
                .ForMember(dest => dest.SanctionDetail, src => src.Ignore());
            #endregion


            #region Domain Modals to View Modals 
            CreateMap<LoanIssueHeader,LoanIssueHeaderVM >()
                    .ForMember(dest => dest.Message, src => src.Ignore());

            CreateMap<LoanIssueDetail, LoanIssueDetailVM>()
                .ForMember(dest => dest.Message, src => src.Ignore());
            //.ForMember(dest => dest.FertilizerPerAcre, src => src.Ignore())
            //.ForMember(dest => dest.SeedPerAcre, src => src.Ignore())
            //.ForMember(dest => dest.PesticidePerAcre, src => src.Ignore())
            //.ForMember(dest => dest.KindFertilizerPerAcre, src => src.Ignore())
            //.ForMember(dest => dest.KindSeedPerAcre, src => src.Ignore())
            //.ForMember(dest => dest.KindPesticidePerAcre, src => src.Ignore());

            CreateMap<VW_ListLoanIssue, ListLoanIssueVM>();

            #endregion
        }

    }
}
