﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Table("LoanRequestDetail")]
    public partial class LoanRequestDetail
    {
        [Key]
        public long Id { get; set; }
        public long LoanRequestId { get; set; }
        public long CropId { get; set; }
        public long VaoDetailId { get; set; }
        public int LoanDuePeriod { get; set; }
        [Column(TypeName = "numeric(5, 2)")]
        public decimal Acre { get; set; }
        [Column(TypeName = "numeric(5, 2)")]
        public decimal CultivationAcre { get; set; }
        [Column(TypeName = "numeric(14, 2)")]
        public decimal? RequestAmount { get; set; }
        public bool IsDeleted { get; set; }
        public int? CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        public int? ModifiedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDate { get; set; }

        [ForeignKey(nameof(CropId))]
        [InverseProperty(nameof(CropMaster.LoanRequestDetails))]
        public virtual CropMaster Crop { get; set; }
        [ForeignKey(nameof(LoanRequestId))]
        [InverseProperty(nameof(LoanRequestHeader.LoanRequestDetails))]
        public virtual LoanRequestHeader LoanRequest { get; set; }
        [ForeignKey(nameof(VaoDetailId))]
        [InverseProperty(nameof(VaoCertificateDetail.LoanRequestDetails))]
        public virtual VaoCertificateDetail VaoDetail { get; set; }
    }
}
