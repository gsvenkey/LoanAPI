﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Table("PacsMaster")]
    public partial class PacsMaster
    {
        public PacsMaster()
        {
            DccbSanctionOrders = new HashSet<DccbSanctionOrder>();
            EmployeeMasters = new HashSet<EmployeeMaster>();
            JewelValuations = new HashSet<JewelValuation>();
            JlgHeaders = new HashSet<JlgHeader>();
            LoanIssueHeaders = new HashSet<LoanIssueHeader>();
            LoanReceipts = new HashSet<LoanReceipt>();
            LoanRequestHeaders = new HashSet<LoanRequestHeader>();
            LoanSanctionHeaders = new HashSet<LoanSanctionHeader>();
            MemberMasters = new HashSet<MemberMaster>();
        }

        [Key]
        public long Id { get; set; }
        public long ZoneId { get; set; }
        public long DistrictId { get; set; }
        public long TalukId { get; set; }
        public long BlockId { get; set; }
        public int SDSCode { get; set; }
        public bool IsReportingToDCCB { get; set; }
        public long? DccbId { get; set; }
        public long? ReportingId { get; set; }
        [Required]
        [StringLength(150)]
        public string Name { get; set; }
        [StringLength(15)]
        public string ShortName { get; set; }
        [Required]
        [StringLength(150)]
        public string NameInTamil { get; set; }
        [Required]
        [StringLength(50)]
        public string Address1 { get; set; }
        [Required]
        [StringLength(50)]
        public string Address2 { get; set; }
        [Required]
        [StringLength(50)]
        public string Address3 { get; set; }
        [Required]
        [StringLength(50)]
        public string Address4 { get; set; }
        public int PinCode { get; set; }
        [Required]
        [StringLength(15)]
        public string PhoneNo { get; set; }
        [Column(TypeName = "numeric(14, 0)")]
        public decimal DccbAccountNumber { get; set; }
        [Column(TypeName = "numeric(14, 0)")]
        public decimal TransitNumber { get; set; }
        [Column(TypeName = "numeric(14, 0)")]
        public decimal CifNumber { get; set; }
        [Column(TypeName = "numeric(14, 0)")]
        public decimal? InsuranceAccountNumber { get; set; }
        public int? VaoCertificateValidity { get; set; }
        public int? MaxSuriety { get; set; }
        public bool IsDeleted { get; set; }
        public int? CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        public int? ModifiedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDate { get; set; }

        [ForeignKey(nameof(BlockId))]
        [InverseProperty(nameof(BlockMaster.PacsMasters))]
        public virtual BlockMaster Block { get; set; }
        [ForeignKey(nameof(DccbId))]
        [InverseProperty(nameof(DccbBankMaster.PacsMasters))]
        public virtual DccbBankMaster Dccb { get; set; }
        [ForeignKey(nameof(DistrictId))]
        [InverseProperty(nameof(DistrictMaster.PacsMasters))]
        public virtual DistrictMaster District { get; set; }
        [ForeignKey(nameof(TalukId))]
        [InverseProperty(nameof(TalukMaster.PacsMasters))]
        public virtual TalukMaster Taluk { get; set; }
        [ForeignKey(nameof(ZoneId))]
        [InverseProperty(nameof(ZoneMaster.PacsMasters))]
        public virtual ZoneMaster Zone { get; set; }
        [InverseProperty(nameof(DccbSanctionOrder.Pacs))]
        public virtual ICollection<DccbSanctionOrder> DccbSanctionOrders { get; set; }
        [InverseProperty(nameof(EmployeeMaster.Pacs))]
        public virtual ICollection<EmployeeMaster> EmployeeMasters { get; set; }
        [InverseProperty(nameof(JewelValuation.Pacs))]
        public virtual ICollection<JewelValuation> JewelValuations { get; set; }
        [InverseProperty(nameof(JlgHeader.Pacs))]
        public virtual ICollection<JlgHeader> JlgHeaders { get; set; }
        [InverseProperty(nameof(LoanIssueHeader.Pacs))]
        public virtual ICollection<LoanIssueHeader> LoanIssueHeaders { get; set; }
        [InverseProperty(nameof(LoanReceipt.Pacs))]
        public virtual ICollection<LoanReceipt> LoanReceipts { get; set; }
        [InverseProperty(nameof(LoanRequestHeader.Pacs))]
        public virtual ICollection<LoanRequestHeader> LoanRequestHeaders { get; set; }
        [InverseProperty(nameof(LoanSanctionHeader.Pacs))]
        public virtual ICollection<LoanSanctionHeader> LoanSanctionHeaders { get; set; }
        [InverseProperty(nameof(MemberMaster.Pacs))]
        public virtual ICollection<MemberMaster> MemberMasters { get; set; }
    }
}
