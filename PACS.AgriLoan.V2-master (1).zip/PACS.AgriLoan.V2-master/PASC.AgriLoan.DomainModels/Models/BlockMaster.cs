﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Table("BlockMaster")]
    public partial class BlockMaster
    {
        public BlockMaster()
        {
            PacsMasters = new HashSet<PacsMaster>();
        }

        [Key]
        public long Id { get; set; }
        public long TalukId { get; set; }
        [Required]
        [StringLength(50)]
        public string Name { get; set; }
        [StringLength(15)]
        public string Code { get; set; }
        [StringLength(15)]
        public string ShortName { get; set; }
        [Required]
        [StringLength(50)]
        public string NameInTamil { get; set; }
        public bool IsDeleted { get; set; }
        public int? CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        public int? ModifiedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDate { get; set; }

        [ForeignKey(nameof(TalukId))]
        [InverseProperty(nameof(TalukMaster.BlockMasters))]
        public virtual TalukMaster Taluk { get; set; }
        [InverseProperty(nameof(PacsMaster.Block))]
        public virtual ICollection<PacsMaster> PacsMasters { get; set; }
    }
}
