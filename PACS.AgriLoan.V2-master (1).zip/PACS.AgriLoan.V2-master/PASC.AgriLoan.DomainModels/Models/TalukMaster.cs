﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Table("TalukMaster")]
    public partial class TalukMaster
    {
        public TalukMaster()
        {
            BlockMasters = new HashSet<BlockMaster>();
            FirkaMasters = new HashSet<FirkaMaster>();
            PacsMasters = new HashSet<PacsMaster>();
            ReportingAreaOffices = new HashSet<ReportingAreaOffice>();
        }

        [Key]
        public long Id { get; set; }
        public long DistrictId { get; set; }
        [Required]
        [StringLength(50)]
        public string Name { get; set; }
        [StringLength(50)]
        public string ShortName { get; set; }
        [Required]
        [StringLength(50)]
        public string NameInTamil { get; set; }
        public bool IsDeleted { get; set; }
        public int? CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        public int? ModifiedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDate { get; set; }

        [ForeignKey(nameof(DistrictId))]
        [InverseProperty(nameof(DistrictMaster.TalukMasters))]
        public virtual DistrictMaster District { get; set; }
        [InverseProperty(nameof(BlockMaster.Taluk))]
        public virtual ICollection<BlockMaster> BlockMasters { get; set; }
        [InverseProperty(nameof(FirkaMaster.Taluk))]
        public virtual ICollection<FirkaMaster> FirkaMasters { get; set; }
        [InverseProperty(nameof(PacsMaster.Taluk))]
        public virtual ICollection<PacsMaster> PacsMasters { get; set; }
        [InverseProperty(nameof(ReportingAreaOffice.Taluk))]
        public virtual ICollection<ReportingAreaOffice> ReportingAreaOffices { get; set; }
    }
}
