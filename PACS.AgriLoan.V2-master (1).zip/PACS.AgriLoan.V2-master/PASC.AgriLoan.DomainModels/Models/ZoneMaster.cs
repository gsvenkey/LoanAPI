﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.EntityFrameworkCore;

#nullable disable

namespace PASC.AgriLoan.DomainModels.Models
{
    [Table("ZoneMaster")]
    public partial class ZoneMaster
    {
        public ZoneMaster()
        {
            PacsMasters = new HashSet<PacsMaster>();
            SubRegisterDistrictMasters = new HashSet<SubRegisterDistrictMaster>();
        }

        [Key]
        public long Id { get; set; }
        [Required]
        [StringLength(50)]
        public string Name { get; set; }
        [Required]
        [StringLength(100)]
        public string NameInTamil { get; set; }
        public bool IsDeleted { get; set; }
        public int? CreatedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? CreatedDate { get; set; }
        public int? ModifiedBy { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? ModifiedDate { get; set; }

        [InverseProperty(nameof(PacsMaster.Zone))]
        public virtual ICollection<PacsMaster> PacsMasters { get; set; }
        [InverseProperty(nameof(SubRegisterDistrictMaster.ZoneMaster))]
        public virtual ICollection<SubRegisterDistrictMaster> SubRegisterDistrictMasters { get; set; }
    }
}
