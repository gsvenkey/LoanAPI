﻿using AutoMapper;
using Moq;
using NUnit.Framework;

namespace PACS.AgriLoan.UnitTests
{
    public abstract class TestBase
    {
        protected Mock<IMapper> MockMapper;
        [OneTimeSetUp]
        public void OneTimeSetUp()
        {
            InitializeMocks();
        }
        private void InitializeMocks()
        {
            MockMapper = new Mock<IMapper>();
        }
    }
}
