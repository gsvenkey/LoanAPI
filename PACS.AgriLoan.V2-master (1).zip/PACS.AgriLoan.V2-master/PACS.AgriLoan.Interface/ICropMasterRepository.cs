﻿using Microsoft.AspNetCore.Mvc.Rendering;
using PACS.AgriLoan.Interface.Common;
using PASC.AgriLoan.DomainModels.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Interface
{
   public interface ICropMasterRepository :  IGenericRepository<CropMaster>
    {
        Task<IEnumerable<SelectListItem>> SelectCrop(long categoryId);
        Task<IEnumerable<SelectListItem>> SelectCrop(long pacsId,long categoryId);
        Task<int> getCropPeriod(long pacsId, long cropId);
    }
}
