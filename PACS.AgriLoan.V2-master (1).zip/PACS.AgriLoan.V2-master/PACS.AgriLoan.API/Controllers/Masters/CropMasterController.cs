﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using PACS.AgriLoan.Business.Interface;
using System;
using System.Threading.Tasks;

namespace PACS.AgriLoan.API.Controllers.Masters
{
    [Route("api/[controller]")]
    [ApiController]
    public class CropMasterController : ControllerBase
    {
        private readonly ICropMasterBL _cropMasterBL;
        private readonly ILogger<CropMasterController> _logger;


        public CropMasterController(ILogger<CropMasterController> logger, ICropMasterBL cropMasterBL)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _cropMasterBL = cropMasterBL ?? throw new ArgumentNullException(nameof(cropMasterBL));
        }

        [HttpGet("SelectCrop/{cropCategoryId}")]
        public async Task<ActionResult<SelectListItem>> SelectCrop(long cropCategoryId)
        {
            _logger.LogInformation("SelectCrop Method Invoked in CropMasterController ");
            return Ok(await _cropMasterBL.SelectCrop(cropCategoryId));
        }

        [HttpGet("getCropPeriod/{pacsId}/{cropId}")]
        public async Task<ActionResult<int>> getCropPeriod(long pacsId, long cropId)
        {
            _logger.LogInformation("getCropPeriod Method Invoked in CropMasterController ");
            return Ok(await _cropMasterBL.getCropPeriod(pacsId, cropId));
        }



    }
}
