﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using PACS.AgriLoan.Business.Interface;
using PACS.AgriLoan.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PACS.AgriLoan.API.Controllers.Masters
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoanRatioMasterController : ControllerBase
    {
        private readonly ILoanRatioMasterBL _loanRatioMasterBL;
        private readonly ILogger<LoanRatioMasterController> _logger;


        public LoanRatioMasterController(ILogger<LoanRatioMasterController> logger, ILoanRatioMasterBL loanRatioMasterBL)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _loanRatioMasterBL = loanRatioMasterBL ?? throw new ArgumentNullException(nameof(loanRatioMasterBL));
        }

        [HttpGet("GetLoanRatioForCrop/{pacsId}/{cropId}/{acre}")]
        public async Task<ActionResult<LoanRatioMasterVM>> GetLoanRatioForCrop(long pacsId, long cropId, decimal acre)
        {
            _logger.LogInformation("GetTalukById Invoked & Id is : " + pacsId );
            var GetLoanRatio = await _loanRatioMasterBL.GetLoanRatioForCrop(pacsId,  cropId,  acre);
            return Ok(GetLoanRatio) != null ? GetLoanRatio : NotFound();
        }

        [HttpGet("GetEstimationAmount/{pacsId}/{cropId}/{acre}")]
        public async Task<ActionResult<decimal>> GetEstimationAmount(long pacsId, long cropId, decimal acre)
        {
            _logger.LogInformation("GetTalukById Invoked & Id is : " + pacsId);
            var Estimation = await _loanRatioMasterBL.GetEstimationAmount(pacsId, cropId, acre);
            return Ok(Estimation) != null ? Estimation : NotFound();
        }

         

    }
}
