﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using PACS.AgriLoan.Business.Interface;
using PACS.AgriLoan.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PACS.AgriLoan.API.Controllers.Transactions
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoanRequestController : ControllerBase
    {
        private readonly ILoanRequestBL _loanRequestBL;
        private readonly ILogger<LoanRequestController> _logger;


        public LoanRequestController(ILogger<LoanRequestController> logger, ILoanRequestBL loanRequestBL)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _loanRequestBL = loanRequestBL ?? throw new ArgumentNullException(nameof(loanRequestBL));
        }

        // POST api/<LoanRequestController>
        [HttpPost]
        public async Task<IActionResult> Post([FromBody] LoanRequestHeaderVM loanRequestHeader)
        {
            _logger.LogInformation("Invoked Post in LoanRequestController  : " + loanRequestHeader);
            return Ok(await _loanRequestBL.Add(loanRequestHeader));

        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Put(long id, [FromBody] LoanRequestHeaderVM loanRequestHeader)
        {
            _logger.LogInformation("Invoked Put in LoanRequestController  : " + loanRequestHeader);
            return Ok(await _loanRequestBL.Update(loanRequestHeader));
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete( long id)
        {
            _logger.LogInformation("Invoked Delete in LoanRequestController  : " + id);
            return Ok(await _loanRequestBL.SoftDelete(id));
        }

        // GET api/<LoanRequestController>/5
        [HttpGet("GetById/{id}")]
        public async Task<ActionResult<LoanRequestHeaderVM>> GetById(long id)
        {
            var GetById = await _loanRequestBL.GetById(id);
            return Ok(GetById) != null ? GetById : NotFound();
        }

        [HttpGet("GetLoanTypeDetails/{id}")]
        public async Task<ActionResult<LoanRequestHeaderVM>> GetLoanTypeDetails(long id)
        {
            var LoanTypeDetails = await _loanRequestBL.GetLoanTypeDetails(id);
            return Ok(LoanTypeDetails) != null ? LoanTypeDetails : NotFound();
        }

        [HttpGet("GetList/{pacsId}/{fYearId}")]
        public async Task<ActionResult<LoanRequestHeaderVM>> GetList(long pacsId, long fYearId)
        {
            var GetById = await _loanRequestBL.GetList(pacsId, fYearId);
            return Ok(GetById);
        }

        [HttpGet("SelectRequestNo/{pacsId}/{memberId}")]
        public async Task<ActionResult<SelectListItem>> SelectRequestNo(long pacsId, long memberId)
        {
            _logger.LogInformation("SelectMember Method Invoked in MemberMasterController ");
            return Ok(await _loanRequestBL.SelectRequestNo(pacsId, memberId));
        }

    }
}
