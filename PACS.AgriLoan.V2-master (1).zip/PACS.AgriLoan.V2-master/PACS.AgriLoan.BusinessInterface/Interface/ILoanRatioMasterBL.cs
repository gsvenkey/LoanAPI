﻿using PACS.AgriLoan.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Business.Interface
{
    public interface ILoanRatioMasterBL
    {
        Task<LoanRatioMasterVM> GetLoanRatioForCrop(long pacsId, long cropId, decimal acre);
        Task<decimal> GetEstimationAmount(long pacsId, long cropId, decimal acre);
    }
}
