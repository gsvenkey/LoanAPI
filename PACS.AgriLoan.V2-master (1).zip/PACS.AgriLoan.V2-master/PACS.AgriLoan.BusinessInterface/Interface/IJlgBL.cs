﻿using Microsoft.AspNetCore.Mvc.Rendering;
using PACS.AgriLoan.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Business.Interface
{
    public interface IJlgBL
    {
        Task<IEnumerable<JlgMembersInfoVM>> GetJlgMembersInfo(long JlgMemberId);

        Task<IEnumerable<SelectListItem>> SelectJlg(long pacsId);
    }
}
