﻿using PACS.AgriLoan.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PACS.AgriLoan.Business.Interface
{
   public interface IVAOCertificateBL
    {
        Task<IEnumerable<ServeyDetailsVM>> GetServeyDetails(long memberId);
        Task<IEnumerable<ServeyDetailsVM>> GetJlgMemberServeyDetails(long jlgMemberId);
        Task<bool> Add(VaoCertificateHeaderVM vaoCertificateHeaderVM);
        Task<VaoCertificateHeaderVM> GetById(long Id);
    }
}
